/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 50528
 Source Host           : localhost:3312
 Source Schema         : serverrest

 Target Server Type    : MySQL
 Target Server Version : 50528
 File Encoding         : 65001

 Date: 05/09/2019 09:29:47
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for permission
-- ----------------------------
DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `per_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '权限名称',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'url',
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图标',
  `parent_id` int(11) NULL DEFAULT NULL COMMENT '父级菜单ID',
  `per_type` tinyint(4) NULL DEFAULT NULL COMMENT '菜单状态  1.只读，2.可写，3.隐藏，4.显示',
  `per_level` tinyint(4) NULL DEFAULT NULL COMMENT '菜单级别：1.一级菜单，2.二级菜单，3.三级菜单',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 74 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of permission
-- ----------------------------
INSERT INTO `permission` VALUES (1, '概览', '/stap/dashboard', '概况', NULL, 2, 1);
INSERT INTO `permission` VALUES (2, '安全事件中心', 'securityEventCenter', '安全', NULL, 2, 1);
INSERT INTO `permission` VALUES (3, '高危攻击', '/stap/securityEventCenter/highAttackEvent', '', 2, 2, 2);
INSERT INTO `permission` VALUES (4, '恶意文件', '/stap/securityEventCenter/rigidCreepEvent', '', 2, 2, 2);
INSERT INTO `permission` VALUES (5, 'C&C攻击', '/stap/securityEventCenter/ccAttack', '', 2, 2, 2);
INSERT INTO `permission` VALUES (6, '邮件威胁', '/stap/securityEventCenter/email', '', 2, 2, 2);
INSERT INTO `permission` VALUES (7, '网页篡改', '/stap/securityEventCenter/pageTamperingEvent', '', 2, 2, 2);
INSERT INTO `permission` VALUES (8, '暴力破解', '/stap/securityEventCenter/bruteForceEvent', '', 2, 2, 2);
INSERT INTO `permission` VALUES (9, '拒绝服务', '/stap/securityEventCenter/denialServiceEvent', '', 2, 2, 2);
INSERT INTO `permission` VALUES (10, '异常访问', '/stap/securityEventCenter/exceptionAccess', '', 2, 2, 2);
INSERT INTO `permission` VALUES (11, '高危漏洞', '/stap/securityEventCenter/highVul', '', 2, 2, 2);
INSERT INTO `permission` VALUES (12, '威胁分析中心', 'threatAnalysisCenter', '威胁情报', NULL, 2, 1);
INSERT INTO `permission` VALUES (13, '内部威胁分析', '/stap/threatAnalysisCenter/insideThreatAnalysis', '', 12, 2, 2);
INSERT INTO `permission` VALUES (14, '外连威胁分析', '/stap/threatAnalysisCenter/contingentThreatAnalysis', '', 12, 2, 2);
INSERT INTO `permission` VALUES (15, '外部威胁分析', '/stap/threatAnalysisCenter/externalThreatAnalysis', '', 12, 2, 2);
INSERT INTO `permission` VALUES (16, '文件威胁分析', '/stap/threatAnalysisCenter/fileThreatAnalysis', '', 12, 2, 2);
INSERT INTO `permission` VALUES (17, '流量分析中心', 'flowAnalysisCenter', '流量', NULL, 2, 1);
INSERT INTO `permission` VALUES (18, '内部流量分析', '/stap/flowAnalysisCenter/insideFlowAnalysis', '', 17, 2, 2);
INSERT INTO `permission` VALUES (19, '外连流量分析', '/stap/flowAnalysisCenter/contingentFlowAnalysis', '', 17, 2, 2);
INSERT INTO `permission` VALUES (20, '外部流量分析', '/stap/flowAnalysisCenter/externalFlowAnalysis', '', 17, 2, 2);
INSERT INTO `permission` VALUES (21, '违规访问分析', '/stap/flowAnalysisCenter/voilatoryVisitsAnalysis', '', 17, 2, 2);
INSERT INTO `permission` VALUES (22, '违规访问', '/stap/flowAnalysisCenter/insideFlowAnalysis/voilatoryVisits', '', 21, 2, 3);
INSERT INTO `permission` VALUES (23, '违规模型', '/stap/flowAnalysisCenter/insideFlowAnalysis/voilatoryVisitsModel', '', 21, 2, 3);
INSERT INTO `permission` VALUES (24, '漏洞分析中心', 'vulnerabilityAnalysisCenter', '漏洞管理', NULL, 2, 1);
INSERT INTO `permission` VALUES (25, '漏洞概览', '/stap/vulnerabilityAnalysisCenter/overallVulnerabilityAnalysis', '', 24, 2, 2);
INSERT INTO `permission` VALUES (26, '任务管理', '/stap/vulnerabilityAnalysisCenter/vulTaskManage', '', 24, 2, 2);
INSERT INTO `permission` VALUES (27, '策略管理', '/stap/vulnerabilityAnalysisCenter/vulPolicyManage', '', 24, 2, 2);
INSERT INTO `permission` VALUES (28, '任务历史', '/stap/vulnerabilityAnalysisCenter/taskHistory', '', 24, 2, 2);
INSERT INTO `permission` VALUES (29, '报告分析', '/stap/vulnerabilityAnalysisCenter/reportAnalysis', '', 24, 2, 2);
INSERT INTO `permission` VALUES (30, '漏洞信息', '/stap/vulnerabilityAnalysisCenter/vulInfo', '', 24, 2, 2);
INSERT INTO `permission` VALUES (31, '威胁情报中心', 'threatIntelligenceCenter', '情报', NULL, 2, 1);
INSERT INTO `permission` VALUES (32, '威胁情报', '/stap/threatIntelligenceCenter/threatIntelligence', '', 31, 2, 2);
INSERT INTO `permission` VALUES (33, '黑客档案', '/stap/threatIntelligenceCenter/hackerArchives', '', 31, 2, 2);
INSERT INTO `permission` VALUES (34, '资产监控中心', 'assetMonitorCenter', '资产', NULL, 2, 1);
INSERT INTO `permission` VALUES (35, '风险监控', '/stap/assetMonitorCenter/riskMonitorOverview', '', 34, 2, 2);
INSERT INTO `permission` VALUES (36, '资产管理', '/stap/assetMonitorCenter/assetManage', '', 34, 2, 2);
INSERT INTO `permission` VALUES (37, '机构标签', '/stap/assetMonitorCenter/institutionalLabelManage', '', 34, 2, 2);
INSERT INTO `permission` VALUES (38, '安全报表中心', 'securityReportCenter', '报告', NULL, 2, 1);
INSERT INTO `permission` VALUES (39, '报表模板管理', '/stap/securityReportCenter/reportTemplateManage', '', 38, 2, 2);
INSERT INTO `permission` VALUES (40, '报表订阅管理', '/stap/securityReportCenter/reportSubscriptionManage', '', 38, 2, 2);
INSERT INTO `permission` VALUES (41, '历史报表', '/stap/securityReportCenter/reportHistory', '', 38, 2, 2);
INSERT INTO `permission` VALUES (42, '联动处置中心', 'linkageDisposalCenter', '社会联动力量', NULL, 2, 1);
INSERT INTO `permission` VALUES (43, '联动管理', '/stap/linkageDisposalCenter/linkageManage', '', 42, 2, 2);
INSERT INTO `permission` VALUES (44, '联动设备', '/stap/linkageDisposalCenter/linkageDevice', '', 42, 2, 2);
INSERT INTO `permission` VALUES (45, '联动历史', '/stap/linkageDisposalCenter/linkageHistory', '', 42, 2, 2);
INSERT INTO `permission` VALUES (46, '安全日志中心', 'logCenter', '日历', NULL, 2, 1);
INSERT INTO `permission` VALUES (47, '安全日志', '/stap/logCenter/securityLog', '', 46, 2, 2);
INSERT INTO `permission` VALUES (48, '联动日志', '/stap/logCenter/linkageLog', '', 46, 2, 2);
INSERT INTO `permission` VALUES (49, 'SIEM系统', '/stap/logCenter/siemLog', '', 46, 2, 2);
INSERT INTO `permission` VALUES (50, '事件告警', '/stap/logCenter/siemLog/eventAlarm', '', 49, 2, 3);
INSERT INTO `permission` VALUES (52, '关联规则', '/stap/logCenter/siemLog/associationRules', '', 49, 2, 3);
INSERT INTO `permission` VALUES (53, '日志告警', '/stap/logCenter/siemLog/logAlarm', '', 49, 2, 3);
INSERT INTO `permission` VALUES (54, '第三方日志', '/stap/logCenter/siemLog/thirdPartyLog', '', 49, 2, 3);
INSERT INTO `permission` VALUES (55, '采集器管理', '/stap/logCenter/siemLog/collectorManage', '', 49, 2, 3);
INSERT INTO `permission` VALUES (56, '系统管理', 'systemManage', '系统', NULL, 2, 1);
INSERT INTO `permission` VALUES (57, '用户管理', '/stap/systemManage/userManage', '', 56, 2, 2);
INSERT INTO `permission` VALUES (58, '角色管理', '/stap/systemManage/ruleManage', '', 56, 2, 2);
INSERT INTO `permission` VALUES (59, '告警管理', '/stap/systemManage/alarmManage', '', 56, 2, 2);
INSERT INTO `permission` VALUES (62, '探针管理', '/stap/systemManage/sensorManage', '', 56, 2, 2);
INSERT INTO `permission` VALUES (63, '系统日志', '/stap/systemManage/systemLog', '', 56, 2, 2);
INSERT INTO `permission` VALUES (64, '系统设置', '/stap/systemManage/systemConfig', '', 56, 2, 2);
INSERT INTO `permission` VALUES (65, '平台管理', '/stap/systemManage/systemConfig/platformManagement', '', 64, 2, 3);
INSERT INTO `permission` VALUES (66, '接口管理', '/stap/systemManage/systemConfig/interfaceManage', '', 64, 2, 3);
INSERT INTO `permission` VALUES (67, '路由管理', '/stap/systemManage/systemConfig/routeManage', '', 64, 2, 3);
INSERT INTO `permission` VALUES (68, '日志设置', '/stap/systemManage/systemConfig/logConfig', '', 64, 2, 3);
INSERT INTO `permission` VALUES (69, '平台级联', '/stap/systemManage/systemConfig/platformCascade', '', 64, 2, 3);
INSERT INTO `permission` VALUES (70, '系统更新', '/stap/systemManage/systemUpdate', '', 56, 2, 2);
INSERT INTO `permission` VALUES (71, '平台升级', '/stap/systemManage/systemUpdate/platformUpgrade', '', 70, 2, 3);
INSERT INTO `permission` VALUES (72, '探针版本', '/stap/systemManage/systemUpdate/probeVersion', '', 70, 2, 3);
INSERT INTO `permission` VALUES (73, '库升级', '/stap/systemManage/systemUpdate/libraryUpgrade', '', 70, 2, 3);

SET FOREIGN_KEY_CHECKS = 1;
