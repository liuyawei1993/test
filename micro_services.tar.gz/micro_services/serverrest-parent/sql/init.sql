/*
eoLinker MySQL Data Transfer

Source Database    : NEW_STAP

Target Server Type : MYSQL
Database Version   : 1.0

Date               : 2019-09-03 11:18:23
*/
DROP database IF EXISTS serverRest;
    create database serverRest DEFAULT CHARSET utf8 COLLATE utf8_general_ci;
use serverRest;
-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
 `user_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户id',
 `user_name` varchar(255) NOT NULL COMMENT '用户名',
 `user_password` varchar(255) NULL DEFAULT NULL COMMENT '登录密码',
 `role_id` int(11) NOT NULL COMMENT '角色',
 `create_time` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
 `recent_opt_time` bigint(20) NULL DEFAULT NULL COMMENT '最近修改时间',
 `email` varchar(255) NULL DEFAULT NULL COMMENT '邮箱',
 `user_desc` varchar(255) NULL DEFAULT NULL COMMENT '用户描述',
 `status` varchar(50) NULL DEFAULT NULL COMMENT '状态（启用，禁用）',
 PRIMARY KEY (`user_id`)
);

-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
 `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
 `role_name` varchar(255) NOT NULL COMMENT '角色名',
 `role_desc` varchar(255) NULL DEFAULT NULL COMMENT '角色描述',
 `role_permission` text NULL DEFAULT NULL COMMENT '角色权限',
 PRIMARY KEY (`role_id`)
);

-- ----------------------------
-- Table structure for system_log
-- ----------------------------
DROP TABLE IF EXISTS `system_log`;
CREATE TABLE `system_log` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志ID',
 `opt_time` bigint(20) NULL DEFAULT NULL COMMENT '操作时间',
 `user_name` varchar(50) NULL DEFAULT NULL COMMENT '用户名',
 `opt` varchar(50) NULL DEFAULT NULL COMMENT '操作',
 `result` varchar(50) NULL DEFAULT NULL COMMENT '结果',
 `message` text NULL DEFAULT NULL COMMENT '日志信息',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for sensor_manage
-- ----------------------------
DROP TABLE IF EXISTS `sensor_manage`;
CREATE TABLE `sensor_manage` (
 `sensor_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '探针ID',
 `sensor_name` varchar(255) NULL DEFAULT NULL COMMENT '探针名称',
 `sensor_ip` varchar(15) NULL DEFAULT NULL COMMENT '探针IP',
 `sensor_type` varchar(50) NULL DEFAULT NULL COMMENT '探针类型',
 `status` varchar(50) NULL DEFAULT NULL COMMENT '探针状态',
 `create_time` bigint(20) NULL DEFAULT NULL COMMENT '添加时间',
 `cpu_name` varchar(100) NULL DEFAULT NULL COMMENT 'cpu名称',
 `cpu_freq` varchar(100) NULL DEFAULT NULL COMMENT 'cpu频率',
 `cpu_proc` varchar(100) NULL DEFAULT NULL COMMENT 'cpu核数',
 `memory_size` varchar(100) NULL DEFAULT NULL COMMENT '内存大小',
 `disk_size` varchar(100) NULL DEFAULT NULL COMMENT '磁盘大小',
 `user_name` varchar(255) NOT NULL COMMENT '探针的用户名',
 `password` varchar(255) NOT NULL COMMENT '密码',
 PRIMARY KEY (`sensor_id`)
);

-- ----------------------------
-- Table structure for sensor_policy
-- ----------------------------
DROP TABLE IF EXISTS `sensor_policy`;
CREATE TABLE `sensor_policy` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '策略ID',
 `policy_name` varchar(255) NULL DEFAULT NULL COMMENT '策略名称',
 `policy_type` varchar(50) NULL DEFAULT NULL COMMENT '策略类型',
 `create_time` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for sensor_status
-- ----------------------------
DROP TABLE IF EXISTS `sensor_status`;
CREATE TABLE `sensor_status` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '探针状态ID',
 `sensor_id` int(11) NOT NULL COMMENT '所属探针的ID',
 `time_stamp` bigint(20) NULL DEFAULT NULL COMMENT '时间戳',
 `cpu_usage` double(5,2) NULL DEFAULT NULL COMMENT 'cpu使用量',
 `memory_usage` double(5,2) NULL DEFAULT NULL COMMENT '内存使用量',
 `disk_usage` double(5,2) NULL DEFAULT NULL COMMENT '磁盘占用量',
 `in_flow` bigint(20) NULL DEFAULT NULL COMMENT '总流入流量',
 `out_flow` bigint(20) NULL DEFAULT NULL COMMENT '总流出流量',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for sensor_interface
-- ----------------------------
DROP TABLE IF EXISTS `sensor_interface`;
CREATE TABLE `sensor_interface` (
 `inf_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '接口ID',
 `sensor_id` int(11) NOT NULL COMMENT '探针ID',
 `name` varchar(100) NULL DEFAULT NULL COMMENT '接口名称',
 `ip` varchar(50) NULL DEFAULT NULL COMMENT 'ip地址',
 `mac` varchar(100) NULL DEFAULT NULL COMMENT 'mac地址',
 `status` varchar(50) NULL DEFAULT NULL COMMENT '接口状态',
 `type` varchar(50) NULL DEFAULT NULL COMMENT '接口类型',
 `flow_status` int(1) NULL DEFAULT NULL COMMENT '流浪服务开启选择',
 `attack_status` int(1) NULL DEFAULT NULL COMMENT '攻击服务开启选择',
 PRIMARY KEY (`inf_id`)
);

-- ----------------------------
-- Table structure for sensor_interface_status
-- ----------------------------
DROP TABLE IF EXISTS `sensor_interface_status`;
CREATE TABLE `sensor_interface_status` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '接口状态ID',
 `inf_id` int(11) NOT NULL COMMENT '接口id',
 `time_stamp` bigint(20) NULL DEFAULT NULL COMMENT '时间戳',
 `name` varchar(100) NULL DEFAULT NULL COMMENT '接口名称',
 `in_flow` bigint(20) NULL DEFAULT NULL COMMENT '流入流量',
 `out_flow` bigint(20) NULL DEFAULT NULL COMMENT '流出流量',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for sensor_cfg
-- ----------------------------
DROP TABLE IF EXISTS `sensor_cfg`;
CREATE TABLE `sensor_cfg` (
 `sensor_id` int(11) NOT NULL COMMENT '探针ID',
 `traffic_enable` tinyint(1) NULL DEFAULT NULL COMMENT '流量采集开关 0 关闭  1开启 2重启',
 `attack_enable` tinyint(1) NULL DEFAULT NULL COMMENT '攻击行为开关 0 关闭  1开启 2重启',
 `traffic_log_ip` varchar(15) NULL DEFAULT NULL COMMENT '流量日志服务器IP',
 `attack_log_ip` varchar(15) NULL DEFAULT NULL COMMENT '攻击日志服务器IP',
 `traffic_policy` text NULL DEFAULT NULL COMMENT '当前流量采集策略',
 `attack_policy` text NULL DEFAULT NULL COMMENT '当前攻击行为策略',
 `soft_version` varchar(50) NULL DEFAULT NULL COMMENT '软件版本信息',
 `sig_version` varchar(50) NULL DEFAULT NULL COMMENT '特征库版本',
 PRIMARY KEY (`sensor_id`)
);

-- ----------------------------
-- Table structure for platform_cfg
-- ----------------------------
DROP TABLE IF EXISTS `platform_cfg`;
CREATE TABLE `platform_cfg` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `cpu_status` tinyint(1) NULL DEFAULT NULL COMMENT 'cpu运行状态',
 `memory_status` tinyint(1) NULL DEFAULT NULL COMMENT '内存状态',
 `disk_status` tinyint(1) NULL DEFAULT NULL COMMENT '磁盘状态',
 `name` varchar(255) NULL DEFAULT NULL COMMENT '平台名称',
 `time_setting` bigint(50) NULL DEFAULT NULL COMMENT '设置的时间',
 `lock_time` bigint(50) NULL DEFAULT NULL COMMENT '用户锁定时间',
 `time_out` bigint(50) NULL DEFAULT NULL COMMENT '用户超时时间',
 `email_send` varchar(255) NULL DEFAULT NULL COMMENT '发件人邮箱',
 `smtp` varchar(255) NULL DEFAULT NULL COMMENT 'SMTP邮箱服务器',
 `port` int(10) NULL DEFAULT NULL COMMENT '端口号',
 `email_password` varchar(255) NULL DEFAULT NULL COMMENT '邮箱密码',
 `email_get` varchar(255) NULL DEFAULT NULL COMMENT '收件人邮箱',
 `simple_mode` tinyint(1) NULL DEFAULT NULL COMMENT '是否为简单模式(是否有用户名密码校验)',
 `certificate_enable` tinyint(1) NULL DEFAULT NULL COMMENT '是否需要证书校验',
 `HDFS` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `YARN` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `MapReduce2` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Tez` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Hive` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `HBase` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Pig` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `ZooKeeper` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Storm` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Ambari Metrics` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Kafka` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Spark` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Spark2` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Zeppelin` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Notebook` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Elasticsearch` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Metron` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 `Slinder` tinyint(1) NULL DEFAULT NULL COMMENT '1：正常，0：异常',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for sub_platform
-- ----------------------------
DROP TABLE IF EXISTS `sub_platform`;
CREATE TABLE `sub_platform` (
 `id` int(11) NULL DEFAULT NULL COMMENT 'id',
 `name` varchar(255) NULL DEFAULT NULL COMMENT '平台名称',
 `ip` varchar(50) NULL DEFAULT NULL COMMENT '平台地址',
 `status` varchar(50) NULL DEFAULT NULL COMMENT '当前状态',
 `message` text NULL DEFAULT NULL COMMENT '上报内容',
 `last_time` varchar(50) NULL DEFAULT NULL COMMENT '最近上报时间'
);

-- ----------------------------
-- Table structure for sup_platform
-- ----------------------------
DROP TABLE IF EXISTS `sup_platform`;
CREATE TABLE `sup_platform` (
 `sup_ip` varchar(50) NOT NULL COMMENT '上级平台IP',
 `asset_info` varchar(255) NULL DEFAULT NULL COMMENT '资产信息',
 `security_event` varchar(255) NULL DEFAULT NULL COMMENT '安全事件',
 `vulnerable_risk` varchar(255) NULL DEFAULT NULL COMMENT '脆弱风险',
 PRIMARY KEY (`sup_ip`)
);

-- ----------------------------
-- Table structure for route
-- ----------------------------
DROP TABLE IF EXISTS `route`;
CREATE TABLE `route` (
 `id` int(11) NULL DEFAULT NULL COMMENT 'id',
 `dst_ip` varchar(50) NULL DEFAULT NULL COMMENT '目的IP',
 `sub_mask` varchar(50) NULL DEFAULT NULL COMMENT '子网掩码',
 `next_network` varchar(50) NULL DEFAULT NULL COMMENT '下跳网管'
);

-- ----------------------------
-- Table structure for interface_manage
-- ----------------------------
DROP TABLE IF EXISTS `interface_manage`;
CREATE TABLE `interface_manage` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `dst_ip` varchar(50) NULL DEFAULT NULL COMMENT '目的IP',
 `desc` text NULL DEFAULT NULL COMMENT '描述',
 `ip_cfg` varchar(50) NULL DEFAULT NULL COMMENT 'ip配置',
 `route_cfg` varchar(50) NULL DEFAULT NULL COMMENT '路由配置',
 `net_status` tinyint(1) NULL DEFAULT NULL COMMENT '网口状态',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for alarm
-- ----------------------------
DROP TABLE IF EXISTS `alarm`;
CREATE TABLE `alarm` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `name` varchar(50) NULL DEFAULT NULL COMMENT '告警名称',
 `type` varchar(50) NULL DEFAULT NULL COMMENT '告警类型',
 `alarm_mode` varchar(50) NULL DEFAULT NULL COMMENT '告警方式',
 `reciver` varchar(255) NULL DEFAULT NULL COMMENT '收件人',
 `status` tinyint(1) NULL DEFAULT NULL COMMENT '状态',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for global_attack
-- ----------------------------
DROP TABLE IF EXISTS `global_attack`;
CREATE TABLE `global_attack` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `src_ip` varchar(50) NULL DEFAULT NULL COMMENT '源IP',
 `dst_ip` varchar(50) NULL DEFAULT NULL COMMENT '目的IP',
 `domain_name` varchar(255) NULL DEFAULT NULL COMMENT '域名',
 `url` varchar(255) NULL DEFAULT NULL COMMENT 'url',
 `attack_type` varchar(50) NULL DEFAULT NULL COMMENT '攻击类型',
 `effective_branch` varchar(255) NULL DEFAULT NULL COMMENT '生效分支',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for attack_whitelist
-- ----------------------------
DROP TABLE IF EXISTS `attack_whitelist`;
CREATE TABLE `attack_whitelist` (
 `id` int(11) NOT NULL COMMENT 'id',
 `host_ip` varchar(50) NULL DEFAULT NULL COMMENT '源地址',
 `target_ip` varchar(50) NULL DEFAULT NULL COMMENT '目标地址',
 `attack_type` varchar(50) NULL DEFAULT NULL COMMENT '攻击类型',
 `attack_name` varchar(100) NULL DEFAULT NULL COMMENT '攻击名称',
 `attack_state` varchar(50) NULL DEFAULT NULL COMMENT '攻击状态',
 `attack_operation` varchar(50) NULL DEFAULT NULL COMMENT '操作',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for vulnerability_whitelist
-- ----------------------------
DROP TABLE IF EXISTS `vulnerability_whitelist`;
CREATE TABLE `vulnerability_whitelist` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `host_ip` varchar(50) NULL DEFAULT NULL COMMENT '资产地址',
 `vul_state` varchar(255) NULL DEFAULT NULL COMMENT '漏洞状态',
 `vul_name` varchar(50) NULL DEFAULT NULL COMMENT '漏洞名称',
 `vul_type` varchar(50) NULL DEFAULT NULL COMMENT '漏洞类型',
 `vul_operation` varchar(50) NULL DEFAULT NULL COMMENT '操作',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for version_log
-- ----------------------------
DROP TABLE IF EXISTS `version_log`;
CREATE TABLE `version_log` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `old_version` varchar(50) NULL DEFAULT NULL COMMENT '老版本的版本号',
 `new_version` varchar(50) NULL DEFAULT NULL COMMENT '新版本的版本号',
 `MD5` int(11) NULL DEFAULT NULL COMMENT 'MD5',
 `doc_size` varchar(50) NULL DEFAULT NULL COMMENT '文件大小',
 `up_time` varchar(50) NULL DEFAULT NULL COMMENT '上传时间',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for sensor_update_log
-- ----------------------------
DROP TABLE IF EXISTS `sensor_update_log`;
CREATE TABLE `sensor_update_log` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `sensor_name` varchar(255) NULL DEFAULT NULL COMMENT '探针名',
 `version` varchar(50) NULL DEFAULT NULL COMMENT '版本',
 `last_update_time` varchar(50) NULL DEFAULT NULL COMMENT '最近更新时间',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for lib_update
-- ----------------------------
DROP TABLE IF EXISTS `lib_update`;
CREATE TABLE `lib_update` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
 `name` varchar(255) NULL DEFAULT NULL COMMENT '库名',
 `current_version` varchar(255) NULL DEFAULT NULL COMMENT '当前版本',
 `latest_version` varchar(255) NULL DEFAULT NULL COMMENT '最新版本',
 `cloud_version` varchar(255) NULL DEFAULT NULL COMMENT '云端获取版本',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for file
-- ----------------------------
DROP TABLE IF EXISTS `file`;
CREATE TABLE `file` (
 `file_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `file_type` int(11) NULL DEFAULT NULL COMMENT '文件类型 0:图片类 1:文档类 2:视频类 3:音乐类 4:其他类  (自定义)',
 `file_url` varchar(50) NULL DEFAULT NULL COMMENT '文件上传的路径',
 `create_time` bigint(20) NULL DEFAULT NULL COMMENT '上传时间',
 PRIMARY KEY (`file_id`)
);

-- ----------------------------
-- Table structure for linkage_equipment
-- ----------------------------
DROP TABLE IF EXISTS `linkage_equipment`;
CREATE TABLE `linkage_equipment` (
 `equipment_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `equipment_name` varchar(50) NULL DEFAULT NULL COMMENT '设备名称',
 `equipment_time` bigint(50) NULL DEFAULT NULL COMMENT '最近联动时间',
 `equipment_address` varchar(50) NULL DEFAULT NULL COMMENT '联动地址',
 PRIMARY KEY (`equipment_id`)
);

-- ----------------------------
-- Table structure for linkage_history
-- ----------------------------
DROP TABLE IF EXISTS `linkage_history`;
CREATE TABLE `linkage_history` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `equipment_name` varchar(50) NULL DEFAULT NULL COMMENT '设备名称',
 `process_target` varchar(80) NULL DEFAULT NULL COMMENT '处置目标',
 `operation_user` varchar(50) NULL DEFAULT NULL COMMENT '操作用户',
 `process_time` bigint(50) NULL DEFAULT NULL COMMENT '操作时间',
 `content` varchar(255) NULL DEFAULT NULL COMMENT '操作内容',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for linkage_manager
-- ----------------------------
DROP TABLE IF EXISTS `linkage_manager`;
CREATE TABLE `linkage_manager` (
 `ip` varchar(50) NOT NULL COMMENT 'ip主键',
 `threat_level` varchar(50) NULL DEFAULT NULL COMMENT '威胁等级',
 `process_time` bigint(50) NULL DEFAULT NULL COMMENT '处理时间',
 `valid_time` bigint(50) NULL DEFAULT NULL COMMENT '有效时间',
 `linkage_state` varchar(50) NULL DEFAULT NULL COMMENT '联动状态（忽略，已处置，未处置）',
 `danger_types` varchar(50) NULL DEFAULT NULL COMMENT '危险等级',
 `ignore` tinyint(2) NULL DEFAULT NULL COMMENT '是否取消（0：未取消，1.已取消）',
 `operation` tinyint(2) NULL DEFAULT NULL COMMENT '操作（0：白名单，1：黑名单）',
 `time` int(11) NULL DEFAULT NULL COMMENT '单位（小时，0表示永久）',
 `equipment_id` int(11) NULL DEFAULT NULL COMMENT '设备id',
 `top3` varchar(255) NULL DEFAULT NULL COMMENT '威胁类型top3',
 `count` int(11) NULL DEFAULT NULL COMMENT '威胁资产数量',
 PRIMARY KEY (`ip`)
);

-- ----------------------------
-- Table structure for platform_module
-- ----------------------------
DROP TABLE IF EXISTS `platform_module`;
CREATE TABLE `platform_module` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `module_name` varchar(50) NULL DEFAULT NULL COMMENT '组件名称',
 `module_status` varchar(50) NULL DEFAULT NULL COMMENT '组件状态',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for sensor_message
-- ----------------------------
DROP TABLE IF EXISTS `sensor_message`;
CREATE TABLE `sensor_message` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
 `sensor_id` int(11) NOT NULL COMMENT '探针id',
 `status` int(2) NULL DEFAULT NULL COMMENT '信息状态  空未下发  1正常下发  2作废',
 `message` text NULL DEFAULT NULL COMMENT '消息内容',
 `createTime` bigint(20) NULL DEFAULT NULL COMMENT '创建时间',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for task_manage
-- ----------------------------
DROP TABLE IF EXISTS `task_manage`;
CREATE TABLE `task_manage` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `name` varchar(50) NULL DEFAULT NULL COMMENT '任务名称',
 `target` varchar(50) NULL DEFAULT NULL COMMENT '检测目标',
 `strategy` varchar(50) NULL DEFAULT NULL COMMENT '检测策略',
 `status` int(11) NULL DEFAULT NULL COMMENT '任务状态  0=未开始 100=已完成 1-99 任务进度',
 `time` bigint(20) NULL DEFAULT NULL COMMENT '下发时间',
 `method` varchar(50) NULL DEFAULT NULL COMMENT '执行方式',
 `count` int(10) NULL DEFAULT NULL COMMENT '检测次数',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for policy_manage
-- ----------------------------
DROP TABLE IF EXISTS `policy_manage`;
CREATE TABLE `policy_manage` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `name` varchar(50) NULL DEFAULT NULL COMMENT '策略名称',
 `vul_type` varchar(50) NULL DEFAULT NULL COMMENT '漏洞类型',
 `desc` varchar(50) NULL DEFAULT NULL COMMENT '策略描述',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for task_history
-- ----------------------------
DROP TABLE IF EXISTS `task_history`;
CREATE TABLE `task_history` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `name` varchar(50) NULL DEFAULT NULL COMMENT '任务名称',
 `start_time` bigint(20) NULL DEFAULT NULL COMMENT '开始时间',
 `end_time` bigint(20) NULL DEFAULT NULL COMMENT '结束时间',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for analysis_report
-- ----------------------------
DROP TABLE IF EXISTS `analysis_report`;
CREATE TABLE `analysis_report` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
 `name` varchar(50) NULL DEFAULT NULL COMMENT '报告名称',
 `source` varchar(50) NULL DEFAULT NULL COMMENT '报告来源',
 `asset_count` int(11) NULL DEFAULT NULL COMMENT '资产数量',
 `vul_count` int(11) NULL DEFAULT NULL COMMENT '漏洞数量',
 `import_time` bigint(20) NULL DEFAULT NULL COMMENT '导入时间',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for asset_manage
-- ----------------------------
DROP TABLE IF EXISTS `asset_manage`;
CREATE TABLE `asset_manage` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '资产的id',
 `ip` varchar(50) NULL DEFAULT NULL COMMENT '资产地址',
 `asset_type` varchar(255) NULL DEFAULT NULL COMMENT '资产类型',
 `institutional_id` int(11) NULL DEFAULT NULL COMMENT '所属机构',
 `label_id` varchar(255) NULL DEFAULT NULL COMMENT '资产标签',
 `asset_state` varchar(255) NULL DEFAULT NULL COMMENT '资产状态',
 `asset_discovery` varchar(255) NULL DEFAULT NULL COMMENT '识别标记',
 `asset_weight` int(11) NULL DEFAULT NULL COMMENT '资产权重',
 `asset_group` varchar(255) NULL DEFAULT NULL COMMENT '资产分组',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for institutional_manage
-- ----------------------------
DROP TABLE IF EXISTS `institutional_manage`;
CREATE TABLE `institutional_manage` (
 `institutional_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '机构ID',
 `institutional_name` varchar(255) NULL DEFAULT NULL COMMENT '机构名称',
 `institutional_type` varchar(255) NULL DEFAULT NULL COMMENT '机构类型',
 `institutional_level` varchar(255) NULL DEFAULT NULL COMMENT '机构级别',
 `institutional_num` varchar(255) NULL DEFAULT NULL COMMENT '机构编号',
 `institutional_local` varchar(255) NULL DEFAULT NULL COMMENT '机构地理位置',
 `institutional_desc` varchar(255) NULL DEFAULT NULL COMMENT '机构描述',
 PRIMARY KEY (`institutional_id`)
);

-- ----------------------------
-- Table structure for institutional_owner
-- ----------------------------
DROP TABLE IF EXISTS `institutional_owner`;
CREATE TABLE `institutional_owner` (
 `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '责任人ID',
 `name` varchar(255) NULL DEFAULT NULL COMMENT '责任人名称',
 `work_code` varchar(255) NULL DEFAULT NULL COMMENT '工号',
 `job` varchar(255) NULL DEFAULT NULL COMMENT '工作岗位',
 `phone` varchar(50) NULL DEFAULT NULL COMMENT '联系电话',
 `email` varchar(255) NULL DEFAULT NULL COMMENT '邮箱',
 `institutional_id` int(11) NOT NULL COMMENT '所属机构的ID',
 PRIMARY KEY (`id`)
);

-- ----------------------------
-- Table structure for institutional_group
-- ----------------------------
DROP TABLE IF EXISTS `institutional_group`;
CREATE TABLE `institutional_group` (
 `group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '分组ID',
 `name` varchar(255) NULL DEFAULT NULL COMMENT '分组名称',
 `group_desc` varchar(255) NULL DEFAULT NULL COMMENT '分组描述',
 `asset_type` varchar(255) NULL DEFAULT NULL COMMENT '资产类型',
 `asset_range` varchar(255) NULL DEFAULT NULL COMMENT '资产范围',
 `institutional_id` int(11) NOT NULL COMMENT '所属机构的ID',
 PRIMARY KEY (`group_id`)
);

-- ----------------------------
-- Table structure for institutional_label
-- ----------------------------
DROP TABLE IF EXISTS `institutional_label`;
CREATE TABLE `institutional_label` (
 `label_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '标签ID',
 `name` varchar(255) NULL DEFAULT NULL COMMENT '标签名',
 `label_name` varchar(255) NULL DEFAULT NULL COMMENT '标签名',
 `label_desc` varchar(255) NULL DEFAULT NULL COMMENT '标签描述',
 PRIMARY KEY (`label_id`)
);


