

INSERT INTO serverrest.`user`
(user_id, user_name, user_password, role_id, create_time, recent_opt_time, email, user_desc, status)
VALUES(1, 'admin', 'YWRtaW4=', 1, NULL, NULL, NULL, NULL, NULL);


INSERT INTO serverRest.`role`
(role_id, role_name, role_desc, role_permission)
VALUES(1, 'test', '测试角色', 'highdisk');
