package com.dp.serverrest.service.api;

import java.util.List;
import java.util.Map;

import com.dp.serverrest.po.InstitutionalGroupPo;
import com.dp.serverrest.po.InstitutionalLabelPo;
import com.dp.serverrest.po.InstitutionalManagePo;
import com.dp.serverrest.po.InstitutionalOwnerPo;
import com.github.pagehelper.PageInfo;

/**
 * @author chaozhang
 */
public interface InstitutionalLabelService extends BaseService  {
     public Map<String, String> addGroup(Integer id, InstitutionalGroupPo institutionalGroupPo);

     public Map<String, String> addInstitution(InstitutionalManagePo institutionalManagePo);

    public Map<String, String> addLabel(InstitutionalLabelPo institutionalLabelPo);

    public Map<String, String> addOwner(Integer id, InstitutionalOwnerPo institutionalOwnerPo);

    public Map<String, String> deleteGroup(Integer id);

    public Map<String, String> deleteInstitution(Integer id);

    public Map<String, String> deleteLabel(Integer id);

    public Map<String, String> deleteOwner(Integer id);

    public List<InstitutionalGroupPo> getGroupList(Integer id);

    public List<InstitutionalManagePo> getInstitutionList();

    public PageInfo<InstitutionalLabelPo> getLabelList(Integer page, Integer limit);

    public List<InstitutionalOwnerPo> getOwnerList(Integer id);

    public Map<String, String> modifyGroup(Integer institutionalId, Integer id,
	    InstitutionalGroupPo institutionalGroupPo);

    public Map<String, String> modifyLabel(Integer id, InstitutionalLabelPo institutionalLabelPo);

    public Map<String, String> modifyOwner(Integer institutionalId, Integer id,
	    InstitutionalOwnerPo institutionalOwnerPo);
}
