package com.dp.serverrest.po;

public class InstitutionalOwnerPo extends BasePo {
    private Integer id;

    private String name;

    private String workCode;

    private String job;

    private String phone;

    private String email;

    private Integer institutionalId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getWorkCode() {
        return workCode;
    }

    public void setWorkCode(String workCode) {
        this.workCode = workCode == null ? null : workCode.trim();
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job == null ? null : job.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public Integer getInstitutionalId() {
        return institutionalId;
    }

    public void setInstitutionalId(Integer institutionalId) {
        this.institutionalId = institutionalId;
    }
}