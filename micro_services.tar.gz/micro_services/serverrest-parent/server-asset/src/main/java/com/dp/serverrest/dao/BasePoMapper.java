package com.dp.serverrest.dao;

import com.dp.serverrest.po.BasePo;

/**
 * @interfaceName: BaseVoMapper
 * @description:
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public interface BasePoMapper {

    int insert(BasePo record);

    int updateByPrimaryKey(BasePo vo);

    int deleteByPrimaryKey(int id);

}
