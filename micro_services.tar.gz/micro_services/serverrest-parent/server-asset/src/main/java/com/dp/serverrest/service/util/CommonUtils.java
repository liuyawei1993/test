package com.dp.serverrest.service.util;

import java.util.List;
import java.util.Map;

import com.dp.serverrest.dao.BasePoMapper;
import com.dp.serverrest.po.BasePo;
import com.google.common.collect.Maps;

/**
 * @className: CommonUtils
 * @description: 公共方法类
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public class CommonUtils {


    /**
     * @param dao
     * 新增的通用方法
     * @return
     */
    public static Map<String, String> addData(BasePo vo,BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        try {
            dao.insert(vo);
            result.put("success", "add success!");
        } catch (Exception e) {
            result.put("err", "add err!check it!");
        }
        return result;
    }

    /**
     * @param id
     * @param dao
     * 删除的通用方法
     * @return
     */
    public static Map<String, String> deleteData(int id, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.deleteByPrimaryKey(id);
        if (res > 0) {
            result.put("success", "delete success!");
        } else {
            result.put("err", "delete err!check it!");
        }
        return result;
    }

    /**
     * @param dao
     * 修改的通用方法
     * @return
     */
    public static Map<String, String> modifyData(Integer id, BasePo vo, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.updateByPrimaryKey(vo);
        if (res > 0) {
            result.put("success", "modify success!");
        } else {
            result.put("err", "modify err!check it!");
        }
        return result;
    }

    /**
     * @param ip
     *            将String型IP转成long
     * @return
     */
    public static Long ipToNumber(String ip) {
        Long ips = 0L;
        String[] numbers = ip.split("\\.");
        for (int i = 0; i < 4; ++i) {
            ips = ips << 8 | Integer.parseInt(numbers[i]);
        }
        return ips;
    }

    /**
     * @param list
     * @param separator
     *            分隔符 将List转成String用分隔符划分
     * @return
     */
    public static String listToString(List list, String separator) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            sb.append(list.get(i)).append(separator);
        }
        return sb.toString().substring(0, sb.toString().length() - 1);
    }

    /**
     * @param number
     *            将long类型IP转成String
     * @return
     */
    public static String numberToIp(Long number) {
        StringBuilder sb = new StringBuilder();
        // 直接右移24位
        sb.append(number >> 24);
        sb.append(".");
        // 将高8位置0，然后右移16
        sb.append((number & 0x00FFFFFF) >> 16);
        sb.append(".");
        // 将高16位置0，然后右移8位
        sb.append((number & 0x0000FFFF) >> 8);
        sb.append(".");
        // 将高24位置0
        sb.append((number & 0x000000FF));
        return sb.toString();
    }

}
