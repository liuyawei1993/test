/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.util;

import java.util.List;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月21日 下午7:25:05
 * 
 */

public class StringCommonUtils {

    /**
     * @param ip
     *            将String型IP转成long
     * @return
     */
    public static Long ipToNumber(String ip) {
	Long ips = 0L;
	String[] numbers = ip.split("\\.");
	for (int i = 0; i < 4; ++i) {
	    ips = ips << 8 | Integer.parseInt(numbers[i]);
	}
	return ips;
    }

    /**
     * @param list
     * @param separator
     *            分隔符 将List转成String用分隔符划分
     * @return
     */
    public static String listToString(List list, String separator) {
	StringBuilder sb = new StringBuilder();
	for (int i = 0; i < list.size(); i++) {
	    sb.append(list.get(i)).append(separator);
	}
	return sb.toString().substring(0, sb.toString().length() - 1);
    }

    /**
     * @param number
     *            将long类型IP转成String
     * @return
     */
    public static String numberToIp(Long number) {
	StringBuilder sb = new StringBuilder();
	// 直接右移24位
	sb.append(number >> 24);
	sb.append(".");
	// 将高8位置0，然后右移16
	sb.append((number & 0x00FFFFFF) >> 16);
	sb.append(".");
	// 将高16位置0，然后右移8位
	sb.append((number & 0x0000FFFF) >> 8);
	sb.append(".");
	// 将高24位置0
	sb.append((number & 0x000000FF));
	return sb.toString();
    }

}
