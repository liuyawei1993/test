package com.dp.serverrest.po;

public class AssetManagePo extends BasePo {
    private Integer id;

    private String ip;

    private String assetType;

    private Integer institutionalId;

    private String labelId;

    private String assetState;

    private String assetDiscovery;

    private Integer assetWeight;

    private String assetGroup;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip == null ? null : ip.trim();
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType == null ? null : assetType.trim();
    }

    public Integer getInstitutionalId() {
        return institutionalId;
    }

    public void setInstitutionalId(Integer institutionalId) {
        this.institutionalId = institutionalId;
    }

    public String getLabelId() {
        return labelId;
    }

    public void setLabelId(String labelId) {
        this.labelId = labelId == null ? null : labelId.trim();
    }

    public String getAssetState() {
        return assetState;
    }

    public void setAssetState(String assetState) {
        this.assetState = assetState == null ? null : assetState.trim();
    }

    public String getAssetDiscovery() {
        return assetDiscovery;
    }

    public void setAssetDiscovery(String assetDiscovery) {
        this.assetDiscovery = assetDiscovery == null ? null : assetDiscovery.trim();
    }

    public Integer getAssetWeight() {
        return assetWeight;
    }

    public void setAssetWeight(Integer assetWeight) {
        this.assetWeight = assetWeight;
    }

    public String getAssetGroup() {
        return assetGroup;
    }

    public void setAssetGroup(String assetGroup) {
        this.assetGroup = assetGroup == null ? null : assetGroup.trim();
    }
}