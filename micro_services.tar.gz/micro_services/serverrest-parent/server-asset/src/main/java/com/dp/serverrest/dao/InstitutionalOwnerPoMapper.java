package com.dp.serverrest.dao;

import java.util.List;

import com.dp.serverrest.po.InstitutionalOwnerPo;

public interface InstitutionalOwnerPoMapper extends BasePoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(InstitutionalOwnerPo record);

    int insertSelective(InstitutionalOwnerPo record);

    List<InstitutionalOwnerPo> selectByInstitutionalId(Integer id);

    InstitutionalOwnerPo selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(InstitutionalOwnerPo record);

    int updateByPrimaryKeySelective(InstitutionalOwnerPo record);
}