package com.dp.serverrest.dao;

import com.dp.serverrest.po.InstitutionalManagePo;

import java.util.List;

/**
 * @author chaozhang
 */
public interface InstitutionalManagePoMapper extends BasePoMapper {
    int deleteByPrimaryKey(Integer institutionalId);

    int insert(InstitutionalManagePo record);

    int insertSelective(InstitutionalManagePo record);

    InstitutionalManagePo selectByPrimaryKey(Integer institutionalId);

    List<InstitutionalManagePo> selectAll();

    int updateByPrimaryKeySelective(InstitutionalManagePo record);

    int updateByPrimaryKey(InstitutionalManagePo record);
}