package com.dp.serverrest.dao;

import com.dp.serverrest.po.AssetManagePo;

public interface AssetManagePoMapper extends BasePoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(AssetManagePo record);

    int insertSelective(AssetManagePo record);

    AssetManagePo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AssetManagePo record);

    int updateByPrimaryKey(AssetManagePo record);
}