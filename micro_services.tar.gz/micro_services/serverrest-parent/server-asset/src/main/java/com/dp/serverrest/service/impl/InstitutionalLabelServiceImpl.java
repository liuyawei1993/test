package com.dp.serverrest.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dp.serverrest.dao.InstitutionalGroupPoMapper;
import com.dp.serverrest.dao.InstitutionalLabelPoMapper;
import com.dp.serverrest.dao.InstitutionalManagePoMapper;
import com.dp.serverrest.dao.InstitutionalOwnerPoMapper;
import com.dp.serverrest.po.InstitutionalGroupPo;
import com.dp.serverrest.po.InstitutionalLabelPo;
import com.dp.serverrest.po.InstitutionalManagePo;
import com.dp.serverrest.po.InstitutionalOwnerPo;
import com.dp.serverrest.service.api.InstitutionalLabelService;
import com.dp.serverrest.service.util.CommonUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * @author chaozhang
 */
@Service
public class InstitutionalLabelServiceImpl implements InstitutionalLabelService {
    @Autowired
    private InstitutionalManagePoMapper institutionalManagePoMapper;
    @Autowired
    private InstitutionalOwnerPoMapper institutionalOwnerPoMapper;
    @Autowired
    private InstitutionalGroupPoMapper institutionalGroupPoMapper;
    @Autowired
    private InstitutionalLabelPoMapper institutionalLabelPoMapper;
    @Override
    public Map<String, String> addGroup(Integer id, InstitutionalGroupPo institutionalGroupPo) {
	institutionalGroupPo.setInstitutionalId(id);
	return CommonUtils.addData(institutionalGroupPo, institutionalGroupPoMapper);
    }

    @Override
    public Map<String, String> addInstitution(InstitutionalManagePo institutionalManagePo) {
        return CommonUtils.addData(institutionalManagePo,institutionalManagePoMapper);
    }

    @Override
    public Map<String, String> addLabel(InstitutionalLabelPo institutionalLabelPo) {
	return CommonUtils.addData(institutionalLabelPo, institutionalLabelPoMapper);
    }

    @Override
    public Map<String, String> addOwner(Integer id, InstitutionalOwnerPo institutionalOwnerPo) {
	institutionalOwnerPo.setInstitutionalId(id);
	return CommonUtils.addData(institutionalOwnerPo, institutionalOwnerPoMapper);
    }

    @Override
    public Map<String, String> deleteGroup(Integer id) {
	return CommonUtils.deleteData(id, institutionalGroupPoMapper);
    }

    @Override
    public Map<String, String> deleteInstitution(Integer id) {
	return CommonUtils.deleteData(id, institutionalManagePoMapper);
    }

    @Override
    public Map<String, String> deleteLabel(Integer id) {
	return CommonUtils.deleteData(id, institutionalLabelPoMapper);
    }

    @Override
    public Map<String, String> deleteOwner(Integer id) {
	return CommonUtils.deleteData(id, institutionalOwnerPoMapper);
    }

    @Override
    public List<InstitutionalGroupPo> getGroupList(Integer id) {
	return institutionalGroupPoMapper.selectByInstitutionalId(id);
    }

    @Override
    public List<InstitutionalManagePo> getInstitutionList() {
        return institutionalManagePoMapper.selectAll();
    }

    @Override
    public PageInfo<InstitutionalLabelPo> getLabelList(Integer page, Integer limit) {
        PageHelper.startPage(page, limit);
        return new PageInfo<InstitutionalLabelPo>(institutionalLabelPoMapper.selectAll());
    }

    @Override
    public List<InstitutionalOwnerPo> getOwnerList(Integer id) {
	return institutionalOwnerPoMapper.selectByInstitutionalId(id);
    }

    @Override
    public Map<String, String> modifyGroup(Integer institutionalId, Integer id,
	    InstitutionalGroupPo institutionalGroupPo) {
	institutionalGroupPo.setInstitutionalId(institutionalId);
	institutionalGroupPo.setGroupId(id);
	return CommonUtils.modifyData(id, institutionalGroupPo, institutionalGroupPoMapper);
    }

    @Override
    public Map<String, String> modifyLabel(Integer id, InstitutionalLabelPo institutionalLabelPo) {
	institutionalLabelPo.setLabelId(id);
	return CommonUtils.modifyData(id, institutionalLabelPo, institutionalLabelPoMapper);
    }

    @Override
    public Map<String, String> modifyOwner(Integer institutionalId, Integer id,
	    InstitutionalOwnerPo institutionalOwnerPo) {
	institutionalOwnerPo.setId(id);
	institutionalOwnerPo.setInstitutionalId(institutionalId);
	return CommonUtils.modifyData(id, institutionalOwnerPo, institutionalOwnerPoMapper);
    }
}
