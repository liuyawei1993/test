package com.dp.serverrest.dao;

import java.util.List;

import com.dp.serverrest.po.InstitutionalGroupPo;

/**
 * @author chaozhang
 */
public interface InstitutionalGroupPoMapper extends BasePoMapper {
    int deleteByPrimaryKey(Integer groupId);

    int insert(InstitutionalGroupPo record);

    int insertSelective(InstitutionalGroupPo record);

    List<InstitutionalGroupPo> selectByInstitutionalId(Integer id);

    InstitutionalGroupPo selectByPrimaryKey(Integer groupId);

    int updateByPrimaryKey(InstitutionalGroupPo record);

    int updateByPrimaryKeySelective(InstitutionalGroupPo record);
}