package com.dp.serverrest.po;

public class InstitutionalManagePo extends BasePo {
    private Integer institutionalId;

    private String institutionalName;

    private String institutionalType;

    private String institutionalLevel;

    private String institutionalNum;

    private String institutionalLocal;

    private String institutionalDesc;

    public Integer getInstitutionalId() {
        return institutionalId;
    }

    public void setInstitutionalId(Integer institutionalId) {
        this.institutionalId = institutionalId;
    }

    public String getInstitutionalName() {
        return institutionalName;
    }

    public void setInstitutionalName(String institutionalName) {
        this.institutionalName = institutionalName == null ? null : institutionalName.trim();
    }

    public String getInstitutionalType() {
        return institutionalType;
    }

    public void setInstitutionalType(String institutionalType) {
        this.institutionalType = institutionalType == null ? null : institutionalType.trim();
    }

    public String getInstitutionalLevel() {
        return institutionalLevel;
    }

    public void setInstitutionalLevel(String institutionalLevel) {
        this.institutionalLevel = institutionalLevel == null ? null : institutionalLevel.trim();
    }

    public String getInstitutionalNum() {
        return institutionalNum;
    }

    public void setInstitutionalNum(String institutionalNum) {
        this.institutionalNum = institutionalNum == null ? null : institutionalNum.trim();
    }

    public String getInstitutionalLocal() {
        return institutionalLocal;
    }

    public void setInstitutionalLocal(String institutionalLocal) {
        this.institutionalLocal = institutionalLocal == null ? null : institutionalLocal.trim();
    }

    public String getInstitutionalDesc() {
        return institutionalDesc;
    }

    public void setInstitutionalDesc(String institutionalDesc) {
        this.institutionalDesc = institutionalDesc == null ? null : institutionalDesc.trim();
    }
}