/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.po;
/** 
	* @author author zhangchao: 
	* @version 创建时间：2019年8月21日 下午5:08:28 
	* 
	*/

import java.util.List;

public class LabelManagePo extends BasePo {

    private List<GroupPo> groupList;
    private List<String> sensorIdList;

    public List<GroupPo> getGroupList() {
	return groupList;
    }

    public List<String> getSensorIdList() {
	return sensorIdList;
    }

    public void setGroupList(List<GroupPo> groupList) {
	this.groupList = groupList;
    }

    public void setSensorIdList(List<String> sensorIdList) {
	this.sensorIdList = sensorIdList;
    }
}
