package com.dp.serverrest;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author chaozhang
 *
 */
@SpringBootApplication
@EnableScheduling
@MapperScan("com.dp.serverrest.dao")
public class ServerRestApplication {

	public static void main(String[] args) {
	SpringApplication.run(ServerRestApplication.class, args);
	}
}
