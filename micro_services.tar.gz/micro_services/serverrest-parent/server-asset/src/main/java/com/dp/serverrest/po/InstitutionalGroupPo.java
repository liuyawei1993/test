package com.dp.serverrest.po;

public class InstitutionalGroupPo extends BasePo {
    private Integer groupId;

    private String name;

    private String groupDesc;

    private String assetType;

    private String assetRange;

    private Integer institutionalId;

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc == null ? null : groupDesc.trim();
    }

    public String getAssetType() {
        return assetType;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType == null ? null : assetType.trim();
    }

    public String getAssetRange() {
        return assetRange;
    }

    public void setAssetRange(String assetRange) {
        this.assetRange = assetRange == null ? null : assetRange.trim();
    }

    public Integer getInstitutionalId() {
        return institutionalId;
    }

    public void setInstitutionalId(Integer institutionalId) {
        this.institutionalId = institutionalId;
    }
}