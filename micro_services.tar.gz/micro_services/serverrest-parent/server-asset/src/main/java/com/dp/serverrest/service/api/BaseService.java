package com.dp.serverrest.service.api;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by zhangchao on 2019/8/30.
 */
public interface BaseService {
    Map<String, String> result = new HashMap<>();
}
