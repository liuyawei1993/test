/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.GroupPo;
import com.dp.serverrest.po.InstitutionalGroupPo;
import com.dp.serverrest.po.InstitutionalLabelPo;
import com.dp.serverrest.po.InstitutionalManagePo;
import com.dp.serverrest.po.InstitutionalOwnerPo;
import com.dp.serverrest.po.LabelManagePo;
import com.dp.serverrest.service.api.InstitutionalLabelService;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.service.util.PageUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月21日 下午5:01:25
 * 
 */
@RestController
@RequestMapping(value = "/stap/assetMonitorCenter/institutionalLabelManage")
public class InstitutionalLabelController {
    private class IpRangeVo {
	private long ipFrom;
	private long ipTo;

	public long getIpFrom() {
	    return ipFrom;
	}

	public long getIpTo() {
	    return ipTo;
	}

	public IpRangeVo setIpFrom(long ipFrom) {
	    this.ipFrom = ipFrom;
	    return this;
	}

	public IpRangeVo setIpTo(long ipTo) {
	    this.ipTo = ipTo;
	    return this;
	}
    }

    private static final Logger log = LoggerFactory.getLogger(InstitutionalLabelController.class);;

    @Autowired
    private InstitutionalLabelService institutionalLabelService;

    JedisPool jedisPool = new JedisPool(new JedisPoolConfig(), "10.121.62.109", 6379);

    /**
     * @param id
     *            新增机构分组的接口
     * @return
     */
    @RequestMapping(value = "{institutionalId}/group", method = RequestMethod.POST)
    public Map<String, String> addGroup(@PathVariable("institutionalId") Integer id,
	    @RequestBody InstitutionalGroupPo institutionalGroupPo) {
	return institutionalLabelService.addGroup(id, institutionalGroupPo);
    }

    /**
     * @param id
     *            新增机构的接口
     * @return
     */
    @RequestMapping(value = "institution", method = RequestMethod.POST)
    public Map<String, String> addInstitution(@RequestBody InstitutionalManagePo institutionalManagePo) {
	return institutionalLabelService.addInstitution(institutionalManagePo);
    }

    /**
     * @param id
     *            新增标签的接口
     * @return
     */
    @RequestMapping(value = "label", method = RequestMethod.POST)
    public Map<String, String> addLabel(@RequestBody InstitutionalLabelPo institutionalLabelPo) {
	return institutionalLabelService.addLabel(institutionalLabelPo);
    }

    /**
     * @param id
     *            新增机构责任人的接口
     * @return
     */
    @RequestMapping(value = "{institutionalId}/responsible", method = RequestMethod.POST)
    public Map<String, String> addOwner(@PathVariable("institutionalId") Integer id,
	    @RequestBody InstitutionalOwnerPo institutionalOwnerPo) {
	return institutionalLabelService.addOwner(id, institutionalOwnerPo);
    }

    /**
     * @param id
     *            删除机构分组的接口
     * @return
     */
    @RequestMapping(value = "group/{groupId}", method = RequestMethod.DELETE)
    public Map<String, String> deleteGroup(@PathVariable("groupId") Integer id) {
	return institutionalLabelService.deleteGroup(id);
    }

    /**
     * @param id
     * 删除机构的接口
     * @return
     */
    @RequestMapping(value = "institution/{institutionalId}", method = RequestMethod.DELETE)
    public Map<String, String> deleteInstitution(@PathVariable("institutionalId") Integer id) {
		return institutionalLabelService.deleteInstitution(id);
    }

    /**
     * @param id
     *            删除标签的接口
     * @return
     */
    @RequestMapping(value = "label/{labelId}", method = RequestMethod.DELETE)
    public Map<String, String> deleteLabel(@PathVariable("labelId") Integer id) {
	return institutionalLabelService.deleteLabel(id);
    }

    /**
     * @param id
     *            删除机构责任人的接口
     * @return
     */
    @RequestMapping(value = "responsible/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deleteOwner(@PathVariable("id") Integer id) {
	return institutionalLabelService.deleteOwner(id);
    }

    @RequestMapping(value = "aaa", method = RequestMethod.GET)
    public String getAlarmList() {
	Jedis jedis = jedisPool.getResource();
	LabelManagePo labelManageVo = new LabelManagePo();
	Set<Long> ipNodeSet = Sets.newConcurrentHashSet();
	Map<Object, Object> sensorValueMap = Maps.newHashMap();
	// 测试代码
	List<String> sensorIdList = Lists.newArrayList();
	sensorIdList.add("sensor1");
	sensorIdList.add("sensor2");
	List<GroupPo> aaa = Lists.newArrayList();
	List<String> bbb = Lists.newArrayList();
	bbb.add("1.1.1.1;1.1.1.5");
	bbb.add("1.1.1.4;1.1.1.7");
	List<String> bbb1 = Lists.newArrayList();
	bbb1.add("1.1.1.1;1.1.1.9");
	bbb1.add("1.1.1.4;1.1.1.20");
	bbb1.add("1.1.1.50;1.1.1.50");
	aaa.add(new GroupPo().setIpRangeList(bbb).setGroupName("bbb组"));
	aaa.add(new GroupPo().setIpRangeList(bbb1).setGroupName("test组"));
	labelManageVo.setGroupList(aaa);
	labelManageVo.setSensorIdList(sensorIdList);
	List<GroupPo> groupList = labelManageVo.getGroupList();
	// 分组内的ipRange合并
	for (GroupPo groupVo : groupList) {
	    List<IpRangeVo> ipRangeVoList = Lists.newArrayList();
	    List<String> ipRangeList = groupVo.getIpRangeList();
	    List<String> sortedIpList = Lists.newArrayList();
	    for (String ipRange : ipRangeList) {
		setIpRange(ipRange, ipRangeVoList);
	    }
	    for (IpRangeVo ipRangeVo : ipRangeVoList) {
		sortedIpList.add(new StringBuffer().append(ipRangeVo.getIpFrom()).append(";")
			.append(ipRangeVo.getIpTo()).toString());
	    }
	    groupVo.setIpRangeList(sortedIpList);
	}
	// 断点的分组断点的查询
	for (GroupPo groupVo : groupList) {
	    List<String> ipRangeList = groupVo.getIpRangeList();
	    for (String ipRange : ipRangeList) {
		long ipFrom = Long.valueOf(ipRange.split(";")[0]);
		long ipTo = Long.valueOf(ipRange.split(";")[1]);
		ipNodeSet.addAll(Arrays.asList(ipFrom - 1, ipFrom, ipFrom + 1, ipTo - 1, ipTo, ipTo + 1));
	    }
	}
	Set<Long> sortSet = new TreeSet<Long>(new Comparator<Long>() {
	    @Override
	    public int compare(Long o1, Long o2) {
		return o1.compareTo(o2);// 升序排列
	    }
	});
	sortSet.addAll(ipNodeSet);
	System.err.println(sortSet.toString());
	Long[] array = new Long[ipNodeSet.size()];
	sensorValueMap.put("ipList", sortSet.toArray(array));
	// ip中信息的分类
	for (Long ipNum : ipNodeSet) {
	    Map<Object, Object> subValue = Maps.newHashMap();
	    List<String> groupNameList = Lists.newArrayList();
	    for (GroupPo groupVo : groupList) {
		if (isInRange(ipNum, groupVo.getIpRangeList())) {
		    groupNameList.add(groupVo.getGroupName());
		}
	    }
	    if (groupNameList.size() == 0) {
		sensorValueMap.put(ipNum, null);
	    } else {
		subValue.put("groupName", CommonUtils.listToString(groupNameList, ";"));
		sensorValueMap.put(ipNum, subValue);
	    }
	}
	// 将组装好的数据分配给每个探针
	try {
	    for (String sensorId : labelManageVo.getSensorIdList()) {
		ByteArrayOutputStream ba = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(ba);
		oos.writeObject(sensorValueMap);
		oos.flush();
		jedis.set(sensorId.getBytes(), ba.toByteArray());
	    }
	    jedis.publish("mychannel", "sensorIp,");
	} catch (IOException e) {
	    e.printStackTrace();
	} finally {
	    jedis.close();
	}
	return "test";
    }

    /**
     * @param id
     *            获取机构分组列表的接口
     * @return
     */
    @RequestMapping(value = "{institutionalId}/group", method = RequestMethod.GET)
    public List<InstitutionalGroupPo> getGroupList(@PathVariable("institutionalId") Integer id) {
	return institutionalLabelService.getGroupList(id);
    }

    /**
     * @param id
     * 获取机构列表的接口
     * @return
     */
    @RequestMapping(value = "institution", method = RequestMethod.GET)
    public List<InstitutionalManagePo> getInstitutionList() {
	return institutionalLabelService.getInstitutionList();
    }

    /**
     * @param id
     *            获取标签列表的接口
     * @return
     */
    @RequestMapping(value = "label", method = RequestMethod.GET)
    public PageDTO<InstitutionalLabelPo> getLabelList(@RequestParam("page") Integer page,
	    @RequestParam("limit") Integer limit) {
	// 使用分页工具类处理查询到的结果集，封装成前端需要的数据
	PageUtils<InstitutionalLabelPo> userVoPageUtils = new PageUtils<>();

	PageDTO<InstitutionalLabelPo> userVoPageDTO = userVoPageUtils
		.pageUtil(institutionalLabelService.getLabelList(page, limit));
	return userVoPageDTO;
    }

    /**
     * @param id
     *            获取机构责任人列表的接口
     * @return
     */
    @RequestMapping(value = "{institutionalId}/responsible", method = RequestMethod.GET)
    public List<InstitutionalOwnerPo> getOwnerList(@PathVariable("institutionalId") Integer id) {
	return institutionalLabelService.getOwnerList(id);
    }
    private boolean isInRange(Long ipNum, List<String> ipRangeList) {
	for (String ipRange : ipRangeList) {
	    long ipFrom = Long.valueOf(ipRange.split(";")[0]);
	    long ipTo = Long.valueOf(ipRange.split(";")[1]);
	    if (ipNum >= ipFrom && ipNum <= ipTo) {
		return true;
	    }
	}
	return false;
    }

    /**
     * @param id 
     * 修改机构分组的接口
     * @return
     */
    @RequestMapping(value = "{institutionalId}/group/{groupId}", method = RequestMethod.PUT)
    public Map<String, String> modifyGroup(@PathVariable("institutionalId") Integer institutionalId,
	    @PathVariable("groupId") Integer id, @RequestBody InstitutionalGroupPo institutionalGroupPo) {
	return institutionalLabelService.modifyGroup(institutionalId, id, institutionalGroupPo);
    }

    /**
     * @param id
     *            修改标签的接口
     * @return
     */
    @RequestMapping(value = "label/{labelId}", method = RequestMethod.PUT)
    public Map<String, String> modifyLabel(@PathVariable("labelId") Integer id,
	    @RequestBody InstitutionalLabelPo institutionalLabelPo) {
	return institutionalLabelService.modifyLabel(id, institutionalLabelPo);
    }

    /**
     * @param id 
     * 修改机构责任人的接口
     * @return
     */
    @RequestMapping(value = "{institutionalId}/responsible/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyOwner(@PathVariable("institutionalId") Integer institutionalId,
	    @PathVariable("id") Integer id, @RequestBody InstitutionalOwnerPo institutionalOwnerPo) {
	return institutionalLabelService.modifyOwner(institutionalId, id, institutionalOwnerPo);
    }

    private void setIpRange(String ipRange, List<IpRangeVo> ipRangeVoList) {
	String[] ipRangeData = ipRange.split(";");
	long ipFrom = CommonUtils.ipToNumber(ipRangeData[0]);
	long ipTo = CommonUtils.ipToNumber(ipRangeData[1]);
	boolean flag = true;
	for (IpRangeVo ipRangeVo : ipRangeVoList) {
	    if (ipRangeVo.getIpFrom() > ipTo || ipRangeVo.getIpTo() < ipFrom) {
		continue;
	    } else {
		flag = false;
		List<Long> ipNodes = Arrays.asList(ipTo, ipFrom, ipRangeVo.getIpFrom(), ipRangeVo.getIpTo()).stream()
			.sorted().collect(Collectors.toList());
		ipRangeVoList.remove(ipRangeVo);
		ipRangeVoList.add(new IpRangeVo().setIpFrom(ipNodes.get(0)).setIpTo(ipNodes.get(ipNodes.size() - 1)));
	    }
	}
	if (flag) {
	    ipRangeVoList.add(new IpRangeVo().setIpFrom(ipFrom).setIpTo(ipTo));
	}
    }
}
