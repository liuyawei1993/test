package com.dp.serverrest.dao;

import java.util.List;

import com.dp.serverrest.po.InstitutionalLabelPo;

public interface InstitutionalLabelPoMapper extends BasePoMapper {
    int deleteByPrimaryKey(Integer labelId);

    int insert(InstitutionalLabelPo record);

    int insertSelective(InstitutionalLabelPo record);

    List<InstitutionalLabelPo> selectAll();

    InstitutionalLabelPo selectByPrimaryKey(Integer labelId);

    int updateByPrimaryKey(InstitutionalLabelPo record);

    int updateByPrimaryKeySelective(InstitutionalLabelPo record);
}