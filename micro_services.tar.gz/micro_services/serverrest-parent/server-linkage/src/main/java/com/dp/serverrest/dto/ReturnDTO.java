package com.dp.serverrest.dto;

import java.util.HashMap;

/**
 * @className: ReturnDTO
 * @description: 返回工具类
 * @author: yuanyubo
 * @create: 2019-09-02
 */
public class ReturnDTO extends HashMap<String, String> {

    public ReturnDTO() {
    }
    public static ReturnDTO error(String code, String msg) {
        ReturnDTO r = new ReturnDTO();
        r.put(code,msg);
        return r;
    }
    public static ReturnDTO ok(String code, String msg) {
        ReturnDTO r = new ReturnDTO();
        r.put(code,msg);
        return r;
    }
}
