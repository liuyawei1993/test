package com.dp.serverrest.dao;

import com.dp.serverrest.po.LinkageHistoryPo;

import java.util.List;

/**
 * @author yuanyubo
 * @apiNote 联动历史mapper
 */
public interface LinkageHistoryMapper extends BasePoMapper {

    /**
     * 根据主键删除联动历史
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 新增 联动历史
     * @param record
     * @return
     */
    int insert(LinkageHistoryPo record);

    /**
     * 新增 字段不为空的联动历史数据
     * @param record
     * @return
     */
    int insertSelective(LinkageHistoryPo record);

    /**
     * 根据ID查询 联动历史
     * @param id
     * @return
     */
    LinkageHistoryPo selectByPrimaryKey(Integer id);

    /**
     * 根据主键 更新数据不为空的联动历史数据
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(LinkageHistoryPo record);

    /**
     * 根据主键  全部更新联动历史数据
     * @param record
     * @return
     */
    int updateByPrimaryKey(LinkageHistoryPo record);

    /**
     * 查询自己操作的联动历史
     * @param userId
     * @return
     */
    List<LinkageHistoryPo> selectAllByUserId(Integer userId);
}