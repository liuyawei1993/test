package com.dp.serverrest.dto;

/**
 * @className: LinkageDTO
 * @description: 封装联动管理接收类
 * @author: yuanyubo
 * @create: 2019-09-02
 */
public class LinkageDTO {

    private String ip;

    private String threatLevel;

    private Long processTime;

    private Long validTime;

    private String linkageState;

    private String dangerTypes;

    private Byte isIgnore;

    private Byte operation;

    private Integer time;

    private Integer equipmentId;

    private Integer count;

    private String top3;

    private String userName;


    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getThreatLevel() {
        return threatLevel;
    }

    public void setThreatLevel(String threatLevel) {
        this.threatLevel = threatLevel;
    }

    public Long getProcessTime() {
        return processTime;
    }

    public void setProcessTime(Long processTime) {
        this.processTime = processTime;
    }

    public Long getValidTime() {
        return validTime;
    }

    public void setValidTime(Long validTime) {
        this.validTime = validTime;
    }

    public String getLinkageState() {
        return linkageState;
    }

    public void setLinkageState(String linkageState) {
        this.linkageState = linkageState;
    }

    public String getDangerTypes() {
        return dangerTypes;
    }

    public void setDangerTypes(String dangerTypes) {
        this.dangerTypes = dangerTypes;
    }

    public Byte getIsIgnore() {
        return isIgnore;
    }

    public void setIsIgnore(Byte isIgnore) {
        this.isIgnore = isIgnore;
    }

    public Byte getOperation() {
        return operation;
    }

    public void setOperation(Byte operation) {
        this.operation = operation;
    }

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }

    public Integer getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(Integer equipmentId) {
        this.equipmentId = equipmentId;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getTop3() {
        return top3;
    }

    public void setTop3(String top3) {
        this.top3 = top3;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public String toString() {
        return "LinkageDTO{" +
                "ip='" + ip + '\'' +
                ", threatLevel='" + threatLevel + '\'' +
                ", processTime=" + processTime +
                ", validTime=" + validTime +
                ", linkageState='" + linkageState + '\'' +
                ", dangerTypes='" + dangerTypes + '\'' +
                ", isIgnore=" + isIgnore +
                ", operation=" + operation +
                ", time=" + time +
                ", equipmentId=" + equipmentId +
                ", count=" + count +
                ", top3='" + top3 + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }
}
