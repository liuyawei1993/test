package com.dp.serverrest.dao;

import com.dp.serverrest.po.BasePo;

/**
 * @interfaceName: BaseVoMapper
 * @description:
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public interface BasePoMapper {

    /**
     * 公共新增方法
     *
     * @param record
     * @return
     */
    int insert(BasePo record);

    /**
     * 公共修改方法
     *
     * @param vo
     * @return
     */
    int updateByPrimaryKey(BasePo vo);

    /**
     * 公共修改方法
     *
     * @param vo
     * @return
     */
    int updateByPrimaryKeySelective(BasePo vo);

    /**
     * 公共删除方法
     *
     * @param id
     * @return
     */
    int deleteByPrimaryKey(int id);

}
