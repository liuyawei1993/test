package com.dp.serverrest.po;

/**
 * @author yuanyubo
 * @serial 联动设备实体类
 */
public class LinkageEquipmentPo extends BasePo {
    private Integer equipmentId;

    private String equipmentName;

    private Long equipmentTime;

    private String equipmentAddress;

    public Integer getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(Integer equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName == null ? null : equipmentName.trim();
    }

    public Long getEquipmentTime() {
        return equipmentTime;
    }

    public void setEquipmentTime(Long equipmentTime) {
        this.equipmentTime = equipmentTime;
    }

    public String getEquipmentAddress() {
        return equipmentAddress;
    }

    public void setEquipmentAddress(String equipmentAddress) {
        this.equipmentAddress = equipmentAddress == null ? null : equipmentAddress.trim();
    }
}