package com.dp.serverrest.service.api;

import com.dp.serverrest.po.LinkageManagerPo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @interfaceName: LinkageManagerService
 * @description: 联动管理 接口类
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public interface LinkageManagerService {

    /**
     * 新增 联动管理
     *
     * @param linkageManagerPo
     * @return
     */
    public Map<String, String> addLinkageManager(LinkageManagerPo linkageManagerPo);

    /**
     * 新增 忽略 联动管理
     *
     * @param linkageManagerPo
     * @return
     */
    public Map<String, String> addLinkageIgnore(LinkageManagerPo linkageManagerPo);

    /**
     * 修改 联动管理
     *
     * @param ip
     * @param linkageManagerPo
     * @return
     */
    public Map<String, String> modifyLinkageManager(String ip, LinkageManagerPo linkageManagerPo);

    /**
     * 主动设置 处置失效
     * @param ip
     * @return
     */
    public Map<String, String> modifyInvalidation(String ip);

    /**
     * 根据主键 删除 联动管理
     *
     * @param ip
     * @return
     */
    public Map<String, String> deleteLinkageManager(String ip);

    /**
     * 分页查询 已处置 联动管理
     *
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<LinkageManagerPo> getLinkageManagerPage(int page, int limit);

    /**
     * 分页查询 已忽略
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<LinkageManagerPo> getLinkageManagerPageIgnore(int page, int limit) ;

    /**
     * 根据主键 查询联动管理
     *
     * @param ip
     * @return
     */
    LinkageManagerPo selectByPrimaryKey(String ip);

}
