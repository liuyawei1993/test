package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.LinkageHistoryMapper;
import com.dp.serverrest.dao.LinkageManagerMapper;
import com.dp.serverrest.dto.ReturnDTO;
import com.dp.serverrest.service.api.LinkageManagerService;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.LinkageManagerPo;
import com.dp.serverrest.service.util.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @className: LinkageManagerServiceImpl
 * @description: 联动管理实现类
 * @author: yuanyubo
 * @create: 2019-08-27
 */
@Service
public class LinkageManagerServiceImpl implements LinkageManagerService {

    @Autowired
    private LinkageManagerMapper dao;

    @Autowired
    private LinkageHistoryMapper linkageHistoryMapper;

    /**
     * 添加 联动管理
     *
     * @param linkageManagerPo
     * @return
     */
    @Override
    public Map<String, String> addLinkageManager(LinkageManagerPo linkageManagerPo) {

        //1.添加联动管理的时候，添加联动时间和过期时间
        linkageManagerPo.setProcessTime(TimeUtils.getCurrentTime());
        linkageManagerPo.setValidTime(TimeUtils.addHour(linkageManagerPo.getTime()));

        //2.判断是否忽略
        if (linkageManagerPo.getIgnore() != null) {
            linkageManagerPo.setLinkageState("已忽略");
        } else {
            //2.添加(修改)联动管理状态为：“已处置”
            linkageManagerPo.setLinkageState("已处置");
        }
        return CommonUtils.addData(linkageManagerPo, dao);
    }

    /**
     * 新增 忽略 联动管理
     *
     * @param linkageManagerPo
     * @return
     */
    @Override
    public Map<String, String> addLinkageIgnore(LinkageManagerPo linkageManagerPo) {
        return CommonUtils.addData(linkageManagerPo, dao);
    }

    /**
     * 修改联动状态
     *
     * @param ip
     * @param linkageManagerPo
     * @return
     */
    @Override
    public Map<String, String> modifyLinkageManager(String ip, LinkageManagerPo linkageManagerPo) {
        linkageManagerPo.setIp(ip);

        //使用时间工具类获取时间
        linkageManagerPo.setProcessTime(TimeUtils.getCurrentTime());
        linkageManagerPo.setValidTime(TimeUtils.addHour(linkageManagerPo.getTime()));
        linkageManagerPo.setLinkageState("已处置");

        int i = dao.updateByPrimaryKey(linkageManagerPo);
        HashMap<String, String> stringObjectHashMap = new HashMap<>(16);
        if (i == 1) {
            stringObjectHashMap.put("success", "modify success!");
        } else {
            stringObjectHashMap.put("err", "modify err!check it!");
        }
        return stringObjectHashMap;
    }

    /**
     * 主动设置 处置失效
     *
     * @param ip
     * @return
     */
    @Override
    public Map<String, String> modifyInvalidation(String ip) {
        LinkageManagerPo linkageManagerPo = new LinkageManagerPo();
        linkageManagerPo.setValidTime(TimeUtils.getCurrentTime());
        linkageManagerPo.setIp(ip);

        int i = dao.updateByPrimaryKeySelective(linkageManagerPo);
        if(i==1){
            return ReturnDTO.ok("success","处置已失效");
        }else {
            return ReturnDTO.error("err","处置异常");
        }
    }


    @Override
    public Map<String, String> deleteLinkageManager(String ip) {
        return null;
    }

    /**
     * 根据联动状态查询出联动信息
     *
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<LinkageManagerPo> getLinkageManagerPage(int page, int limit) {
        PageHelper.startPage(page, limit);
        LinkageManagerPo linkageManagerPo = new LinkageManagerPo();
        linkageManagerPo.setLinkageState("已处置");
        return new PageInfo<LinkageManagerPo>(dao.selectAll(linkageManagerPo));
    }

    /**
     * 查询已忽略
     *
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<LinkageManagerPo> getLinkageManagerPageIgnore(int page, int limit) {
        PageHelper.startPage(page, limit);
        LinkageManagerPo linkageManagerPo = new LinkageManagerPo();
        linkageManagerPo.setLinkageState("已忽略");
        return new PageInfo<LinkageManagerPo>(dao.selectAll(linkageManagerPo));
    }

    /**
     * 根据主键 查询联动管理
     *
     * @param ip
     * @return
     */
    @Override
    public LinkageManagerPo selectByPrimaryKey(String ip) {
        return dao.selectByPrimaryKey(ip);
    }
}
