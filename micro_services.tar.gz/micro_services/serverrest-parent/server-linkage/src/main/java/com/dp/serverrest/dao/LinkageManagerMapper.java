package com.dp.serverrest.dao;

import com.dp.serverrest.po.LinkageManagerPo;

import java.util.List;

/**
 * @author yuanyubo
 * @apiNote 联动管理mapper
 */
public interface LinkageManagerMapper extends BasePoMapper {

    /**
     * 根据主键 删除联动管理数据
     * @param ip
     * @return
     */
    int deleteByPrimaryKey(String ip);

    /**
     * 新增 联动管理
     * @param record
     * @return
     */
    int insert(LinkageManagerPo record);

    /**
     * 新增字段不为空的 联动管理
     * @param record
     * @return
     */
    int insertSelective(LinkageManagerPo record);

    /**
     * 根据主键 查询联动管理
     * @param ip
     * @return
     */
    LinkageManagerPo selectByPrimaryKey(String ip);

    /**
     * 根据主键更新字段不为空的 联动管理
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(LinkageManagerPo record);

    /**
     * 根据主键 更新全部的 联动管理
     * @param record
     * @return
     */
    int updateByPrimaryKey(LinkageManagerPo record);

    /**
     * 根据状态查询出管理信息
     * @param linkageManagerPo
     * @return
     */
    List<LinkageManagerPo> selectAll(LinkageManagerPo linkageManagerPo);
}