package com.dp.serverrest.controller;

import com.dp.serverrest.dto.LinkageDTO;
import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.service.api.LinkageEquipmentService;
import com.dp.serverrest.service.api.LinkageHistoryService;
import com.dp.serverrest.service.api.LinkageManagerService;
import com.dp.serverrest.service.util.PageUtils;
import com.dp.serverrest.po.LinkageEquipmentPo;
import com.dp.serverrest.po.LinkageHistoryPo;
import com.dp.serverrest.po.LinkageManagerPo;
import com.dp.serverrest.service.util.TimeUtils;
import com.github.pagehelper.PageInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @className: LinkageManagerController
 * @description: 联动管理 接口
 * @author: yuanyubo
 * @create: 2019-08-27
 */
@RestController
@RequestMapping(value = "/stap/linkageManager")
public class LinkageManagerController {


    @Autowired
    private LinkageEquipmentService linkageEquipmentService;

    @Autowired
    private LinkageHistoryService linkageHistoryService;

    @Autowired
    private LinkageManagerService linkageManagerService;


    //=================联动设备管理==========================

    /**
     * 添加联动设备
     *
     * @param linkageEquipmentPo
     * @return
     */
    @PostMapping("/equipment/equipment")
    public Map<String, String> addLinkageEquipment(@RequestBody LinkageEquipmentPo linkageEquipmentPo, HttpServletRequest request) {

        return linkageEquipmentService.addLinkageEquipment(linkageEquipmentPo);
    }

    /**
     * 修改联动设备
     *
     * @return
     */
    @PutMapping("/equipment/equipment/{id}")
    public Map<String, String> modifyLinkageEquipment(@PathVariable int id, @RequestBody LinkageEquipmentPo linkageEquipmentPo) {
        return linkageEquipmentService.modifyLinkageEquipment(id, linkageEquipmentPo);
    }

    /**
     * 删除联动设备
     *
     * @param id
     * @return
     */
    @DeleteMapping("/equipment/equipment/{id}")
    public Map<String, String> deleteLinkageEquipment(@PathVariable int id) {
        return linkageEquipmentService.deleteLinkageEquipment(id);
    }

    /**
     * 分页查询联动设备
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/equipment/equipment")
    public Map<String, Object> getLinkageEquipmentPage(int page, int limit) {

        //使用分页工具类处理查询到的结果集，封装成前端需要的数据
        PageUtils<LinkageEquipmentPo> linkageEquipmentPageUtils = new PageUtils<>();
        PageDTO<LinkageEquipmentPo> linkageEquipmentPageDTO = linkageEquipmentPageUtils.pageUtil(linkageEquipmentService.getLinkageEquipmentPage(page, limit));

        //根据接口文档对返回数据格式进行处理
        HashMap<String, Object> stringObjectHashMap = new HashMap<>(16);
        stringObjectHashMap.put("total", linkageEquipmentPageDTO.getTotal());
        stringObjectHashMap.put("tableData", linkageEquipmentPageDTO.getTableData());
        return stringObjectHashMap;
    }

    /**
     * 获取全部的联动设备
     *
     * @return
     */
    @GetMapping("/equipment/equipment/all")
    public List<LinkageEquipmentPo> getLinkageEquipmentAll() {
        return linkageEquipmentService.getLinkageEquipmentAll();
    }


    //=======================联动历史管理=============================

    /**
     * 根据ID删除联动日志
     *
     * @param id
     * @return
     */
    @DeleteMapping("/history/history/{id}")
    public Map<String, String> deleteHistory(@PathVariable int id) {
        return linkageHistoryService.deleteLinkageHistory(id);
    }

    /**
     * 分页查询 联动日志
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/history/history")
    public PageDTO<LinkageHistoryPo> selectHistoryPage(int page, int limit,HttpServletRequest request) {
        Integer userId = (Integer) request.getSession().getAttribute("userId");
        PageUtils<LinkageHistoryPo> linkageHistoryPageUtils = new PageUtils<>();
        PageDTO<LinkageHistoryPo> linkageHistoryPageDTO = linkageHistoryPageUtils.pageUtil(linkageHistoryService.getLinkageHistoryPage(page, limit,userId));
        return linkageHistoryPageDTO;
    }


    //======================联动管理===============================

    /**
     * 添加联动管理 ----> 执行联动处置
     *
     * @param linkageManagerDTO
     * @return
     */
    @PatchMapping("/manager/{ip}")
    public Map<String, String> addLinkageManager123(@PathVariable String ip, @RequestBody LinkageDTO linkageManagerDTO,HttpServletRequest request) {

        Integer userId = (Integer) request.getSession().getAttribute("userId");

        if (linkageManagerDTO.getIsIgnore() == null) {
            //1.从session中获取用户名
            String useName = linkageManagerDTO.getUserName();
            //通过ID获取联动设备名称
            LinkageEquipmentPo linkageEquipmentPo = linkageEquipmentService.selectByPrimaryKey(linkageManagerDTO.getEquipmentId());
            LinkageHistoryPo linkageHistoryPo = new LinkageHistoryPo();

            //2.更新最近联动时间
            linkageEquipmentPo.setEquipmentTime(TimeUtils.getCurrentTime());
            linkageEquipmentService.updateByPrimaryKeySelective(linkageEquipmentPo);

            LinkageManagerPo linkageManagerPo = new LinkageManagerPo();
            //3.将数据从封装类中取出
            linkageManagerPo.setIp(ip);
            linkageManagerPo.setCount(linkageManagerDTO.getCount());
            linkageManagerPo.setDangerTypes(linkageManagerDTO.getDangerTypes());
            linkageManagerPo.setEquipmentId(linkageManagerDTO.getEquipmentId());
            linkageManagerPo.setTime(linkageManagerDTO.getTime());
            linkageManagerPo.setIgnore(linkageManagerDTO.getIsIgnore());
            linkageManagerPo.setOperation(linkageManagerDTO.getOperation());
            linkageManagerPo.setThreatLevel(linkageManagerDTO.getThreatLevel());
            linkageManagerPo.setTop3(linkageManagerDTO.getTop3());

            //4.判断数据库中是否有同一IP的数据，如果没有则为“未处置”数据首次处置，如果有数据，则为已处置数据”重新处置“
            if (linkageManagerService.selectByPrimaryKey(ip) != null) {

                Map<String, String> stringStringMap = linkageManagerService.modifyLinkageManager(ip, linkageManagerPo);
                //5.添加处置日志
                linkageHistoryPo.setProcessTime(TimeUtils.getCurrentTime());
                linkageHistoryPo.setEquipmentName(linkageEquipmentPo.getEquipmentName());
                linkageHistoryPo.setProcessTarget(ip);
                linkageHistoryPo.setOperationUser(useName);
                linkageHistoryPo.setUserId(userId);
                //判断是否处置成功
                if (stringStringMap.containsKey("success")) {
                    linkageHistoryPo.setContent("重新处置");
                } else {
                    linkageHistoryPo.setContent("重新处置失败");
                }
                linkageHistoryService.insert(linkageHistoryPo);

                return stringStringMap;
            } else {
                Map<String, String> stringStringMap = linkageManagerService.addLinkageManager(linkageManagerPo);

                //5.添加处置日志
                linkageHistoryPo.setProcessTime(TimeUtils.getCurrentTime());
                linkageHistoryPo.setEquipmentName(linkageEquipmentPo.getEquipmentName());
                linkageHistoryPo.setProcessTarget(ip);
                linkageHistoryPo.setOperationUser(useName);
                linkageHistoryPo.setUserId(userId);
                //判断是否处置成功
                if (stringStringMap.containsKey("success")) {
                    linkageHistoryPo.setContent("已处置");
                } else {
                    linkageHistoryPo.setContent("处置失败");
                }
                linkageHistoryService.insert(linkageHistoryPo);
                return stringStringMap;
            }
        } else {
            //处理忽略操作 数据库中没有数据，直接保存忽略信息
            LinkageManagerPo linkageManagerPo = new LinkageManagerPo();
            linkageManagerPo.setIp(ip);
            linkageManagerPo.setLinkageState("已忽略");
            linkageManagerPo.setProcessTime(TimeUtils.getCurrentTime());
            return linkageManagerService.addLinkageIgnore(linkageManagerPo);
        }
    }

    /**
     * 查询已处置联动管理
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping(value = "/manager/processed")
    public PageDTO<LinkageManagerPo> getLinkageManager(@Param("page") Integer page,
                                                       @Param("limit") Integer limit) {
        PageUtils<LinkageManagerPo> linkageHistoryPageUtils = new PageUtils<>();
        PageDTO<LinkageManagerPo> linkageHistoryPageDTO = linkageHistoryPageUtils.pageUtil(linkageManagerService.getLinkageManagerPage(page, limit));
        return linkageHistoryPageDTO;
    }

    /**
     * 查询 已忽略
     * @param page
     * @param limit
     * @return
     */
    @GetMapping(value = "/manager/ignore")
    public PageDTO<LinkageManagerPo> getLinkageManagerIgnore(@Param("page") Integer page,
                                                             @Param("limit") Integer limit) {
        PageUtils<LinkageManagerPo> linkageHistoryPageUtils = new PageUtils<>();
        PageDTO<LinkageManagerPo> linkageHistoryPageDTO = linkageHistoryPageUtils.pageUtil(linkageManagerService.getLinkageManagerPageIgnore(page, limit));
        return linkageHistoryPageDTO;
    }

    /**
     * 主动设置 处置失效
     * @param ip
     * @return
     */
    @PutMapping(value = "/manager/invalidation/{ip}")
    public Map<String,String> invalidation(@PathVariable String ip ){
        return linkageManagerService.modifyInvalidation(ip);
    }




}
