package com.dp.serverrest.po;

/**
 * @author yuanyubo
 * @serial 联动历史实体类
 */
public class LinkageHistoryPo extends BasePo {
    private Integer id;

    private String equipmentName;

    private String processTarget;

    private String operationUser;

    private Long processTime;
    private String content;
    private Integer userId;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName == null ? null : equipmentName.trim();
    }

    public String getProcessTarget() {
        return processTarget;
    }

    public void setProcessTarget(String processTarget) {
        this.processTarget = processTarget == null ? null : processTarget.trim();
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser == null ? null : operationUser.trim();
    }

    public Long getProcessTime() {
        return processTime;
    }

    public void setProcessTime(Long processTime) {
        this.processTime = processTime;
    }
}