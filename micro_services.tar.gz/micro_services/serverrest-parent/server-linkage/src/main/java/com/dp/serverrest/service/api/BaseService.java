package com.dp.serverrest.service.api;

import java.util.HashMap;
import java.util.Map;

/**
 * @interfaceName: BaseService
 * @description: 公共接口
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public interface BaseService {
    Map<String, String> RESULT = new HashMap<>();
}
