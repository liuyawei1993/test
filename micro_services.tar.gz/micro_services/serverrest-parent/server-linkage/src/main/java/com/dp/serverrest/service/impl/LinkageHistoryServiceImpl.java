package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.LinkageHistoryMapper;
import com.dp.serverrest.service.api.LinkageHistoryService;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.LinkageHistoryPo;
import com.dp.serverrest.service.util.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;

/**
 * @className: LinkageHistoryServiceImpl
 * @description: 联动历史实现类
 * @author: yuanyubo
 * @create: 2019-08-27
 */
@Service
public class LinkageHistoryServiceImpl implements LinkageHistoryService {

    @Autowired
    private LinkageHistoryMapper dao;

    /**
     * 搜集联动日志
     * @param linkageHistoryPo
     * @return
     */
    @Override
    public Map<String, String> addLinkageHistory(LinkageHistoryPo linkageHistoryPo) {

        linkageHistoryPo.setProcessTime(TimeUtils.getCurrentTime());
        return CommonUtils.addData(linkageHistoryPo,dao);
    }

    /**
     * 删除联动日志
     * @param id
     * @return
     */
    @Override
    public Map<String, String> deleteLinkageHistory(int id) {
        return CommonUtils.deleteData(id,dao);
    }

    /**
     * 分页查看联动日志
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<LinkageHistoryPo> getLinkageHistoryPage(int page, int limit,Integer userId) {
        PageHelper.startPage(page, limit);
        return new PageInfo<LinkageHistoryPo>(dao.selectAllByUserId(userId));
    }

    /**
     * 新增 联动历史
     *
     * @param record
     * @return
     */
    @Override
    public int insert(LinkageHistoryPo record) {
        return dao.insert(record);
    }
}
