package com.dp.serverrest.service.impl;

import ch.qos.logback.core.util.TimeUtil;
import com.dp.serverrest.dao.LinkageEquipmentMapper;
import com.dp.serverrest.dto.ReturnDTO;
import com.dp.serverrest.service.api.LinkageEquipmentService;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.LinkageEquipmentPo;
import com.dp.serverrest.service.util.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @className: LinkageEquipmentImpl
 * @description: 联动设备实现类
 * @author: yuanyubo
 * @create: 2019-08-27
 */
@Service
public class LinkageEquipmentServiceImpl implements LinkageEquipmentService {

    @Autowired
    private LinkageEquipmentMapper dao;

    /**
     * 添加联动设备
     * @param linkageEquipmentPo
     * @return
     */
    @Override
    public Map<String, String> addLinkageEquipment(LinkageEquipmentPo linkageEquipmentPo) {
        linkageEquipmentPo.setEquipmentTime(TimeUtils.getCurrentTime());
        return CommonUtils.addData(linkageEquipmentPo,dao);
    }

    /**
     * 修改联动设备
     * @param id
     * @param linkageEquipmentPo
     * @return
     */
    @Override
    public Map<String, String> modifyLinkageEquipment(int id, LinkageEquipmentPo linkageEquipmentPo) {
        linkageEquipmentPo.setEquipmentId(id);
        int i = dao.updateByPrimaryKeySelective(linkageEquipmentPo);
        if(i==1){
            return ReturnDTO.ok("success","修改成功");
        }else {
            return ReturnDTO.error("err","修改异常");
        }
    }

    /**
     * 删除联动设备
     * @param id
     * @return
     */
    @Override
    public Map<String, String> deleteLinkageEquipment(int id) {
        return CommonUtils.deleteData(id,dao);
    }

    /**
     * 分页查询联动设备
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<LinkageEquipmentPo> getLinkageEquipmentPage(int page, int limit) {
        PageHelper.startPage(page,limit);
        return new PageInfo<LinkageEquipmentPo>(dao.selectAll());
    }

    /**
     * 不分页查询全部的联动设备
     * @return
     */
    @Override
    public List<LinkageEquipmentPo> getLinkageEquipmentAll() {
        return dao.selectAll();
    }

    /**
     * 根据主键 查询联动设备信息
     *
     * @param equipmentId
     * @return
     */
    @Override
    public LinkageEquipmentPo selectByPrimaryKey(Integer equipmentId) {
        return  dao.selectByPrimaryKey(equipmentId);
    }

    /**
     * 根据主键信息更新联动设备
     *
     * @param record
     * @return
     */
    @Override
    public int updateByPrimaryKeySelective(LinkageEquipmentPo record) {

        return dao.updateByPrimaryKeySelective(record);
    }
}
