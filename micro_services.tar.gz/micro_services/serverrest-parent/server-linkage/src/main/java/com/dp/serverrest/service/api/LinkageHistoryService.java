package com.dp.serverrest.service.api;

import com.dp.serverrest.po.LinkageHistoryPo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @interfaceName: LinkageHistoryService
 * @description: 联动历史接口类
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public interface LinkageHistoryService {

    /**
     * 新增 联动历史数据
     * @param linkageHistoryPo
     * @return
     */
    public Map<String, String> addLinkageHistory(LinkageHistoryPo linkageHistoryPo);

    /**
     * 根据主键 删除联动ID
     * @param id
     * @return
     */
    public Map<String, String> deleteLinkageHistory(int id);

    /**
     * 分页查询联动历史数据
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<LinkageHistoryPo> getLinkageHistoryPage(int page, int limit,Integer userId);

    /**
     * 新增 联动历史
     * @param record
     * @return
     */
    int insert(LinkageHistoryPo record);

}
