package com.dp.serverrest.dto;

import java.util.List;

/**
 * @className: PageDTO
 * @description: 分页查询返回结果集
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public class PageDTO<T> {

    /**
     * 查询总数
     */
    private Long total;

    /**
     * 当前页码
     */
    private Integer pageNum;

    /**
     * 每页数量
     */
    private Integer pageSize;

    /**
     * 返回结果集
     */
    private List<T> tableData;


    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<T> getTableData() {
        return tableData;
    }

    public void setTableData(List<T> tableData) {
        this.tableData = tableData;
    }

    @Override
    public String toString() {
        return "PageDTO{" +
                "total=" + total +
                ", pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                ", tableData=" + tableData +
                '}';
    }

}
