package com.dp.serverrest.service.api;

import com.dp.serverrest.po.LinkageEquipmentPo;
import com.github.pagehelper.PageInfo;

import java.util.List;
import java.util.Map;

/**
 * @interfaceName: LinkageEquipmentService
 * @description: 联动设备接口
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public interface LinkageEquipmentService {

    /**
     * 新增 联动设备
     * @param linkageEquipmentPo
     * @return
     */
    public Map<String, String> addLinkageEquipment(LinkageEquipmentPo linkageEquipmentPo);

    /**
     * 根据主键更新联动设备信息
     * @param id
     * @param linkageEquipmentPo
     * @return
     */
    public Map<String, String> modifyLinkageEquipment(int id, LinkageEquipmentPo linkageEquipmentPo);

    /**
     * 根据主键删除联动设备信息
     * @param id
     * @return
     */
    public Map<String, String> deleteLinkageEquipment(int id);

    /**
     * 分页查询联动设备
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<LinkageEquipmentPo> getLinkageEquipmentPage(int page, int limit);

    /**
     * 不分页 查询所有的联动设备
     * @return
     */
    public List<LinkageEquipmentPo> getLinkageEquipmentAll();

    /**
     * 根据主键 查询联动设备信息
     * @param equipmentId
     * @return
     */
    LinkageEquipmentPo selectByPrimaryKey(Integer equipmentId);

    /**
     * 根据主键信息更新联动设备
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(LinkageEquipmentPo record);


}
