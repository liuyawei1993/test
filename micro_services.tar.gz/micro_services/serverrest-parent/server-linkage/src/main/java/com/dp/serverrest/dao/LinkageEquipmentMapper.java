package com.dp.serverrest.dao;

import com.dp.serverrest.po.LinkageEquipmentPo;

import java.util.List;

/**
 * @author yuanyubo
 * @apiNote 联动设备mapper
 */
public interface LinkageEquipmentMapper extends BasePoMapper {

    /**
     * 根据ID删除联动设备
     * @param equipmentId
     * @return
     */
    int deleteByPrimaryKey(Integer equipmentId);

    /**
     * 新增数据
     * @param record
     * @return
     */
    int insert(LinkageEquipmentPo record);

    /**
     * 新增有数据的字段
     * @param record
     * @return
     */
    int insertSelective(LinkageEquipmentPo record);

    /**
     * 根据ID查询数据
     * @param equipmentId
     * @return
     */
    LinkageEquipmentPo selectByPrimaryKey(Integer equipmentId);

    /**
     * 根据主键更新不为空的字段
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(LinkageEquipmentPo record);

    /**
     * 根据主键更新所有字段
     * @param record
     * @return
     */
    int updateByPrimaryKey(LinkageEquipmentPo record);

    /**
     * 查询全部数据
     * @return
     */
    List<LinkageEquipmentPo> selectAll();

}