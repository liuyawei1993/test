package com.dp.serverrest.service.util;

import java.util.Map;

import com.dp.serverrest.dao.BasePoMapper;
import com.dp.serverrest.po.BasePo;
import com.google.common.collect.Maps;

/**
 * @className: CommonUtils
 * @description: 公共方法类
 * @author: yuanyubo
 * @create: 2019-08-27
 */
public class CommonUtils {


    /**
     * @param dao
     * 新增的通用方法
     * @return
     */
    public static Map<String, String> addData(BasePo vo,BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        try {
            dao.insert(vo);
            result.put("success", "add success!");
        } catch (Exception e) {
            result.put("err", "add err!check it!");
        }
        return result;
    }

    /**
     * @param id
     * @param dao
     * 删除的通用方法
     * @return
     */
    public static Map<String, String> deleteData(int id, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.deleteByPrimaryKey(id);
        if (res > 0) {
            result.put("success", "delete success!");
        } else {
            result.put("err", "delete err!check it!");
        }
        return result;
    }

    /**
     * @param dao
     * 修改的通用方法
     * @return
     */
    public static Map<String, String> modifyData(Integer id, BasePo vo, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.updateByPrimaryKey(vo);
        if (res > 0) {
            result.put("success", "modify success!");
        } else {
            result.put("err", "modify err!check it!");
        }
        return result;
    }

    /**
     * 通用修改 字段不为空
     * @param id
     * @param vo
     * @param dao
     * @return
     */
    public static Map<String, String> modifyDataSelective(Integer id, BasePo vo, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.updateByPrimaryKeySelective(vo);
        if (res > 0) {
            result.put("success", "modify success!");
        } else {
            result.put("err", "modify err!check it!");
        }
        return result;
    }

}
