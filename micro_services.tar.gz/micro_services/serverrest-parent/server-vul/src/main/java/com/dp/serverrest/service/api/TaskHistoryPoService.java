package com.dp.serverrest.service.api;

import com.dp.serverrest.po.TaskHistoryPo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @interfaceName: TaskHistoryPoService
 * @description: 任务历史service接口
 * @author: yuanyubo
 * @create: 2019-08-30
 */
public interface TaskHistoryPoService {

    /**
     * 新增 任务历史
     * @param taskHistoryPo
     * @return
     */
    public Map<String, String> addTaskHistoryPo(TaskHistoryPo taskHistoryPo);

   /**
     * 删除 任务历史
     * @param id
     * @return
     */
    public Map<String, String> deleteTaskHistoryPo(int id);

    /**
     * 分页查询 任务历史
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<TaskHistoryPo> getVulTaskHistoryPo(int page, int limit);

}
