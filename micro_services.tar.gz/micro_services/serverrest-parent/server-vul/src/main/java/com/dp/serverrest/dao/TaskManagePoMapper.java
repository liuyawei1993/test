package com.dp.serverrest.dao;

import com.dp.serverrest.po.TaskManagePo;

import java.util.List;

/**
 * @author yuanyubo
 * @apiNote 历史任务接口
 */
public interface TaskManagePoMapper extends BasePoMapper {

    /**
     * 根据主键进行删除
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 添加任务管理
     * @param record
     * @return
     */
    int insert(TaskManagePo record);

    /**
     * 非空字段添加
     * @param record
     * @return
     */
    int insertSelective(TaskManagePo record);

    /**
     * 根据主键查询任务管理
     * @param id
     * @return
     */
    TaskManagePo selectByPrimaryKey(Integer id);

    /**
     * 根据非空字段进行任务管理更新
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(TaskManagePo record);

    /**
     * 根据主键进行数据更新
     * @param record
     * @return
     */
    int updateByPrimaryKey(TaskManagePo record);

    /**
     * 根据ID获取 任务状态
     * @param id
     * @return
     */
    Integer getTaskStatus(Integer id);

    /**
     * 查询全部任务信息 用于分页查询
     * @return
     */
    List<TaskManagePo> selectAll();
}