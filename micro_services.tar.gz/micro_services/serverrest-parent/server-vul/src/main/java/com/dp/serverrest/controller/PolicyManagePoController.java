package com.dp.serverrest.controller;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.dto.VulPolicyPoDTO;
import com.dp.serverrest.po.PolicyManagePo;
import com.dp.serverrest.service.api.PolicyManagePoService;
import com.dp.serverrest.service.util.PageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @className: PolicyManageController
 * @description: 漏洞------>策略管理接口
 *      加前缀vul防止与system模块的策略接口类名冲突
 * @author: yuanyubo
 * @create: 2019-08-30
 */
@RestController
@RequestMapping("/stap/vulAnalysis/strategyManager")
public class PolicyManagePoController {

    @Autowired
    private PolicyManagePoService policyManagePoService;

    /**
     * 新增 策略 接口
     * 使用DTO进行数据接收
     * @param vulPolicyPoDTO
     * @return
     */
    @PostMapping("/strategy")
    public Map<String, String> addStrategy(@RequestBody VulPolicyPoDTO vulPolicyPoDTO) {

        //将数据转移到java bean
        PolicyManagePo vulPolicyPo = new PolicyManagePo();
        vulPolicyPo.setDesc(vulPolicyPoDTO.getDesc());
        vulPolicyPo.setName(vulPolicyPoDTO.getName());
        vulPolicyPo.setVulType(vulPolicyPoDTO.getVulTypeIdList());

        return policyManagePoService.addVulPolicyPo(vulPolicyPo);
    }

    /**
     * 删除策略 接口
     *
     * @param id
     * @return
     */
    @DeleteMapping("/strategy/{id}")
    public Map<String, String> deleteStrategy(@PathVariable Integer id) {
        return policyManagePoService.deleteVulPolicyPo(id);
    }

    /**
     * 分页查询策略 接口
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/strategy")
    public PageDTO<PolicyManagePo> getStrategy(Integer page, Integer limit) {

        //使用分页工具类处理查询到的结果集，封装成前端需要的数据
        PageUtils<PolicyManagePo> taskManagePoPageUtils = new PageUtils<>();
        PageDTO<PolicyManagePo> taskManagePoPageDTO = taskManagePoPageUtils.pageUtil(policyManagePoService.getVulPolicyPoPage(page, limit));
        return taskManagePoPageDTO;
    }

    /**
     * 获取漏洞列表
     * @return
     */
    @GetMapping("/vulType")
    public List getVulType(){
        //TODO
        return null;
    }

}
