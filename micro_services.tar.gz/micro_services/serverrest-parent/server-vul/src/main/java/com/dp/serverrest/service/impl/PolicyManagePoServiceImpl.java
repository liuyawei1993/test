package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.PolicyManagePoMapper;
import com.dp.serverrest.po.PolicyManagePo;
import com.dp.serverrest.service.api.PolicyManagePoService;
import com.dp.serverrest.service.util.CommentUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @className: PolicyManagePoServiceImpl
 * @description: 策略管理接口 实现类
 * @author: yuanyubo
 * @create: 2019-08-30
 */
@Service
public class PolicyManagePoServiceImpl implements PolicyManagePoService {

    @Autowired
    private PolicyManagePoMapper dao;


    /**
     * 新增策略
     * @param vulPolicyPo
     * @return
     */
    @Override
    public Map<String, String> addVulPolicyPo(PolicyManagePo vulPolicyPo) {

        return CommentUtils.addData(vulPolicyPo,dao);
    }

    /**
     * 修改策略
     * @param id
     * @param vulPolicyPo
     * @return
     */
    @Override
    public Map<String, String> modifyVulPolicyPo(int id, PolicyManagePo vulPolicyPo) {
        vulPolicyPo.setId(id);
        return CommentUtils.modifyData(id,vulPolicyPo,dao);
    }

    /**
     * 删除策略
     * @param id
     * @return
     */
    @Override
    public Map<String, String> deleteVulPolicyPo(int id) {
        return CommentUtils.deleteData(id,dao);
    }

    /**
     * 分页查询策略
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<PolicyManagePo> getVulPolicyPoPage(int page, int limit) {
        PageHelper.startPage(page, limit);
        return new PageInfo<PolicyManagePo>(dao.selectAll());
    }
}
