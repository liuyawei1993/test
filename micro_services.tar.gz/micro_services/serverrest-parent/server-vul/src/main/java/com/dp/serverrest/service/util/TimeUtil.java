package com.dp.serverrest.service.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @className: TimeUtil
 * @description: 时间处理工具类
 * @author: yuanyubo
 * @create: 2019-08-29
 */
public class TimeUtil {

    /**
     * 时间戳转字符串
     *
     * @param time
     * @return
     */
    public static String timeToString(Long time) throws ParseException {

        //24小时时间制
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd"); //24小时时间制
        String stringTime = format.format(time);
        return stringTime;
    }

    public static void main(String[] args) throws ParseException {
        //1.获取毫秒值
        long time = System.currentTimeMillis();
        String toString = timeToString(time);
        System.out.println(toString);
    }
}
