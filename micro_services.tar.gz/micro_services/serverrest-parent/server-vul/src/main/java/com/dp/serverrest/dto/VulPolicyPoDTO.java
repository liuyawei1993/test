package com.dp.serverrest.dto;

/**
 * @className: VulPolicyPoDTO
 * @description: 策略管理DTO 接收前端传递参数
 * @author: yuanyubo
 * @create: 2019-08-30
 */
public class VulPolicyPoDTO {

    private Integer id;

    private String name;

    private String vulTypeIdList;

    private String desc;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVulTypeIdList() {
        return vulTypeIdList;
    }

    public void setVulTypeIdList(String vulTypeIdList) {
        this.vulTypeIdList = vulTypeIdList;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public String toString() {
        return "VulPolicyPoDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", vulTypeIdList='" + vulTypeIdList + '\'' +
                ", desc='" + desc + '\'' +
                '}';
    }
}
