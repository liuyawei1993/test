package com.dp.serverrest.controller;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.TaskHistoryPo;
import com.dp.serverrest.service.api.TaskHistoryPoService;
import com.dp.serverrest.service.api.TaskManagePoService;
import com.dp.serverrest.service.util.PageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @className: TaskHistoryController
 * @description: 任务历史 接口
 * @author: yuanyubo
 * @create: 2019-08-30
 */
@RestController
@RequestMapping("/stap/vulAnalysis/taskHistory")
public class TaskHistoryController {

    @Autowired
    private TaskHistoryPoService taskHistoryPoService;

    /**
     * 删除任务历史
     * @param id
     * @return
     */
    @DeleteMapping("/history/{id}")
    public Map<String,String> deleteTaskHistory(@PathVariable Integer id){
        return taskHistoryPoService.deleteTaskHistoryPo(id);
    }

    /**
     * 分页查询任务历史
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/history")
    public PageDTO<TaskHistoryPo> getTaskHistory(Integer page,Integer limit){

        //使用分页工具类处理查询到的结果集，封装成前端需要的数据
        PageUtils<TaskHistoryPo> taskHistoryPoPageUtils = new PageUtils<>();
        PageDTO<TaskHistoryPo>  taskHistoryPoPageDTO= taskHistoryPoPageUtils.pageUtil(taskHistoryPoService.getVulTaskHistoryPo(page, limit));
        return taskHistoryPoPageDTO;
    }

    /**
     * 任务历史 对比 未完成
     * @param id
     * @return
     */
    @PostMapping("/history/{id}/diff")
    public Map<String,Object> getDiff(@PathVariable Integer id){
        //TODO
        return null;
    }

    /**
     * 任务历史 下载
     * @param id
     * @return
     */
    @PostMapping("/history/{id}/download")
    public Map<String,Object> getDownload(@PathVariable Integer id){
        //TODO
        return null;
    }

}
