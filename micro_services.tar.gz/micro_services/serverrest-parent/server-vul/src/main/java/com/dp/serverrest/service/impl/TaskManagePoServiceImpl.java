package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.TaskManagePoMapper;
import com.dp.serverrest.po.TaskManagePo;
import com.dp.serverrest.service.api.TaskManagePoService;
import com.dp.serverrest.service.util.CommentUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @className: TaskManagePoServiceImpl
 * @description: 任务管理实现类
 * @author: yuanyubo
 * @create: 2019-08-29
 */
@Service
public class TaskManagePoServiceImpl implements TaskManagePoService {

    @Autowired
    private TaskManagePoMapper dao;

    /**
     * 新建 任务管理
     * @param taskManagePo
     * @return
     */
    @Override
    public Map<String, String> addTaskManage(TaskManagePo taskManagePo) {

        return CommentUtils.addData(taskManagePo,dao);
    }

    /**
     * 修改 任务管理
     * @param id
     * @param taskManagePo
     * @return
     */
    @Override
    public Map<String, String> modifyTaskManage(int id, TaskManagePo taskManagePo) {
        return null;
    }

    /**
     * 删除 任务管理
     * @param id
     * @return
     */
    @Override
    public Map<String, String> deleteTaskManage(int id) {
        return CommentUtils.deleteData(id,dao);
    }

    /**
     * 查询 全部任务管理
     *
     * @param page
     * @param limit
     * @return
     */
    @Override
    public List<TaskManagePo> getTaskManageList(int page, int limit) {
        //暂时无用
        return null;
    }

    /**
     * 分页查询 任务管理
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<TaskManagePo> getTaskManagePage(int page, int limit) {
        PageHelper.startPage(page, limit);
        return new PageInfo<TaskManagePo>(dao.selectAll());
    }

    /**
     * 根据ID查询任务完成状态
     * 0=未开始 100=已完成 1-99 任务进度
     * @param id
     * @return
     */
    @Override
    public Integer getTaskStatus(Integer id) {
        Integer integer = dao.getTaskStatus(id);
        return integer;
    }
}
