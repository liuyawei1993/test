package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.TaskHistoryPoMapper;
import com.dp.serverrest.po.TaskHistoryPo;
import com.dp.serverrest.service.api.TaskHistoryPoService;
import com.dp.serverrest.service.util.CommentUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @className: TaskHistoryPoServiceImpl
 * @description: 漏洞管理 任务历史 实现类
 * @author: yuanyubo
 * @create: 2019-08-30
 */
@Service
public class TaskHistoryPoServiceImpl implements TaskHistoryPoService {

    @Autowired
    private TaskHistoryPoMapper dao;

    /**
     * 新增 任务历史
     * @param taskHistoryPo
     * @return
     */
    @Override
    public Map<String, String> addTaskHistoryPo(TaskHistoryPo taskHistoryPo) {
        return CommentUtils.addData(taskHistoryPo,dao);
    }

    /**
     * 删除 任务历史
     * @param id
     * @return
     */
    @Override
    public Map<String, String> deleteTaskHistoryPo(int id) {
        return CommentUtils.deleteData(id,dao);
    }

    /**
     * 分页查询 任务历史
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<TaskHistoryPo> getVulTaskHistoryPo(int page, int limit) {
        PageHelper.startPage(page, limit);
        return new PageInfo<TaskHistoryPo>(dao.selectAll());
    }
}
