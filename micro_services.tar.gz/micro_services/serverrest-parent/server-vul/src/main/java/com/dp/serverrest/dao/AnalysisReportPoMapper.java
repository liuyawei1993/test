package com.dp.serverrest.dao;

import com.dp.serverrest.po.AnalysisReportPo;

import java.util.List;

/**
 * @author yuanyubo
 */
public interface AnalysisReportPoMapper extends BasePoMapper{
    /**
     * 根据ID删除
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 新增
     * @param record
     * @return
     */
    int insert(AnalysisReportPo record);

    /**
     * 批量新增
     * @param record
     * @return
     */
    int insertSelective(AnalysisReportPo record);

    /**
     * 根据主键查询数据
     * @param id
     * @return
     */
    AnalysisReportPo selectByPrimaryKey(Integer id);

    /**
     * 非空字段修改
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(AnalysisReportPo record);

    /**
     * 根据ID更新数据
     * @param record
     * @return
     */
    int updateByPrimaryKey(AnalysisReportPo record);

    /**
     * 查询全部的报告数据
     * @return
     */
    List<AnalysisReportPo> selectAll();
}