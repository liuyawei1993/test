package com.dp.serverrest.service.api;

import com.dp.serverrest.po.PolicyManagePo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @className: PolicyManagePoService
 * @description: 策略管理接口
 * @author: yuanyubo
 * @create: 2019-08-30
 */
public interface PolicyManagePoService {

    /**
     * 新增策略
     * @param policyManagePo
     * @return
     */
    public Map<String, String> addVulPolicyPo(PolicyManagePo policyManagePo);

    /**
     * 修改策略
     * @param id
     * @param policyManagePo
     * @return
     */
    public Map<String, String> modifyVulPolicyPo(int id, PolicyManagePo policyManagePo);

    /**
     * 删除策略
     * @param id
     * @return
     */
    public Map<String, String> deleteVulPolicyPo(int id);

    /**
     * 分页查询策略
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<PolicyManagePo> getVulPolicyPoPage(int page, int limit);

}
