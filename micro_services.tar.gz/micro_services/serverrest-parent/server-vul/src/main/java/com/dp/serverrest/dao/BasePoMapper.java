package com.dp.serverrest.dao;

import com.dp.serverrest.po.BasePo;

/**
 * @interfaceName: BasePoMapper
 * @description: Dao 基类
 * @author: yuanyubo
 * @create: 2019-08-29
 */
public interface BasePoMapper {

    /**
     * 新增 通用接口
     * @param record
     * @return
     */
    int insert(BasePo record);

    /**
     * 根据ID修改通用接口
     * @param vo
     * @return
     */
    int updateByPrimaryKey(BasePo vo);

    /**
     * 根据ID删除通用接口
     * @param id
     * @return
     */
    int deleteByPrimaryKey(int id);
}
