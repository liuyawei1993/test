package com.dp.serverrest.dao;

import com.dp.serverrest.po.TaskHistoryPo;

import java.util.List;

/**
 * @author yuanyuabo
 * @apiNote 漏洞管理 历史任务管理
 */
public interface TaskHistoryPoMapper extends BasePoMapper {

    /**
     * 根据ID删除 历史任务
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 新增 历史任务
     * @param record
     * @return
     */
    int insert(TaskHistoryPo record);

    /**
     * 非空字段添加
     * @param record
     * @return
     */
    int insertSelective(TaskHistoryPo record);

    /**
     * 根据主键进行查询
     * @param id
     * @return
     */
    TaskHistoryPo selectByPrimaryKey(Integer id);

    /**
     * 根据主键进行非空更新
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(TaskHistoryPo record);

    /**
     * 根据主键进行全部更新
     * @param record
     * @return
     */
    int updateByPrimaryKey(TaskHistoryPo record);

    /**
     * 查询全部的任务历史
     * @return
     */
    List<TaskHistoryPo> selectAll();
}