package com.dp.serverrest.controller;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.TaskManagePo;
import com.dp.serverrest.service.api.TaskManagePoService;
import com.dp.serverrest.service.util.PageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @className: TaskManageController
 * @description: 任务管理 接口
 * @author: yuanyubo
 * @create: 2019-08-29
 */
@RestController
@RequestMapping(value = "/stap/vulAnalysis/taskManager")
public class TaskManageController {

    @Autowired
    private TaskManagePoService taskManagePoService;

    /**
     * 新建任务 接口
     * @param taskManagePo
     * @return
     */
    @PostMapping("task")
    public Map<String,String> addTask(@RequestBody TaskManagePo taskManagePo){
        return taskManagePoService.addTaskManage(taskManagePo);
    }

    /**
     * 删除任务 接口
     * @param id
     * @return
     */
    @DeleteMapping("/task/{id}")
    public Map<String,String> deleteTask(@PathVariable Integer id){
        return taskManagePoService.deleteTaskManage(id);
    }

    /**
     * 分页查询 任务列表
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("task")
    public PageDTO<TaskManagePo> queryTask(Integer page, Integer limit){

        //使用分页工具类处理查询到的结果集，封装成前端需要的数据
        PageUtils<TaskManagePo> taskManagePoPageUtils = new PageUtils<>();
        PageDTO<TaskManagePo> taskManagePoPageDTO = taskManagePoPageUtils.pageUtil(taskManagePoService.getTaskManagePage(page, limit));
        return taskManagePoPageDTO;
    }

    /**
     * 开始任务接口
     * @param id
     * @return
     */
    @PostMapping("/task/{id}/status")
    public Map<String,String> startTask(@PathVariable Integer id){
        //TODO
        return null;
    }

    /**
     * 获取任务状态接口 返回数值，没有“%”号
     * 0=未开始 100=已完成 1-99 任务进度
     * @param id
     * @return
     */
    @GetMapping("/task/{id}/status")
    public Map<String,Object> getTaskStatus(@PathVariable Integer id){
        Integer taskStatus = taskManagePoService.getTaskStatus(id);
        HashMap<String, Object> stringObjectHashMap = new HashMap<String, Object>(16);
        stringObjectHashMap.put("status",taskStatus);
        return stringObjectHashMap;
    }

    /**
     * 任务管理 -- 检测目标列表
     * 需要访问资产管理模块的接口来实现查询功能
     * 单机版不需要模块间通信，微服务版需要进行模块间通信
     *
     * @return
     */
    @GetMapping("target")
    public Map<String,String> addTask(){
        //TODO
        return null;
    }

}
