package com.dp.serverrest.po;

/**
 * @className: BasePo
 * @description: 实体类 基类
 * @author: yuanyubo
 * @create: 2019-08-29
 */
public class BasePo {
}
