package com.dp.serverrest.dao;

import com.dp.serverrest.po.PolicyManagePo;

import java.util.List;

/**
 * @author yuanyubo
 * @apiNote 漏洞策略管理接口
 */
public interface PolicyManagePoMapper extends BasePoMapper {

    /**
     * 根据主键删除 漏洞策略
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 新增数据 漏洞策略
     * @param record
     * @return
     */
    int insert(PolicyManagePo record);

    /**
     * 非空漏洞策略 新增
     * @param record
     * @return
     */
    int insertSelective(PolicyManagePo record);

    /**
     * 根据ID查询
     * @param id
     * @return
     */
    PolicyManagePo selectByPrimaryKey(Integer id);

    /**
     * 根据主键进行字段非空更新
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(PolicyManagePo record);

    /**
     * 根据主键进行全部更新
     * @param record
     * @return
     */
    int updateByPrimaryKey(PolicyManagePo record);

    /**
     * 查询全部的漏洞策略信息
     * @return
     */
    List<PolicyManagePo> selectAll();
}