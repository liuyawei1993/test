package com.dp.serverrest.controller;

import com.dp.serverrest.service.api.AnalysisReportPoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @className: AnalysisReportController
 * @description: 漏洞分析  报告分析 接口
 * @author: yuanyubo
 * @create: 2019-08-30
 */
@RestController
@RequestMapping("/stap/vulAnalysis/reportAnalysis")
public class AnalysisReportController {

    @Autowired
    private AnalysisReportPoService analysisReportPoService;

    /**
     * 删除报告分析
     * @param id
     * @return
     */
    @DeleteMapping("/report/{id}")
    public Map<String,String> deleteAnalysisReport(@PathVariable Integer id){
        return analysisReportPoService.deleteAnalysisReportPo(id);
    }

    /**
     * 数据导入 未完成
     * （需要记录导入信息）
     * @return
     */
    @PostMapping("/report")
    public Map<String,Object> report(){
        //TODO
        return null;
    }

    /**
     * 报告分析-对比 相同来源的进行对比 未完成
     * @param id
     * @return
     */
    @PostMapping("/report/{id}/diff")
    public Map<String,Object> reportDiff(@PathVariable Integer id){
        //TODO
        return null;
    }

    /**
     * 报告分析 在线查看 未完成
     * @param id
     * @return
     */
    @PostMapping("/report/{id}/view")
    public Map<String,Object> reportView(@PathVariable Integer id){
        //TODO
        return null;
    }

}
