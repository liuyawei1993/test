package com.dp.serverrest.service.api;

import com.dp.serverrest.po.TaskManagePo;
import com.github.pagehelper.PageInfo;

import java.util.List;
import java.util.Map;

/**
 * @interfaceName: TaskManagePoService
 * @description: 任务管理 接口
 * @author: yuanyubo
 * @create: 2019-08-29
 */
public interface TaskManagePoService {

    /**
     * 新增 任务管理
     * @param taskManagePo
     * @return
     */
    public Map<String, String> addTaskManage(TaskManagePo taskManagePo);

    /**
     * 修改 任务管理
     * @param id
     * @param taskManagePo
     * @return
     */
    public Map<String, String> modifyTaskManage(int id,TaskManagePo taskManagePo);

    /**
     * 删除 任务管理
     * @param id
     * @return
     */
    public Map<String, String> deleteTaskManage(int id);

    /**
     * 获取全部 任务管理
     * @param page
     * @param limit
     * @return
     */
    public List<TaskManagePo> getTaskManageList(int page, int limit);

    /**
     * 分页查询 任务管理
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<TaskManagePo> getTaskManagePage(int page, int limit);

    /**
     * 根据ID查询任务完成状态
     * @param id
     * @return
     */
    public Integer getTaskStatus(Integer id);
}
