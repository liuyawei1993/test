package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.AnalysisReportPoMapper;
import com.dp.serverrest.po.AnalysisReportPo;
import com.dp.serverrest.service.api.AnalysisReportPoService;
import com.dp.serverrest.service.util.CommentUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @className: AnalysisReportPoServiceImpl
 * @description: 漏洞分析  报告分析  实现类
 * @author: yuanyubo
 * @create: 2019-08-30
 */
@Service
public class AnalysisReportPoServiceImpl implements AnalysisReportPoService {

    @Autowired
    private AnalysisReportPoMapper dao;

    /**
     * 新增 报告分析
     * @param analysisReportPo
     * @return
     */
    @Override
    public Map<String, String> addAnalysisReportPo(AnalysisReportPo analysisReportPo) {
        return null;
    }

    /**
     * 删除 报告分析
     * @param id
     * @return
     */
    @Override
    public Map<String, String> deleteAnalysisReportPo(int id) {
        return CommentUtils.deleteData(id,dao);
    }

    /**
     * 分页查询  报告分析
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<AnalysisReportPo> getAnalysisReportPo(int page, int limit) {
        PageHelper.startPage(page, limit);
        return new PageInfo<AnalysisReportPo>(dao.selectAll());
    }
}
