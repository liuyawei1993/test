package com.dp.serverrest.service.util;

import com.dp.serverrest.dao.BasePoMapper;
import com.dp.serverrest.po.BasePo;
import com.google.common.collect.Maps;

import java.util.Map;

/**
 * @className: CommentUtil
 * @description:
 * @author: yuanyubo
 * @create: 2019-08-29
 */
public class CommentUtils {

    /**
     * @param id
     * @param dao
     * 删除的通用方法
     * @return
     */
    public static Map<String, String> deleteData(int id, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.deleteByPrimaryKey(id);
        if (res > 0) {
            result.put("success", "delete success!");
        } else {
            result.put("err", "delete err!check it!");
        }
        return result;
    }

    /**
     * @param dao
     * 新增的通用方法
     * @return
     */
    public static Map<String, String> addData(BasePo po, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        try {
            dao.insert(po);
            result.put("success", "add success!");
        } catch (Exception e) {
            result.put("err", "add err!check it!");
        }
        return result;
    }

    /**
     * @param dao
     * 修改的通用方法
     * @return
     */
    public static Map<String, String> modifyData(Integer id,BasePo po,BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.updateByPrimaryKey(po);
        if (res > 0) {
            result.put("success", "modify success!");
        } else {
            result.put("err", "modify err!check it!");
        }
        return result;
    }

}
