package com.dp.serverrest.service.api;

import com.dp.serverrest.po.AnalysisReportPo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @className: AnalysisReportPoService
 * @description: 漏洞分析   报告分析
 * @author: yuanyubo
 * @create: 2019-08-30
 */
public interface AnalysisReportPoService {


    /**
     * 新增 报告分析
     * @param analysisReportPo
     * @return
     */
    public Map<String, String> addAnalysisReportPo(AnalysisReportPo analysisReportPo);

    /**
     * 删除 报告分析
     * @param id
     * @return
     */
    public Map<String, String> deleteAnalysisReportPo(int id);

    /**
     * 分页查询 报告分析
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<AnalysisReportPo> getAnalysisReportPo(int page, int limit);

}
