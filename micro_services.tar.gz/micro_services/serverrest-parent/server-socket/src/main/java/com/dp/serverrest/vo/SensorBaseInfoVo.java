/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.vo;

import java.util.List;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月16日 下午3:41:43
 * 
 */

public class SensorBaseInfoVo {

    public static class HardWareVo {

	private Long createTime;

	private String cpuName;

	private String cpuFreq;

	private String cpuProc;

	private String memorySize;

	private String diskSize;

	private String getCpuFreq() {
	    return cpuFreq;
	}

	public String getCpuName() {
	    return cpuName;
	}

	public String getCpuProc() {
	    return cpuProc;
	}

	public Long getCreateTime() {
	    return createTime;
	}

	public String getDiskSize() {
	    return diskSize;
	}

	public String getMemorySize() {
	    return memorySize;
	}

	public HardWareVo setCpuFreq(String cpuFreq) {
	    this.cpuFreq = cpuFreq;
	    return this;
	}

	public HardWareVo setCpuName(String cpuName) {
	    this.cpuName = cpuName;
	    return this;
	}

	public HardWareVo setCpuProc(String cpuProc) {
	    this.cpuProc = cpuProc;
	    return this;
	}

	public HardWareVo setCreateTime(Long createTime) {
	    this.createTime = createTime;
	    return this;
	}

	public HardWareVo setDiskSize(String diskSize) {
	    this.diskSize = diskSize;
	    return this;
	}

	public HardWareVo setMemorySize(String memorySize) {
	    this.memorySize = memorySize;
	    return this;
	}
    }

    private Integer sensorId;

    private String sensorName;

    private String sensorIp;

    private String sensorType;
    
    private String status;

    public HardWareVo hardWareVo;

    private List<SensorInterfaceVo> sensorInterfaceList;

    public HardWareVo getHardWareVo() {
	return hardWareVo;
    }

    public Integer getSensorId() {
	return sensorId;
    }

    public List<SensorInterfaceVo> getSensorInterfaceList() {
	return sensorInterfaceList;
    }

    public String getSensorIp() {
	return sensorIp;
    }

    public String getSensorName() {
	return sensorName;
    }

    public String getSensorType() {
	return sensorType;
    }

    public String getStatus() {
	return status;
    }

    public SensorBaseInfoVo setHardWareVo(HardWareVo hardWareVo) {
	this.hardWareVo = hardWareVo;
	return this;
    }

    public SensorBaseInfoVo setSensorId(Integer sensorId) {
	this.sensorId = sensorId;
	return this;
    }

    public SensorBaseInfoVo setSensorInterfaceList(List<SensorInterfaceVo> sensorInterfaceList) {
	this.sensorInterfaceList = sensorInterfaceList;
	return this;
    }

    public SensorBaseInfoVo setSensorIp(String sensorIp) {
	this.sensorIp = sensorIp;
	return this;
    }

    public SensorBaseInfoVo setSensorName(String sensorName) {
	this.sensorName = sensorName;
	return this;
    }

    public SensorBaseInfoVo setSensorType(String sensorType) {
	this.sensorType = sensorType;
	return this;
    }

    public SensorBaseInfoVo setStatus(String status) {
	this.status = status;
	return this;
    }
}
