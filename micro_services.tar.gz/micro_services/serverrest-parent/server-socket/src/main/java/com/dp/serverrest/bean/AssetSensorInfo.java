package com.dp.serverrest.bean;

public class AssetSensorInfo {
    private int id;
    private String sensorUUID;
    private String sensorInfo;
    public AssetSensorInfo(){}
    public AssetSensorInfo(String sensorUUID, String sensorInfo) {
        this.sensorUUID = sensorUUID;
        this.sensorInfo = sensorInfo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSensorUUID() {
        return sensorUUID;
    }

    public void setSensorUUID(String sensorUUID) {
        this.sensorUUID = sensorUUID;
    }

    public String getSensorInfo() {
        return sensorInfo;
    }

    public void setSensorInfo(String sensorInfo) {
        this.sensorInfo = sensorInfo;
    }
}
