package com.dp.serverrest.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.StringUtils;

import com.dp.jni.DpSSLServerSocket;
import com.dp.jni.SSLServer;
import com.dp.jni.SocketServer;
import com.dp.serverrest.bean.AssetSensorInfo;
import com.dp.serverrest.bean.HostAuditInfo;
import com.dp.serverrest.bean.MessageObj;
import com.dp.serverrest.bean.VulTaskConfig;
import com.dp.serverrest.bean.VulTaskStatus;
import com.dp.serverrest.common.SensorMessage;
import com.dp.serverrest.common.ServerConstant;
import com.dp.serverrest.dao.AssetSensorDao;
import com.dp.serverrest.dao.AssetSensorInfoDao;
import com.dp.serverrest.dao.CenterControlDao;
import com.dp.serverrest.dao.HostAuditInfoDao;
import com.dp.serverrest.dao.ReportInfoDao;
import com.dp.serverrest.dao.SensorCfgVoMapper;
import com.dp.serverrest.dao.SensorInterfaceStatusVoMapper;
import com.dp.serverrest.dao.SensorInterfaceVoMapper;
import com.dp.serverrest.dao.SensorManageVoMapper;
import com.dp.serverrest.dao.SensorMessageVoMapper;
import com.dp.serverrest.dao.SensorStatusDao;
import com.dp.serverrest.dao.SensorStatusVoMapper;
import com.dp.serverrest.dao.VulTaskConfigDao;
import com.dp.serverrest.dao.VulTaskRecordDao;
import com.dp.serverrest.dao.VulTaskStatusDao;
import com.dp.serverrest.service.api.CenterControlService;
import com.dp.serverrest.service.util.ESutil;
import com.dp.serverrest.service.util.LogUtil;
import com.dp.serverrest.service.util.MD5Util;
import com.dp.serverrest.vo.SensorCfgVo;
import com.dp.serverrest.vo.SensorCfgVoWithBLOBs;
import com.dp.serverrest.vo.SensorInterfaceStatusVo;
import com.dp.serverrest.vo.SensorInterfaceVo;
import com.dp.serverrest.vo.SensorManageVo;
import com.dp.serverrest.vo.SensorMessageVo;
import com.dp.serverrest.vo.SensorStatusVo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;

/**
 * Created by jed on 19-7-10.
 */
@Service
@Transactional(readOnly = false)
public class CenterControlServiceImpl implements CenterControlService {

    LogUtil logUtil = new LogUtil(CenterControlServiceImpl.class);

    @Autowired
    private CenterControlDao CenterControlDao;

    @Autowired
    private ReportInfoDao reportInfoDao;

    @Autowired
    private AssetSensorDao assetSensorDao;

    @Autowired
    private SensorStatusDao sensorStatusDao;

    @Autowired
    private AssetSensorInfoDao assetSensorInfoDao;

    @Autowired
    private VulTaskStatusDao vulTaskStatusDao;

    @Autowired
    private VulTaskConfigDao vulTaskConfigDao;

    @Autowired
    private SensorMessageVoMapper sensorMessageVoMapper;

    @Autowired
    private HostAuditInfoDao hostAuditInfoDao;

    @Autowired
    private VulTaskRecordDao vulTaskRecordDao;

    @Autowired
    private SensorManageVoMapper sensorManageVoMapper;

    @Autowired
    private SensorInterfaceVoMapper sensorInterfaceVoMapper;

    @Autowired
    private SensorStatusVoMapper sensorStatusVoMapper;

    @Autowired
    private SensorInterfaceStatusVoMapper sensorInterfaceStatusVoMapper;

    @Autowired
    private SensorCfgVoMapper sensorCfgVoMapper;

    @Autowired
    private ESutil eSutil;

    @Value("${logSwitch}")
    private String logSwitch;

    private String rootPath = System.getProperty("user.dir") + "/../source/";

//    private String rootPath = System.getProperty("user.dir") + "/../uis/ui_quzhou/source/";

    public CenterControlServiceImpl() {
	// System.load(System.getProperty("user.dir") + "/../source/libdpssl.so");
    }

    /**
     * 控制处理
     *
     * @return
     */
    private void controlHandle(Map<String, Object> result, JsonNode rootNode, int socketInt, int socketType, Socket socket) throws Exception {
        logUtil.info("控制开始。。。。", logSwitch);

        JsonNode dataNode = rootNode.get("data");
        int operator = dataNode.get("operator").asInt();

        logUtil.info("operator:" + operator, logSwitch);

        switch (operator) {
            case ServerConstant.OPERATOR_INFORELATION:
                //信息关联
                infoRelation(result, rootNode);
                break;
            case ServerConstant.OPERATOR_INITINFO:
                //信息初始化
                infoInit(result, rootNode);
                break;
            case ServerConstant.OPERATOR_SENSORCONFIG:
                //探针配置获取
                getSensorConfig(result, rootNode);
                break;
            case ServerConstant.OPERATOR_TASKCONFIG:
                //任务配置获取
                getTaskConfig(result, dataNode.get("taskUUID").asText(), dataNode.get("seqUUID").asText());
                break;
            case ServerConstant.OPERATOR_HOSTINFO:
                //整改修复上报
//                modifyReportInfo(result, rootNode);
                break;
            case ServerConstant.OPERATOR_FILE_ISSUED:
                //软件版本或漏洞库文件下发
                fileIssued(result, rootNode, socketInt, socketType, socket);
                break;
            case ServerConstant.OPERATOR_FILE_REPORTED:
                //探针文件上报
                fileReported(result, rootNode, socketInt);
                break;
            default:
        }
        logUtil.info("控制结束。。。。" + operator, logSwitch);

    }

    /**
     * 平台文件下发（探针版本、漏洞库）
     *
     * @param result
     * @param rootNode
     * @param socket
     */
    private void fileIssued(Map<String, Object> result, JsonNode rootNode, int socketInt, int socketType, Socket socket) {
        result.put("result", "ok");
        FileInputStream in = null;
        OutputStream out = null;

        try {
            JsonNode info = rootNode.get("data").get("info");

            String fileName = info.get("fileName").asText();
            Long fileLength = info.get("fileLength").asLong();
            String versionType = info.get("versionType").asText();

            File file = new File(rootPath + "sensorVersion/" + versionType + "/" + fileName);
            if (file.exists()) {
                in = new FileInputStream(file);
                // 文件写入
                int len;
                byte[] bt = new byte[1024 * 10];
                int size = 0;
                if (socketType == 0) {
                    while ((len = in.read(bt)) != -1) {

                        size += len;
                        DpSSLServerSocket.writebuf(socketInt, bt, len);

                        logUtil.info("发送进度:" + fileLength + "/" + size, logSwitch);
                    }

                } else if (socketType == 1) {
                    out = socket.getOutputStream();
                    while ((len = in.read(bt)) != -1) {

                        size += len;

                        out.write(bt, 0, len);

                        logUtil.info("发送进度:" + fileLength + "/" + size, logSwitch);
                    }

                }

            } else {
                logUtil.info("没有找到该文件：" + fileName, logSwitch);
                result.put("result", "error");
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.put("result", "error");
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
                result.put("result", "error");
            }
        }

    }

    /**
     * 探针文件上报
     *
     * @param result
     * @param rootNode
     */
    private void fileReported(Map<String, Object> result, JsonNode rootNode, int socket) {
        result.put("result", "ok");
        FileOutputStream out = null;
        try {
            String sensorUUID = rootNode.get("deviceUUID").asText();
            JsonNode info = rootNode.get("data").get("info");

            String fileName = info.get("fileName").asText();
            String md5 = info.get("md5").asText();
            long length = info.get("fileLength").asLong();
            String desc = info.get("desc").asText();
            String id = info.get("id").asText();

            SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
            String date = format.format(new Date());

            //目标文件夹
            String dFilePath = rootPath + "hostInfoFile/" + sensorUUID + "/" + date;

            if (!StringUtils.isEmpty(fileName)) {

                File dFile = new File(dFilePath);
                if (!dFile.exists()) {
                    dFile.mkdirs();
                }
                //目标文件
                String realPath = dFilePath + "/" + fileName;
                File realFile = new File(realPath);

                out = new FileOutputStream(realFile);
                int len;
                byte[] bytes = null;
                while (length > 0) {

                    len = length >= 1024 ? 1024 : (int) length;
                    bytes = DpSSLServerSocket.readbuf(socket, len);
                    if (bytes == null) {
                        break;
                    }
                    out.write(bytes, 0, len);
                    length -= len;
                }

                out.close();

                //文件md5验
                String fileMD5 = MD5Util.getMD5ByCMD(realPath);
                logUtil.info("md5:" + fileMD5, logSwitch);

                if (!fileMD5.equals(md5)) {

                    realFile.delete();

                    result.put("result", "error");
                }
            }

            if (result.get("result").equals("ok")) {
                HostAuditInfo hostAuditInfo = new HostAuditInfo();
                hostAuditInfo.setHostDesc(desc);
                hostAuditInfo.setHostId(id);

                if (!StringUtils.isEmpty(fileName)) {
                    hostAuditInfo.setPath("source/hostInfoFile/" + sensorUUID + "/" + date + "/" + fileName);
                }

                hostAuditInfoDao.deleteInfoByhostId(id);

                hostAuditInfoDao.insertInfo(hostAuditInfo);
            }

        } catch (Exception e) {
            e.printStackTrace();
            result.put("result", "error");
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
                result.put("result", "error");
            }
        }
    }

    /**
     * 获取探针配置
     *
     * @param result
     * @param rootNode
     * @throws Exception
     */
    private void getSensorConfig(Map<String, Object> result, JsonNode rootNode) {
        int sensorUUID = rootNode.get("deviceUUID").asInt();

        SensorCfgVo sensorCfgVo = sensorCfgVoMapper.selectByPrimaryKey(sensorUUID);

        List<Map<String, Object>> list = new ArrayList<>();

        List<SensorInterfaceVo> interfaces = sensorInterfaceVoMapper.selectBySensorId(sensorUUID);
        List<String> auditList = new ArrayList<>();
        List<String> attackList = new ArrayList<>();
        for (SensorInterfaceVo info : interfaces) {
            if (info.getFlowStatus() != null && info.getFlowStatus() == 1) {
                auditList.add(info.getName());
            }
            if (info.getAttackStatus() != null && info.getAttackStatus() == 1) {
                attackList.add(info.getName());
            }
        }

        Map<String, Object> auditMap = new HashMap<>();
        auditMap.put("name", "audit");
        auditMap.put("status", sensorCfgVo.getTrafficEnable());
        auditMap.put("logaddr", sensorCfgVo.getTrafficLogIp());
        auditMap.put("netcfg", auditList);
        list.add(auditMap);

        Map<String, Object> attackMap = new HashMap<>();
        attackMap.put("name", "audit");
        attackMap.put("status", sensorCfgVo.getAttackEnable());
        attackMap.put("logaddr", sensorCfgVo.getAttackLogIp());
        attackMap.put("netcfg", attackList);
        list.add(attackMap);

        result.put("modules", list);
    }

    /**
     * 整改修复上报（es更新）
     *
     * @param rootNode
     */
//    private void modifyReportInfo(Map<String, Object> result, JsonNode rootNode) throws Exception {
//        TransportClient client = eSutil.getSingleTransportClient();
//        JsonNode arrayNode = rootNode.get("data").get("report_info");
//        for (int i = 0; i < arrayNode.size(); i++) {
//            JsonNode node = arrayNode.get(i);
//            String id = node.get("id").asText();
//
//            UpdateRequest updateRequest = new UpdateRequest();
//            updateRequest.index("vul_host_info");
//            updateRequest.type("host_doc");
//            updateRequest.id(id);
//            updateRequest.doc(XContentFactory.jsonBuilder()
//                    .startObject()
//                    .field("status", "fixed")
//                    .field("status_change_time", new Date().getTime())
//                    .endObject());
//            client.update(updateRequest).get();
//        }
//        result.put("result", "ok");
//    }

    /**
     * 获取任务配置信息
     *
     * @param taskUUID
     */
    private void getTaskConfig(Map<String, Object> result, String taskUUID, String seqUUID) throws Exception {
        VulTaskConfig vulTaskConfig = vulTaskConfigDao.searchInfoById(taskUUID);
        result.put("sequenceUUID", seqUUID);
        result.put("taskUUID", taskUUID);

        if (vulTaskConfig != null) {
            result.put("taskName", vulTaskConfig.getTaskName());
            int checkType = vulTaskConfig.getCheckType();//vulPolicy的id
            //获取策略信息
            List<Map<String, Object>> res = vulTaskConfigDao.getVulPolicyName(checkType);
            if (res != null && !StringUtils.isEmpty(res.get(0).get("vulType"))) {
                String[] names = res.get(0).get("vulType").toString().split(",");
                result.put("scanList", names);
            } else {
                result.put("scanList", "");
            }
        } else {
            result.put("taskName", "");
            result.put("scanList", "");
        }
        result.put("scanType", "2");
        result.put("targetType", "1");
        result.put("scanTarget", "");
        result.put("execute", "manual");
    }

    /**
     * 心跳处理
     *
     * @return
     */
    private void heartBeatHandle(Map<String, Object> result, JsonNode rootNode) throws Exception {
        logUtil.info("心跳开始。。。。", logSwitch);
        String deviceUUID = rootNode.get("deviceUUID").asText();
        JsonNode dataNode = rootNode.get("data");

        //更新sensorInfo表和插入sensorStatus新记录
        JsonNode statusNode = dataNode.get("status");
        updateSensorStatus(deviceUUID, statusNode);

//        //任务信息处理
//        if (dataNode.has("task_info"))
//            updateVulTaskStatus(deviceUUID, dataNode.get("task_info"));
//
        //获取一条该探针的消息队列数据
        ObjectMapper mapper = new ObjectMapper();
        SensorMessage sensorMessage = SensorMessage.getInstance();
        MessageObj messageObj = sensorMessage.popMessage(deviceUUID);
//
        if (StringUtils.isEmpty(messageObj.getMessage())) {
            result.put("result", "ok");
            result.put("info", mapper.readTree("{\"data\":{},\"operator\":0}"));
        } else {
            int messageUUID = Integer.valueOf(messageObj.getMessageUUID());
            SensorMessageVo sensorMessageBean = new SensorMessageVo();
            sensorMessageBean.setStatus(1);
            sensorMessageBean.setId(messageUUID);
            //更新信息状态码
            sensorMessageVoMapper.updateSensorMessage(sensorMessageBean);
            result.put("result", "message");
            JsonNode ndoe = mapper.readTree(messageObj.getMessage());
            result.put("info", ndoe);
        }
        logUtil.info("心跳结束。。。。" + mapper.writeValueAsString(result), logSwitch);
    }

    /**
     * 信息初始化
     *
     * @param result
     * @param rootNode
     * @throws Exception
     */
    private void infoInit(Map<String, Object> result, JsonNode rootNode) {
        int sensorUUID = rootNode.get("deviceUUID").asInt();

        JsonNode infoNode = rootNode.get("data").get("info");

        //探针基本信息数据处理
        String cpu_proc = infoNode.get("cpu_proc").asText();
        String cpu_freq = infoNode.get("cpu_freq").asText();
        String cpu_name = infoNode.get("cpu_name").asText();
        String mem_size = infoNode.get("mem_size").asText();
        String disk_size = infoNode.get("disk_size").asText();
        String softupdate = infoNode.get("softupdate").asText();
        String ruleupdate = infoNode.get("ruleupdate").asText();
        SensorManageVo sensorManageVo = new SensorManageVo();
        sensorManageVo.setSensorId(sensorUUID);
        sensorManageVo.setCpuProc(cpu_proc);
        sensorManageVo.setCpuFreq(cpu_freq);
        sensorManageVo.setCpuName(cpu_name);
        sensorManageVo.setMemorySize(mem_size);
        sensorManageVo.setDiskSize(disk_size);
        sensorManageVo.setStatus(ServerConstant.ONLINE);
        sensorManageVoMapper.updateByPrimaryKeySelective(sensorManageVo);

        //探针配置信息处理
        SensorCfgVoWithBLOBs sensorCfgVo = new SensorCfgVoWithBLOBs();
        List<String> auditList = new ArrayList<>();
        List<String> attackList = new ArrayList<>();

        JsonNode modulesNodes = infoNode.get("modules");
        for (int i = 0; i < modulesNodes.size(); i++) {
            JsonNode node = modulesNodes.get(i);
            String name = node.get("name").asText();
            int status = node.get("status").asInt();
            String logaddr = node.get("logaddr").asText();
            JsonNode netcfgNodes = node.get("netcfg");
            List<String> policysList = new ArrayList<>();
            JsonNode policyNodes = node.get("policy");
            for (int j = 0; j < policyNodes.size(); j++) {
                policysList.add(policyNodes.get(j).asText());
            }
            if (name.equals("audit")) {
                for (int j = 0; j < netcfgNodes.size(); j++) {
                    auditList.add(netcfgNodes.get(j).asText());
                }
                sensorCfgVo.setTrafficEnable(status);
                sensorCfgVo.setTrafficLogIp(logaddr);
                sensorCfgVo.setTrafficPolicy(Joiner.on(",").join(policysList));
            } else if (name.equals("attack")) {
                for (int j = 0; j < netcfgNodes.size(); j++) {
                    attackList.add(netcfgNodes.get(j).asText());
                }
                sensorCfgVo.setAttackEnable(status);
                sensorCfgVo.setAttackLogIp(logaddr);
                sensorCfgVo.setAttackPolicy(Joiner.on(",").join(policysList));
            }
        }
        sensorCfgVo.setSensorId(sensorUUID);
        sensorCfgVo.setSoftVersion(softupdate);
        sensorCfgVo.setSigVersion(ruleupdate);
        sensorCfgVoMapper.updateByPrimaryKeySelective(sensorCfgVo);

        //探针接口信息处理
        JsonNode interfacesNodes = infoNode.get("interfaces");

        sensorInterfaceStatusVoMapper.deleteBySensorId(sensorUUID);
        sensorInterfaceVoMapper.deleteBySensorId(sensorUUID);

        for (int i = 0; i < interfacesNodes.size(); i++) {
            JsonNode node = interfacesNodes.get(i);
            String name = node.get("name").asText();
            String status = node.get("status").asText();
            String mac = node.get("mac").asText();

            JsonNode addrsNode = node.get("addrs");
            List<String> addrList = new ArrayList<>();
            for (int j = 0; j < addrsNode.size(); j++) {
                addrList.add(addrsNode.get(j).asText());
            }

            String type = node.get("type").asText();
            SensorInterfaceVo sensorInterfaceVo = new SensorInterfaceVo();
            sensorInterfaceVo.setSensorId(sensorUUID);
            sensorInterfaceVo.setMac(mac);
            sensorInterfaceVo.setName(name);
            sensorInterfaceVo.setStatus(status);
            sensorInterfaceVo.setType(type);
            sensorInterfaceVo.setIp(Joiner.on(",").join(addrList));
            sensorInterfaceVo.setFlowStatus(auditList.contains(name) ? 1 : 0);
            sensorInterfaceVo.setAttackStatus(attackList.contains(name) ? 1 : 0);
            sensorInterfaceVoMapper.insert(sensorInterfaceVo);
        }
        result.put("result", "ok");
    }


    /**
     * 信息关联
     *
     * @param rootNode
     * @return
     */
    private void infoRelation(Map<String, Object> result, JsonNode rootNode) {
        JsonNode infoNode = rootNode.get("data").get("info");
        String deviceName = infoNode.get("deviceName").asText();
        SensorManageVo sensorManageVo = sensorManageVoMapper.selectBySensorName(deviceName);
        if (sensorManageVo != null) {
            result.put("result", "ok");
            result.put("deviceUUID", sensorManageVo.getSensorId() + "");
            //信息初始化
//            infoInit(uuid, infoNode);
        } else {
            result.put("result", "error");
            result.put("message", "deviceName error");
        }

    }


    @Override
    public String messageHandle(JsonNode rootNode, int socketInt, int socketType, Socket socket) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            Map<String, Object> result = new HashMap<>();
            int type = rootNode.get("type").asInt();

            switch (type) {

                case ServerConstant.HEART:
                    //心跳
                    heartBeatHandle(result, rootNode);
                    break;
                case ServerConstant.CONTROL:
                    //控制
                    controlHandle(result, rootNode, socketInt, socketType, socket);
                    break;
                default:
            }
            return mapper.writeValueAsString(result);
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            e.printStackTrace();
            return "{\"result\":\"error\"}";
        }
    }

    @Override
    public Map<String, String> startServer(int port, String serverKey, String server) {
        Map<String, String> result;

        //获取启动模式  需改
        int type = 1;

        if (type == 0) {
            //带证书socket
            SSLServer sslServer = SSLServer.getInstance();
            sslServer.stop();
            result = sslServer.start(port, serverKey, server);
        } else {
            //普通socket
            SocketServer socketServer = SocketServer.getInstance();
            socketServer.stop();
            result = socketServer.start(port);
        }
        return result;
    }


    /**
     * 资产组织结构（先删除再添加）
     *
     * @param rootNode
     */
    private void updateAssetSensorInfo(Map<String, Object> result, JsonNode rootNode) throws Exception {
        String sensorUUID = rootNode.get("deviceUUID").asText();
        String info = rootNode.get("data").get("info").toString();
        //根据探针uuid删除资产信息
        assetSensorInfoDao.deleteBySensorUUID(sensorUUID);
        //新增资产信息
        AssetSensorInfo assetSensorInfo = new AssetSensorInfo(sensorUUID, info);
        assetSensorInfoDao.insertInfo(assetSensorInfo);
        result.put("result", "ok");

    }

    /**
     * 更新探针信息
     *
     * @param statusNode
     */
    private void updateSensorStatus(String uuid, JsonNode statusNode) {
        double cpu_usage = statusNode.get("cpu_usage").asDouble();
        double mem_usage = statusNode.get("mem_usage").asDouble();
        double disk_usage = statusNode.get("disk_usage").asDouble();
        Integer sensorId = Integer.valueOf(uuid);

        SensorStatusVo sensorStatusVo = new SensorStatusVo();
        sensorStatusVo.setCpuUsage(cpu_usage);
        sensorStatusVo.setMemoryUsage(mem_usage);
        sensorStatusVo.setDiskUsage(disk_usage);
        sensorStatusVo.setSensorId(sensorId);
        sensorStatusVo.setTimeStamp(System.currentTimeMillis());
        sensorStatusVoMapper.insert(sensorStatusVo);

        JsonNode interfacesNodes = statusNode.get("interfaces");
        if (interfacesNodes != null && interfacesNodes.size() > 0) {
            List<SensorInterfaceVo> interfaces = sensorInterfaceVoMapper.selectBySensorId(sensorId);
            Map<String, Integer> map = new HashMap<>();
            for (SensorInterfaceVo info : interfaces) {
                map.put(info.getName(), info.getInfId());
            }

            for (int i = 0; i < interfacesNodes.size(); i++) {
                JsonNode node = interfacesNodes.get(i);
                String name = node.get("name").asText();
                long in_bytes = node.get("in_bytes").asLong();
                long out_bytes = node.get("out_bytes").asLong();

                SensorInterfaceStatusVo sensorInterfaceStatusVo = new SensorInterfaceStatusVo();
                sensorInterfaceStatusVo.setInBytes(in_bytes);
                sensorInterfaceStatusVo.setOutBytes(out_bytes);
                sensorInterfaceStatusVo.setName(name);
                sensorInterfaceStatusVo.setTimeStamp(System.currentTimeMillis());
                sensorInterfaceStatusVo.setInfId(map.get(name));
                sensorInterfaceStatusVoMapper.insert(sensorInterfaceStatusVo);

            }
        }

    }

    /**
     * 更新任务信息
     *
     * @param deviceUUID
     * @param taskNode
     */
    private void updateVulTaskStatus(String deviceUUID, JsonNode taskNode) throws Exception {
        if (taskNode.size() > 0) {
            for (int i = 0; i < taskNode.size(); i++) {
                JsonNode node = taskNode.get(i);
                String seq_uuid = node.get("seq_uuid").asText();
                double speed = node.get("speed").asDouble();

                if (!StringUtils.isEmpty(seq_uuid)) {
                    VulTaskStatus vulTaskStatus = new VulTaskStatus(deviceUUID, seq_uuid, speed);
                    if (speed == 100) {
                        vulTaskStatus.setEndTime(System.currentTimeMillis());
                        //正常结束
                        vulTaskStatus.setStatus(1);
                    }
                    vulTaskStatusDao.updateVulTaskStatus(vulTaskStatus);

                    //检查任务是否都完成，如果都完成更新vulTaskRecord表结束时间
                    int count = vulTaskStatusDao.selectCountNotFinishNum(seq_uuid);
                    if (count == 0) {
                        Map<String, Object> map = new HashMap<>();
                        map.put("uuid", seq_uuid);
                        map.put("endTime", System.currentTimeMillis());
                        vulTaskRecordDao.updateVulTaskRecordEndTime(map);
                    }
                }
            }


        }

    }

}