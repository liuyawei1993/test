package com.dp.serverrest.bean;

import java.math.BigInteger;

public class ReportInfo {
    private int id;
    private String ip;
    private String vul_id;
    private String message;
    private BigInteger createTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getVul_id() {
        return vul_id;
    }

    public void setVul_id(String vul_id) {
        this.vul_id = vul_id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public BigInteger getCreateTime() {
        return createTime;
    }

    public void setCreateTime(BigInteger createTime) {
        this.createTime = createTime;
    }
}
