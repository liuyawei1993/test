package com.dp.jni;


public class DpSSLSocket {
    public DpSSLSocket() {
    }

    public static native int create(byte[] crt, byte[] key, byte[] ca, int client_port);

    public static native int connect(byte[] ip, int port, int fd);

    public static native byte[] read(int fd);

    public static native int write(int fd, byte[] buf);

    public static native int close(int fd);

    public static native byte[] readbuf(int fd, int len);

    public static native int writebuf(int fd, byte[] buf, int len);
}
