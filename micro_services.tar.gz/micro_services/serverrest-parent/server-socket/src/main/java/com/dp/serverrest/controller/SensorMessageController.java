package com.dp.serverrest.controller;

import com.dp.serverrest.service.api.SensorManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Created by jed on 19-7-8.
 * 探针信息交互路由控制
 */
@RestController
@RequestMapping(value = "/api/sensorMessage")
public class SensorMessageController{

    @Autowired
    private SensorManageService sensorManageService;

    /**
     * 增加探针消息
     * @param sensorUUID
     * @param messageUUID
     * @param message
     * @return
     */
    @RequestMapping(value = "/pushNewMessage")
    public Map<String, String> pushNewMessage(@RequestParam String sensorUUID, @RequestParam String messageUUID, @RequestParam String message) {
        return sensorManageService.pushNewMessage(sensorUUID,messageUUID, message);

    }

}
