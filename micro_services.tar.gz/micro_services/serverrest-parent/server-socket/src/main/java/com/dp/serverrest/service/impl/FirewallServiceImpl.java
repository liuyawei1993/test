package com.dp.serverrest.service.impl;

import com.dp.serverrest.service.api.FirewallService;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.Map;

@Service
public class FirewallServiceImpl implements FirewallService {
    private static String BASE_PATH = System.getProperty("user.dir");
    private static String FIREWALL_CONFIG_FILE = "/../extra/roles/firewalld_set/templates/public.xml.j2";
    private static String FIREWALL_STOP = "/../extra/firewalld_stop.sh";
    private static String FIREWALL_UPDATE = "/../extra/firewalld_set.sh";
    private static String FIREWALL_START = "/../extra/firewalld_start.sh";


    @Override
    public Map<String, String> addSensorToFirewall(String sensorIp, int[] ports) {
        result.put("result", "true");

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        File f = new File(BASE_PATH + FIREWALL_CONFIG_FILE);
        DocumentBuilder db = null;

        try {
            db = dbf.newDocumentBuilder();
            Document firewallConfig = db.parse(f);
            Element root = firewallConfig.getDocumentElement();

            NodeList rules = root.getElementsByTagName("rule");
            boolean repeatFlag = false;

            for (int i = 0; i < rules.getLength(); i++) {
                Element rule = (Element) rules.item(i);

                NodeList sources = rule.getElementsByTagName("source");
                if (sources.getLength() != 0) {
                    Element sourceEle = (Element)sources.item(0);
                    if (sensorIp.equals(sourceEle.getAttribute("address"))) {
                        //只判断IP地址,端口号不可能存在多个,即一个探针IP只对应一个端口号.
                        repeatFlag = true;
                        break;
                    }
                }
            }

            if (repeatFlag) {
                result.put("result", "false");
            } else {
                for (int port : ports) {
                    Element newRule = firewallConfig.createElement("rule");
                    newRule.setAttribute("family", "ipv4");

                    Element newSource = firewallConfig.createElement("source");
                    newSource.setAttribute("address", sensorIp);
                    newRule.appendChild(newSource);

                    Element newPort = firewallConfig.createElement("port");
                    newPort.setAttribute("protocol", "tcp");
                    newPort.setAttribute("port", String.valueOf(port));
                    newRule.appendChild(newPort);

                    Element newAccept = firewallConfig.createElement("accept");
                    newRule.appendChild(newAccept);

                    root.appendChild(newRule);
                }

                saveFirewallConfigToFile(firewallConfig);
            }
        } catch (Exception e) {
            e.printStackTrace();

            result.put("result", "false");
        }

        return result;
    }

    @Override
    public Map<String, String> deleteSensorFromFirewall(String sensorIp) {
        result.put("result", "true");

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = null;

        try {
            db = dbf.newDocumentBuilder();
            Document firewallConfig = db.parse(new File(BASE_PATH + FIREWALL_CONFIG_FILE));
            Element root = firewallConfig.getDocumentElement();

            NodeList rules = root.getElementsByTagName("rule");

            int ruleLength = rules.getLength();

            for (int i = 0; i < ruleLength; i++) {
                Element rule = (Element) rules.item(i);

                NodeList sources = rule.getElementsByTagName("source");
                if (sources.getLength() != 0) {
                    Element sourceEle = (Element)sources.item(0);

                    if (sensorIp.equals(sourceEle.getAttribute("address"))) {
                        root.removeChild(rules.item(i));

                        i -= 1;
                        ruleLength -= 1;
                    }
                }
            }

            saveFirewallConfigToFile(firewallConfig);
        } catch (Exception e) {
            e.printStackTrace();

            result.put("result", "false");
        }

        return result;
    }

    /**
     * 保存配置到配置文件
     * @param firewallConfig
     */
    private static void saveFirewallConfigToFile(Document firewallConfig) {
        try {
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty("encoding", "utf-8");
            transformer.setOutputProperty("indent", "yes");
            transformer.transform(new DOMSource(firewallConfig), new StreamResult(new File(BASE_PATH + FIREWALL_CONFIG_FILE)));

            updateFirewallConfig();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 调用脚本更新防火墙配置
     */
    private static void updateFirewallConfig() {
        try {
            //停止防火墙
            Runtime.getRuntime().exec(BASE_PATH + FIREWALL_STOP).waitFor();
            //更新防火墙配置
            Runtime.getRuntime().exec(BASE_PATH + FIREWALL_UPDATE).waitFor();
            //启动防火墙
            Runtime.getRuntime().exec(BASE_PATH + FIREWALL_START).waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
