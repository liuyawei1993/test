package com.dp.serverrest.dao;

import com.dp.serverrest.bean.ReportInfo;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportInfoDao {
    void insertInfo(ReportInfo reportInfo);
}
