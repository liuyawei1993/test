package com.dp.serverrest.bean;

public class VulTaskStatus {
    private int id;
    private String sensorUuid;
    private String recordUuid;
    private double percent;
    private long startTime;
    private long endTime;
    private int status;

    public VulTaskStatus() {
    }

    public VulTaskStatus(String sensorUuid, String recordUuid, double percent) {
        this.sensorUuid = sensorUuid;
        this.recordUuid = recordUuid;
        this.percent = percent;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSensorUuid() {
        return sensorUuid;
    }

    public void setSensorUuid(String sensorUuid) {
        this.sensorUuid = sensorUuid;
    }

    public String getRecordUuid() {
        return recordUuid;
    }

    public void setRecordUuid(String recordUuid) {
        this.recordUuid = recordUuid;
    }

    public double getPercent() {
        return percent;
    }

    public void setPercent(double percent) {
        this.percent = percent;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
