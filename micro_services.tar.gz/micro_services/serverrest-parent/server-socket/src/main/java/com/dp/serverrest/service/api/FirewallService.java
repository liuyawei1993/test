package com.dp.serverrest.service.api;

import java.util.Map;

public interface FirewallService extends BaseService {
    public Map<String, String> addSensorToFirewall(String sensorIp, int[] ports);

    public Map<String, String> deleteSensorFromFirewall(String sensorIp);
}
