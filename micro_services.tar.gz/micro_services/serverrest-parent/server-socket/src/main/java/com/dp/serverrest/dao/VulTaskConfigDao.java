package com.dp.serverrest.dao;

import com.dp.serverrest.bean.AssetSensor;
import com.dp.serverrest.bean.VulTaskConfig;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface VulTaskConfigDao {


    /**
     * 根据id获取任务配置信息
     *
     * @param uuid
     * @return
     */

    VulTaskConfig searchInfoById(String uuid);

    /**
     * 获取Vulpolicy表的policyName
     *
     * @param id
     * @return
     */
    List<Map<String, Object>> getVulPolicyName(int id);

    /**
     * 获取任务列表
     * @return
     */
    List<VulTaskConfig> selectTaskList();


}
