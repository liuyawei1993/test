package com.dp.serverrest.dao;


import com.dp.serverrest.vo.SensorInterfaceVo;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface SensorInterfaceVoMapper extends BaseVoMapper{
    
    int deleteByPrimaryKey(Integer infId);

    
    int insert(SensorInterfaceVo record);

    
    int insertSelective(SensorInterfaceVo record);

    
    SensorInterfaceVo selectByPrimaryKey(Integer infId);
    
    List<SensorInterfaceVo> selectBySensorId(Integer sensorId);

    
    int updateByPrimaryKeySelective(SensorInterfaceVo record);

    
    int updateByPrimaryKey(SensorInterfaceVo record);

    int deleteBySensorId(Integer sensorId);
}