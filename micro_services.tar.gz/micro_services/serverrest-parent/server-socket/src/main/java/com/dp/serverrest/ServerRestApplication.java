package com.dp.serverrest;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.dp.serverrest.dao")
public class ServerRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerRestApplication.class, args);
    }

}
