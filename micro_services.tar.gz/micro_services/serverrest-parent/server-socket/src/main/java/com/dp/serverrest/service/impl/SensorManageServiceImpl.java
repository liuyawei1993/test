package com.dp.serverrest.service.impl;

import com.dp.serverrest.bean.*;
import com.dp.serverrest.service.util.LogUtil;
import com.dp.serverrest.common.SensorMessage;
import com.dp.serverrest.common.ServerConstant;
import com.dp.serverrest.dao.*;
import com.dp.serverrest.service.api.SensorManageService;
import com.dp.serverrest.vo.SensorManageVo;
import com.dp.serverrest.vo.SensorMessageVo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.*;

/**
 * Created by jed on 19-7-8.
 */
@Service
@Transactional(readOnly = false)
public class SensorManageServiceImpl implements SensorManageService {
    LogUtil logUtil = new LogUtil(SensorManageServiceImpl.class);
    @Autowired
    private SensorMessageVoMapper sensorMessageVoMapper;

    @Autowired
    private AssetSensorDao assetSensorDao;

    @Autowired
    private VulTaskStatusDao vulTaskStatusDao;

    @Autowired
    private VulTaskRecordDao vulTaskRecordDao;

    @Autowired
    private SensorManageVoMapper sensorManageVoMapper;

    @Value("${logSwitch}")
    private String logSwitch;

    @Value("${sensorMessageTimeOut}")
    private int sensorMessageTimeOut;


    @Override
    public Map<String, String> pushNewMessage(String sensor, String messageUUID, String message) {
        logUtil.info("sensorUUID:" + sensor + "      messageUUID:" + messageUUID + "     message:" + message, logSwitch);
        SensorMessage sensorMessage = SensorMessage.getInstance();

        sensorMessage.pushMessage(sensor, messageUUID, message);

        result.put("result", "true");
        return result;
    }

    @Override
    public void setSensorMessageToQueue() {
        logUtil.info("初始化消息队列", logSwitch);

        SensorMessage sensorMessage = SensorMessage.getInstance();

        //将未下发的消息放入队列中
        List<SensorMessageVo> list = sensorMessageVoMapper.getNoDeployMessageList();
        for (SensorMessageVo sensorMessageBean : list) {
            String sensorUUID = sensorMessageBean.getSensor_id()+"";
            String messageUUID = sensorMessageBean.getId()+"";
            String message = sensorMessageBean.getMessage();
            sensorMessage.pushMessage(sensorUUID, messageUUID, message);
        }

        logUtil.info("初始化探针为离线", logSwitch);
        sensorManageVoMapper.updateSensorToOffline();

    }

    @Override
    public void checkMessage() {
        logUtil.info("定时检测任务开始", logSwitch);
        try {
            //获取30分钟之前的时间
            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            //30分钟前的时间
            cal.add(Calendar.MINUTE, -sensorMessageTimeOut);
            Date newDay = cal.getTime();

            Map<String, Object> map = new HashMap<>();
            map.put("responseTime", newDay.getTime());

            //探针超时处理
            timeOutSensor(map);

            //任务超时处理
            timeOutVulTask(map);

            logUtil.info("定时检测任务结束", logSwitch);
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            e.printStackTrace();
        }

    }

    /**
     * 超时探针处理（探针超过30分钟没有心跳响应）
     *
     * @param map
     */
    public void timeOutSensor(Map<String, Object> map) throws Exception {
        List<AssetSensor> list = assetSensorDao.findLowerInfo(map);

        for (AssetSensor assetSensor : list) {
            if (assetSensor.getStatus().equals(ServerConstant.ONLINE)) {
                assetSensor.setStatus(ServerConstant.OFFLINE);
                assetSensorDao.updateAssetSensor(assetSensor);
            }

            String sensorUUID = assetSensor.getUuid();

            //移除消息队列中该探针的消息并修改sensorMessage表状态
            operatorMessage(sensorUUID);

            //获取该探针下未完成的任务
            List<VulTaskStatus> tasks = vulTaskStatusDao.selectBySensorUUID(sensorUUID);

            if (tasks != null && tasks.size() > 0) {
                //更新该探针下的所有任务进度及时间 speed=100 endTime
                VulTaskStatus vulTaskStatus = new VulTaskStatus();
                vulTaskStatus.setPercent(100);
                vulTaskStatus.setSensorUuid(sensorUUID);
                vulTaskStatus.setEndTime(System.currentTimeMillis());
                //超时结束
                vulTaskStatus.setStatus(0);
                vulTaskStatusDao.updateVulTaskStatusBySensorUUID(vulTaskStatus);

                //检查任务是否都完成，如果都完成更新vulTaskRecord表结束时间
                for (VulTaskStatus taskStatus : tasks) {
                    String seqUUID = taskStatus.getRecordUuid();
                    int count = vulTaskStatusDao.selectCountNotFinishNum(seqUUID);

                    if (count == 0) {
                        Map<String, Object> map1 = new HashMap<>();
                        map1.put("uuid", seqUUID);
                        map1.put("endTime", System.currentTimeMillis());
                        vulTaskRecordDao.updateVulTaskRecordEndTime(map1);
                    }
                }
            }

        }
    }

    /**
     * 超时任务处理（探针活着，任务挂了）
     *
     * @param map
     */
    public void timeOutVulTask(Map<String, Object> map) {
        //获取超时未完成的任务
        List<VulTaskStatus> tasks = vulTaskStatusDao.findLowerTask(map);
        if (tasks != null && tasks.size() > 0) {
            for (VulTaskStatus taskStatus : tasks) {

                //更新任务进度及状态
                taskStatus.setPercent(100);
                taskStatus.setEndTime(System.currentTimeMillis());
                taskStatus.setStatus(0);
                vulTaskStatusDao.updateVulTaskStatus(taskStatus);

                //检查任务是否都完成，如果都完成更新vulTaskRecord表结束时间
                String seqUUID = taskStatus.getRecordUuid();
                int count = vulTaskStatusDao.selectCountNotFinishNum(seqUUID);
                if (count == 0) {
                    Map<String, Object> map1 = new HashMap<>();
                    map1.put("uuid", seqUUID);
                    map1.put("endTime", System.currentTimeMillis());
                    vulTaskRecordDao.updateVulTaskRecordEndTime(map1);
                }
            }
        }
    }


    /**
     * 离线探针消息的清除
     *
     * @param sensorUUID
     * @throws Exception
     */
    public void operatorMessage(String sensorUUID) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        SensorMessage sensorMessage = SensorMessage.getInstance();

        //移除消息队列中改探针的消息并修改sensorMessage表状态
        LinkedList<MessageObj> messageObjList = sensorMessage.getMesaageObjList(sensorUUID);

        ArrayList<MessageObj> del = new ArrayList<>();

        for (MessageObj messageObj : messageObjList) {
            String message = messageObj.getMessage();
            JsonNode node = mapper.readTree(message);
            int operator = node.get("operator").asInt();
            //只清除任务，保留通报消息
            if (operator == ServerConstant.OPERATOR_TASK_START) {
                //消息表修改状态
                String sensorMessageUUID = messageObj.getMessageUUID();
                SensorMessageVo sensorMessageBean = new SensorMessageVo();
                sensorMessageBean.setId(Integer.valueOf(sensorMessageUUID));
                sensorMessageBean.setStatus(2);//作废
                sensorMessageVoMapper.updateSensorMessage(sensorMessageBean);
                del.add(messageObj);
            }
        }
        //消息队列中删除改探针消息
        for (MessageObj messageObj : del) {
            messageObjList.remove(messageObj);
        }
    }

    /**
     * 设置探针离线
     * @param sensorUUID
     */
    @Override
    public void sensorTimeOut(String sensorUUID) {
        logUtil.info("探针离线：" + sensorUUID, logSwitch);
        try {
            SensorManageVo sensorManageVo =new SensorManageVo();
            sensorManageVo.setStatus(ServerConstant.OFFLINE);
            sensorManageVo.setSensorId(Integer.valueOf(sensorUUID));

            sensorManageVoMapper.updateByPrimaryKeySelective(sensorManageVo);
        } catch (Exception e) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            e.printStackTrace();
        }
    }


}
