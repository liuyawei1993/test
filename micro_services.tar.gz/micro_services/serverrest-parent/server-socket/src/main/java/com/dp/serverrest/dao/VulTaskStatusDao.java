package com.dp.serverrest.dao;

import com.dp.serverrest.bean.VulTaskStatus;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface VulTaskStatusDao {

    /**
     * 更新vulTaskStatus表
     * @param vulTaskStatus
     * @return
     */
    int updateVulTaskStatus(VulTaskStatus vulTaskStatus);

    /**
     * 根据recordUuid查询未完成的任务数量
     * @param recordUuid
     * @return
     */
    int selectCountNotFinishNum(String recordUuid);

    /**
     * 根须sensoruuid更新任务完成状态
     * @param vulTaskStatus
     */
    void updateVulTaskStatusBySensorUUID(VulTaskStatus vulTaskStatus);

    List<VulTaskStatus> selectBySensorUUID(String sensorUUID);

    /**
     * 获取超时任务
     * @param map
     * @return
     */
    List<VulTaskStatus> findLowerTask(Map<String, Object> map);

    /**
     * 保存信息
     * @param vulTaskStatus
     */
    void saveVulTaskStatus(VulTaskStatus vulTaskStatus);
}
