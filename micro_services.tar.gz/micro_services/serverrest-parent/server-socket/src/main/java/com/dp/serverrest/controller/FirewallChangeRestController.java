package com.dp.serverrest.controller;

import com.dp.serverrest.service.api.FirewallService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Created by jed on 19-7-6.
 * 防火墙操作路由控制
 */
@RestController
@RequestMapping(value = "/api/firewallChange")
public class FirewallChangeRestController {

    @Autowired
    private FirewallService firewallService;

    /**
     * 增加新的探针信息到防火墙
     * @param sensorIp
     * @param ports
     * @return
     */
    @RequestMapping(value = "addSensorToFirewall", method = RequestMethod.POST)
    public Map<String, String> addSensorToFirewall(@RequestBody String sensorIp, @RequestBody int[] ports) {
        System.out.println(sensorIp + "\t" + ports);

        return firewallService.addSensorToFirewall(sensorIp, ports);
    }

    /**
     * 删除防火墙中的探针信息
     * @param sensorIp
     * @return
     */
    @RequestMapping(value = "deleteSensorFromFirewall", method = RequestMethod.POST)
    public Map<String, String> deleteSensorFromFirewall(@RequestBody String sensorIp) {
        return firewallService.deleteSensorFromFirewall(sensorIp);
    }
}
