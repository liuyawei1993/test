package com.dp.serverrest.service.util;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;

@Component
public class ESutil {
//    @Value("${ES_CLUSTER_NAME}")
//    public  String CLUSTER_NAME;//Elasticsearch集群名称
//    @Value("${ES_HOST_IP}")
//    public  String HOST_IP;//Elasticsearch集群节点
//    @Value("${ES_TCP_PORT}")
//    public  int TCP_PORT;//Elasticsearch节点TCP通讯端口
//    private volatile static TransportClient client;//客户端对象,用于连接到Elasticsearch集群
//
//    /**
//     * Elasticsearch Java API 的相关操作都是通过TransportClient对象与Elasticsearch集群进行交互的。
//     * 为了避免每次请求都创建一个新的TransportClient对象,可以封装一个双重加锁单例模式返回TransportClient对象。
//     * 即同时使用volatile和synchronized。volatile是Java提供的一种轻量级的同步机制,synchronized通常称为重量级同步锁。
//     *
//     * @author moonxy
//     */
//    public TransportClient getSingleTransportClient() {
//
//        Settings settings = Settings.builder().put("cluster.name", CLUSTER_NAME).build();
//        try {
//            if (client == null) {
//                synchronized (TransportClient.class) {
//                    client = new PreBuiltTransportClient(settings).addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName(HOST_IP), TCP_PORT));
//                }
//            }
//        } catch (UnknownHostException e) {
//            e.printStackTrace();
//        }
//        return client;
//    }
}
