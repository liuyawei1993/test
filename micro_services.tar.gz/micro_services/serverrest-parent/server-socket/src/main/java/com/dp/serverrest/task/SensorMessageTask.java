package com.dp.serverrest.task;

import com.dp.serverrest.service.api.SensorManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

/**
 * 定时任务
 */

@Component
@Configuration
@EnableScheduling
public class SensorMessageTask {

    @Autowired
    private SensorManageService sensorManageService;

    /**
     * 每隔5分钟检查探针超时时间
     */
//    @Scheduled(initialDelay = 5 * 60 * 1000, fixedDelay = 5 * 60 * 1000)
    public void messageTask() {
        sensorManageService.checkMessage();
    }
}
