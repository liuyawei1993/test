package com.dp.serverrest.controller;

import com.dp.serverrest.service.api.CertificateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Created by jxl on 19-8-9.
 * 证书申请
 */
@RestController
@RequestMapping(value = "/api/certificateControl")
public class CertificateController {

    @Autowired
    private CertificateService certificateService;


    /**
     * 证书申请
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/certificateApply")
    public Map<String, String> certificateApply(@RequestParam String param) {
        return certificateService.certificateApply(param);
    }

}
