package com.dp.serverrest.service.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LogUtil {
    private Log log;

    public LogUtil(Class<?> clazz) {
        log = LogFactory.getLog(clazz);
    }

    public void info(String message, String logSwitch) {
        if (logSwitch.equals("on")) {
            log.info(message);
        }
    }
}
