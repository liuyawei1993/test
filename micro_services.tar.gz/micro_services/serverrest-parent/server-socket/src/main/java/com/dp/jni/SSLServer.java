package com.dp.jni;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.springframework.util.StringUtils;

import com.dp.serverrest.common.ServerConstant;
import com.dp.serverrest.service.api.CenterControlService;
import com.dp.serverrest.service.api.SensorManageService;
import com.dp.serverrest.service.impl.SensorManageServiceImpl;
import com.dp.serverrest.service.util.ApplicationContextUtil;
import com.dp.serverrest.service.util.LogUtil;
import com.dp.serverrest.service.util.PropertiesUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Created by jed on 19-7-8.
 */
public class SSLServer {

    private volatile static SSLServer instance = null;
    public static SSLServer getInstance() {
        if (instance == null) {
            synchronized (SSLServer.class) {
                if (instance == null) {
                    instance = new SSLServer();
                }
            }
        }

        return instance;
    }

    PropertiesUtil propertiesUtil = new PropertiesUtil();
    LogUtil logUtil = new LogUtil(SensorManageServiceImpl.class);
    private int serverSocket = -1;
    private ArrayList<String> sockets = new ArrayList<>();

    private boolean flag = true;
    ExecutorService exec;
    /**
     * 线程池数量
     */
    private int threadPoolSize = Integer.valueOf(propertiesUtil.getProperty("threadPoolSize"));
    /**
     * 心跳超时次数
     */
    private int heartTimeOutNum = Integer.valueOf(propertiesUtil.getProperty("heartTimeOutNum"));

    /**
     * 日志开关
     */
    private String logSwitch = propertiesUtil.getProperty("logSwitch");

    private SSLServer() {
//        System.load(System.getProperty("user.dir") + "/../source/libdpssl.so");
    }

    public void closessl(int socket) {
        DpSSLServerSocket.closeSSL(socket);

        if (sockets.contains(socket + ""))
            sockets.remove(socket + "");
    }

    public Map<String, String> start(int port, String serverKey, String server) {
        Map<String, String> result = new HashMap<>();

        serverSocket = DpSSLServerSocket.create(port, serverKey.getBytes(), server.getBytes(), null);

        if (DpSSLServerSocket.listen(serverSocket, 1000) != -1) {
            logUtil.info("Server socket start success", "on");
            result.put("result", "true");
        } else {
            logUtil.info("Server socket start error", "on");
            result.put("result", "error");
        }

        flag = true;
        if (serverSocket == -1) {
            return result;
        } else {

            exec = new ThreadPoolExecutor(threadPoolSize, threadPoolSize, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue());

            exec.execute(new Runnable() {
                @Override
                public void run() {
                    while (flag) {
                        int socket = DpSSLServerSocket.accept(serverSocket, 5);

                        if (socket == 0 || socket == -1) {
                            continue;
                        } else {
                            sockets.add(socket + "");

                            exec.execute(new Runnable() {
                                @Override
                                public void run() {
                                    int num = 0;//超时次数
                                    String sensorUUID = "";//探针uuid
                                    int type = ServerConstant.HEART;//1 心跳  2控制

                                    CenterControlService centerControlService = (CenterControlService) ApplicationContextUtil.getBean(CenterControlService.class);

                                    SensorManageService sensorManageService = (SensorManageService) ApplicationContextUtil.getBean(SensorManageService.class);

                                    while (flag) {
                                        try {
                                            byte[] recieve = DpSSLServerSocket.read(socket, 8);
                                            String msg = new String(recieve);
                                            logUtil.info("msg=" + msg, logSwitch);

                                            if (msg.equals(ServerConstant.ERROR) || (type == ServerConstant.HEART && num > heartTimeOutNum)) {//客户端断开或超时超过15次
                                                logUtil.info("客户端未连接或超时次数达到" + heartTimeOutNum + "次", "on");
                                                //关闭socket连接
                                                closessl(socket);
                                                //探针修改成下线
                                                if (!StringUtils.isEmpty(sensorUUID)) {
                                                    sensorManageService.sensorTimeOut(sensorUUID);
                                                }

                                                break;
                                            } else if (msg.equals(ServerConstant.TIMEOUT)) {//超时
                                                logUtil.info("客户端超时", logSwitch);
                                                num++;
                                                continue;
                                            }

                                            num = 0;

                                            //交互数据处理
                                            ObjectMapper mapper = new ObjectMapper();
                                            JsonNode rootNode = mapper.readTree(new String(recieve));
                                            type = rootNode.get("type").asInt();
                                            sensorUUID = rootNode.get("deviceUUID").asText();

                                            String response = centerControlService.messageHandle(rootNode, socket, 0, null);
//                                            String response="{\"result\":\"ok\",\"deviceUUID\":\"11111111\"}";

                                            if (response != "") {
                                                DpSSLServerSocket.write(socket, response.getBytes());
                                            }
                                            logUtil.info("结果：" + response, logSwitch);
                                            if (type == ServerConstant.CONTROL) {
                                                //关闭socket连接
                                                closessl(socket);
                                                break;
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            });
                        }
                    }
                }
            });
            return result;
        }
    }

    public void stop() {
        try {
            if (serverSocket != -1) {
                flag = false;

                Thread.sleep(6000);

                if (exec != null) {
                    exec.shutdownNow();
                }

                for (String sk : sockets) {
                    DpSSLServerSocket.closeSSL(Integer.valueOf(sk));
                }
                sockets.clear();
                DpSSLServerSocket.close(serverSocket);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}