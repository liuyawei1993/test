package com.dp.serverrest.dao;

import com.dp.serverrest.vo.SensorStatusVo;
import org.springframework.stereotype.Repository;

@Repository
public interface SensorStatusVoMapper extends BaseVoMapper{
    
    int deleteByPrimaryKey(Integer id);

    
    int insert(SensorStatusVo record);

    
    int insertSelective(SensorStatusVo record);

    
    SensorStatusVo selectByPrimaryKey(Integer id);

    
    int updateByPrimaryKeySelective(SensorStatusVo record);

    
    int updateByPrimaryKey(SensorStatusVo record);
}