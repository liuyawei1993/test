package com.dp.serverrest.dao;

import com.dp.serverrest.bean.AssetSensor;
import com.dp.serverrest.bean.AssetSensorInfo;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface AssetSensorInfoDao {

    /**
     * 更新sensorInfo表
     * @param sensorUUID
     * @return
     */
    int deleteBySensorUUID(String sensorUUID);

    /**
     * 添加一条数据
     * @param assetSensorInfo
     * @return
     */

    int insertInfo(AssetSensorInfo assetSensorInfo);



}
