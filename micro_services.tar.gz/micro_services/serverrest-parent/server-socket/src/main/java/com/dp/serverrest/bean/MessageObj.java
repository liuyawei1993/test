package com.dp.serverrest.bean;

public class MessageObj {
    private String messageUUID;
    private String message;
    public MessageObj(){}
    public MessageObj(String messageUUID,String message){
        this.messageUUID=messageUUID;
        this.message=message;
    }

    public String getMessageUUID() {
        return messageUUID;
    }

    public void setMessageUUID(String messageUUID) {
        this.messageUUID = messageUUID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
