package com.dp.serverrest.controller;

import com.dp.jni.SocketServer;
import com.dp.serverrest.service.api.CenterControlService;
import com.dp.serverrest.service.api.SensorManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by jed on 19-7-8.
 * 集控路由控制
 */
@RestController
@RequestMapping(value = "/api/centerControl")
public class CenterControlController {

    @Autowired
    private SensorManageService sensorManageService;

    @Autowired
    private CenterControlService centerControlService;

    private static String BASE_PATH = System.getProperty("user.dir");

    @Value("${SSLPORT}")
    private int port;

    @Value("${SERVERKEY_PATH}")
    private String SERVERKEY_PATH;

    @Value("${SERVER_PATH}")
    private String SERVER_PATH;

    /**
     * 启动ssl服务端
     *
     * @return
     */
    @RequestMapping(value = "/startServer")
    public Map<String, String> startServer() {

        Map<String, String> result = new HashMap<>();

        try {
            result = centerControlService.startServer(port, BASE_PATH + SERVERKEY_PATH, BASE_PATH + SERVER_PATH);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 项目启动时，启动socket并将数据库中未执行的消息放入消息队列中
     */
    @PostConstruct
    public void setSensorMessageToQueue() {
        startServer();
        sensorManageService.setSensorMessageToQueue();
    }

}
