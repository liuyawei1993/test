package com.dp.serverrest.common;

import com.dp.serverrest.bean.MessageObj;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by jed on 19-7-8.
 */
public class SensorMessage {
    private volatile static SensorMessage instance = null;
    private Map<String, LinkedList<MessageObj>> messageMap;

    private SensorMessage() {
        messageMap = new ConcurrentHashMap<>();
    }

    public static SensorMessage getInstance() {
        if (instance == null) {
            synchronized (SensorMessage.class) {
                if (instance == null) {
                    instance = new SensorMessage();
                }
            }
        }

        return instance;
    }

    /**
     * 添加新的消息到探针消息队列
     *
     * @param sensor
     * @param message
     */
    public void pushMessage(String sensor, String messageUUID, String message) {
        MessageObj messageObj = new MessageObj(messageUUID, message);
        if (messageMap.get(sensor) == null) {
            LinkedList<MessageObj> messages = new LinkedList<>();
            messages.add(messageObj);
            messageMap.put(sensor, messages);
        } else {
            messageMap.get(sensor).add(messageObj);
        }
    }

    /**
     * 从探针消息队列读取最早的一条消息
     *
     * @param sensor
     * @return
     */
    public MessageObj popMessage(String sensor) {
        if (messageMap.get(sensor) == null || messageMap.get(sensor).size() == 0) {
            return new MessageObj();
        } else {
            return messageMap.get(sensor).pop();
        }
    }

    /**
     * 从探针消息队列删除一条消息
     *
     * @param sensor
     */
    public void delMessage(String sensor) {
        if (messageMap.get(sensor) == null || messageMap.get(sensor).size() != 0) {
            messageMap.remove(sensor);
        }
    }

    /**
     * 根据探针获取消息集合
     * @param sensor
     * @return
     */
    public LinkedList<MessageObj> getMesaageObjList(String sensor){
        if (messageMap.get(sensor) == null || messageMap.get(sensor).size() == 0) {
            return new LinkedList<MessageObj>();
        } else {
            return messageMap.get(sensor);
        }
    }


}
