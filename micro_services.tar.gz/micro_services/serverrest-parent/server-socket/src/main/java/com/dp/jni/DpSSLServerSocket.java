package com.dp.jni;

/**
 * Created by jed on 19-7-8.
 */
public class DpSSLServerSocket {
    public DpSSLServerSocket() {
    }

    public static native int create(int port, byte[] serverKey, byte[] server, byte[] clientKey);

    public static native int listen(int serverSocket, int count);

    public static native int accept(int serverSocket, int timeOut);

    public static native byte[] read(int socket, int timeOut);

    public static native int write(int socket, byte[] message);

    public static native void closeSSL(int socket);

    public static native void close(int serverSocket);

    public static native int writebuf(int socket, byte[] buffer, int length);

    public static native byte[] readbuf(int socket, int length);
}
