package com.dp.serverrest.bean;

public class AssetSensor {
    private Integer id;
    private String sensorName;
    private String assetName;
    private String status;
    private String address;
    private String checkType;
    private String uuid;
    private String description;
    private String sensorIp;
    private String cpuProc;
    private String cpuFreq;
    private String cpuName;
    private String memorySize;
    private String diskSize;
    private String cpuUsage;
    private String memoryUsage;
    private String diskUsage;
    private Long responseTime;
    public AssetSensor(){}

    public AssetSensor(String uuid, String cpuUsage, String memoryUsage, String diskUsage,long responseTime,String status) {
        this.uuid = uuid;
        this.cpuUsage = cpuUsage;
        this.memoryUsage = memoryUsage;
        this.diskUsage = diskUsage;
        this.responseTime=responseTime;
        this.status=status;

    }

    public AssetSensor(String uuid, String cpuProc, String cpuFreq, String cpuName, String memorySize, String diskSize,long responseTime,String status,String sensorIp) {
        this.uuid = uuid;
        this.cpuProc = cpuProc;
        this.cpuFreq = cpuFreq;
        this.cpuName = cpuName;
        this.memorySize = memorySize;
        this.diskSize = diskSize;
        this.responseTime=responseTime;
        this.status=status;
        this.sensorIp=sensorIp;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSensorName() {
        return sensorName;
    }

    public void setSensorName(String sensorName) {
        this.sensorName = sensorName;
    }

    public String getAssetName() {
        return assetName;
    }

    public void setAssetName(String assetName) {
        this.assetName = assetName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCheckType() {
        return checkType;
    }

    public void setCheckType(String checkType) {
        this.checkType = checkType;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSensorIp() {
        return sensorIp;
    }

    public void setSensorIp(String sensorIp) {
        this.sensorIp = sensorIp;
    }

    public String getCpuProc() {
        return cpuProc;
    }

    public void setCpuProc(String cpuProc) {
        this.cpuProc = cpuProc;
    }

    public String getCpuFreq() {
        return cpuFreq;
    }

    public void setCpuFreq(String cpuFreq) {
        this.cpuFreq = cpuFreq;
    }

    public String getCpuName() {
        return cpuName;
    }

    public void setCpuName(String cpuName) {
        this.cpuName = cpuName;
    }

    public String getMemorySize() {
        return memorySize;
    }

    public void setMemorySize(String memorySize) {
        this.memorySize = memorySize;
    }

    public String getDiskSize() {
        return diskSize;
    }

    public void setDiskSize(String diskSize) {
        this.diskSize = diskSize;
    }

    public String getCpuUsage() {
        return cpuUsage;
    }

    public void setCpuUsage(String cpuUsage) {
        this.cpuUsage = cpuUsage;
    }

    public String getMemoryUsage() {
        return memoryUsage;
    }

    public void setMemoryUsage(String memoryUsage) {
        this.memoryUsage = memoryUsage;
    }

    public String getDiskUsage() {
        return diskUsage;
    }

    public void setDiskUsage(String diskUsage) {
        this.diskUsage = diskUsage;
    }

    public Long getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Long responseTime) {
        this.responseTime = responseTime;
    }
}
