package com.dp.serverrest.service.api;

import java.util.Map;

/**
 * Created by jed on 19-7-8.
 */
public interface SensorManageService extends BaseService {

    public Map<String, String> pushNewMessage(String sensor,String messageId, String message);

    public void checkMessage();

    public void setSensorMessageToQueue();

    public void sensorTimeOut(String sensorUUID);

}
