package com.dp.serverrest.dao;

import com.dp.serverrest.vo.SensorCfgVo;
import com.dp.serverrest.vo.SensorCfgVoWithBLOBs;
import org.springframework.stereotype.Repository;

@Repository
public interface SensorCfgVoMapper extends BaseVoMapper {
    
    int deleteByPrimaryKey(Integer sensorId);

    
    int insert(SensorCfgVoWithBLOBs record);

    
    int insertSelective(SensorCfgVoWithBLOBs record);

    
    SensorCfgVoWithBLOBs selectByPrimaryKey(Integer sensorId);

    
    int updateByPrimaryKey(SensorCfgVo record);

    
    int updateByPrimaryKeySelective(SensorCfgVoWithBLOBs record);

    
    int updateByPrimaryKeyWithBLOBs(SensorCfgVoWithBLOBs record);
}