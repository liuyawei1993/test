package com.dp.serverrest.service.api;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by jed on 19-7-8.
 */
public interface BaseService {
    Map<String, String> result = new HashMap<>();
}
