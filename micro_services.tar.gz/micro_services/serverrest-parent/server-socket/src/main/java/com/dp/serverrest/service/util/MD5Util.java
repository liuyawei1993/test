package com.dp.serverrest.service.util;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.poi.util.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class MD5Util {
    public static String getMD5(FileInputStream fis) {
        String md5 = "";
        try {
            md5 = DigestUtils.md5Hex(IOUtils.toByteArray(fis));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return md5;

    }

    public static String getMD5ByCMD(String path) {
        String md5 = "";
        try {

            String[] execute = {"/bin/sh", "-c", "md5sum " + path + " |cut -d ' ' -f1"};

            md5 = CmdUtil.executeCMD4Res(execute).trim();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return md5;

    }


    public static void main(String[] args) throws IOException {
//        FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/../ideaIU-2019.1.1.tar.gz");
//        System.out.println(getMD5(fis));
        String path = System.getProperty("user.dir") + "/../source/sensorVersion/library/平台.rar";
        File file =new File(path);
        System.out.println(file.length());
        System.out.println(getMD5ByCMD(path));
    }


}
