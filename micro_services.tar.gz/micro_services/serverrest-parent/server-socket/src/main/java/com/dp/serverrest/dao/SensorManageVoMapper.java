package com.dp.serverrest.dao;


import com.dp.serverrest.vo.SensorManageVo;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface SensorManageVoMapper extends BaseVoMapper{
    
    int deleteByPrimaryKey(Integer sensorId);

    
    int insert(SensorManageVo record);

    
    int insertSelective(SensorManageVo record);

    
    SensorManageVo selectByPrimaryKey(Integer sensorId);
    
    List<SensorManageVo> selectAll();

    
    int updateByPrimaryKeySelective(SensorManageVo record);

    
    int updateByPrimaryKey(SensorManageVo record);

    SensorManageVo selectBySensorName(String sensorName);

    int updateSensorToOffline();
}