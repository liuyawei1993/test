package com.dp.serverrest.dao;

import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface CenterControlDao {

    /**
     * 根据taskUUID获取任务配置中心
     * @param taskUUID
     * @return
     */
    Map<String,Object>  searchTaskConfigByUUID(String taskUUID);


}
