/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/** 
	* @author author zhangchao: 
	* @version 创建时间：2019年9月10日 下午5:21:00 
	* 
	*/
@RestController
@RequestMapping(value = "/api/test")
public class TestController {
    @RequestMapping(value = "test", method = RequestMethod.GET)
    public String get() {
	System.err.println();
	return "Hello from get";
    }
}
