package com.dp.serverrest.dao;

import com.dp.serverrest.bean.VulTaskRecord;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface VulTaskRecordDao {


    /**
     * 保存信息
     * @param vulTaskRecord
     */
    void saveRecord(VulTaskRecord vulTaskRecord);

    /**
     * 更新结束时间
     * @param map
     * @return
     */
    int updateVulTaskRecordEndTime(Map<String,Object> map);


}
