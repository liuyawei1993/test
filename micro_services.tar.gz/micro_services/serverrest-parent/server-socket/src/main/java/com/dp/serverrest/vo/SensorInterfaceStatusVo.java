package com.dp.serverrest.vo;

public class SensorInterfaceStatusVo {
    
    private Integer id;

    
    private Integer infId;

    
    private Long timeStamp;

    
    private String name;

    
    private Long inBytes;

    
    private Long outBytes;

    
    private Long inPackets;

    
    private Long outPackets;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public Integer getInfId() {
        return infId;
    }

    
    public void setInfId(Integer infId) {
        this.infId = infId;
    }

    
    public Long getTimeStamp() {
        return timeStamp;
    }

    
    public void setTimeStamp(Long timeStamp) {
        this.timeStamp = timeStamp;
    }

    
    public String getName() {
        return name;
    }

    
    public void setName(String name) {
        this.name = name;
    }

    
    public Long getInBytes() {
        return inBytes;
    }

    
    public void setInBytes(Long inBytes) {
        this.inBytes = inBytes;
    }

    
    public Long getOutBytes() {
        return outBytes;
    }

    
    public void setOutBytes(Long outBytes) {
        this.outBytes = outBytes;
    }

    
    public Long getInPackets() {
        return inPackets;
    }

    
    public void setInPackets(Long inPackets) {
        this.inPackets = inPackets;
    }

    
    public Long getOutPackets() {
        return outPackets;
    }

    
    public void setOutPackets(Long outPackets) {
        this.outPackets = outPackets;
    }
}