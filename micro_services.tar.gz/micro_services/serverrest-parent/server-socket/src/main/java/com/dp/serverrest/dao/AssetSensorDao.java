package com.dp.serverrest.dao;

import com.dp.serverrest.bean.AssetSensor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface AssetSensorDao {

    /**
     * 更新sensorInfo表
     * @param assetSensor
     * @return
     */
    int updateAssetSensor(AssetSensor assetSensor);

    /**
     * 根据deviceName获取uuid
     * @param deviceName
     * @return
     */

    Map<String,Object> searchUUIDBydeviceName(String deviceName);

    /**
     * 查询下线探针
     * @return
     */
    List<AssetSensor> findLowerInfo(Map<String,Object> map);

    /**
     * 根据UUID获取探针信息
     * @param uuid
     * @return
     */
    AssetSensor getSensorInfoByUUID(String uuid);

    /**
     * 在线探针改为离线
     */
    void updateAssetSensorToOffline();

    /**
     * 根据uuid设置探针离线
     */
    void updateAssetSensorToOfflineByUUID(String uuid);
}
