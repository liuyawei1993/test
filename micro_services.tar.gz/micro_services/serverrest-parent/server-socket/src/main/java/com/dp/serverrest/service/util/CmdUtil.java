package com.dp.serverrest.service.util;

import org.springframework.util.StringUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CmdUtil {

    public static void executeCMD(String[] executes) {
        try {
            Runtime cmd = Runtime.getRuntime();
            Process process = cmd.exec(executes);
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static String executeCMD4Res(String[] executes) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            Runtime cmd = Runtime.getRuntime();
            Process process = cmd.exec(executes);
            process.waitFor();

            BufferedReader bf = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader bf2 = new BufferedReader(new InputStreamReader(process.getErrorStream()));

            String line = null;
            while ((line = bf.readLine()) != null) {
                if (!StringUtils.isEmpty(line)) {
                    stringBuilder.append(line).append("\n");
                }
            }
            while ((line = bf2.readLine()) != null) {
                if (!StringUtils.isEmpty(line)) {
                    stringBuilder.append(line).append("\n");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "error";
        }
        return stringBuilder.toString();
    }
}
