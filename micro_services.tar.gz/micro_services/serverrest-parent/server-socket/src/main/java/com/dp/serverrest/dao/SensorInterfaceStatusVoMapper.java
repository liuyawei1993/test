package com.dp.serverrest.dao;

import com.dp.serverrest.vo.SensorInterfaceStatusVo;
import org.springframework.stereotype.Repository;

@Repository
public interface SensorInterfaceStatusVoMapper extends BaseVoMapper {

    int deleteByPrimaryKey(Integer id);


    int insert(SensorInterfaceStatusVo record);


    int insertSelective(SensorInterfaceStatusVo record);


    SensorInterfaceStatusVo selectByPrimaryKey(Integer id);


    int updateByPrimaryKeySelective(SensorInterfaceStatusVo record);


    int updateByPrimaryKey(SensorInterfaceStatusVo record);

    int deleteBySensorId(Integer sensorId);
}