package com.dp.serverrest.dao;

import com.dp.serverrest.bean.SystemUserLog;
import org.springframework.stereotype.Repository;

@Repository
public interface SystemUserLogDao {

    /**
     * 添加系统日志
     * @param systemUserLog
     * @return
     */
    int insertLog(SystemUserLog systemUserLog);


}
