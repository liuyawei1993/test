package com.dp.serverrest.bean;

/**
 * Created by jed on 19-7-8.
 * 资产信息
 */
public class VulTaskConfig {
    private int id;
    private String uuid;
    private String taskName;
    private int checkType;
    private String policyList;
    private int targetType;
    private int targetGroup;
    private String targetIps;
    private String targetNames;
    private String vulSensor;
    private int executeType;
    private String executeTime;
    private long lastExecuteTime;
    private long createTime;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public int getCheckType() {
        return checkType;
    }

    public void setCheckType(int checkType) {
        this.checkType = checkType;
    }

    public String getPolicyList() {
        return policyList;
    }

    public void setPolicyList(String policyList) {
        this.policyList = policyList;
    }

    public int getTargetType() {
        return targetType;
    }

    public void setTargetType(int targetType) {
        this.targetType = targetType;
    }

    public int getTargetGroup() {
        return targetGroup;
    }

    public void setTargetGroup(int targetGroup) {
        this.targetGroup = targetGroup;
    }

    public String getTargetIps() {
        return targetIps;
    }

    public void setTargetIps(String targetIps) {
        this.targetIps = targetIps;
    }

    public String getTargetNames() {
        return targetNames;
    }

    public void setTargetNames(String targetNames) {
        this.targetNames = targetNames;
    }

    public String getVulSensor() {
        return vulSensor;
    }

    public void setVulSensor(String vulSensor) {
        this.vulSensor = vulSensor;
    }

    public int getExecuteType() {
        return executeType;
    }

    public void setExecuteType(int executeType) {
        this.executeType = executeType;
    }

    public String getExecuteTime() {
        return executeTime;
    }

    public void setExecuteTime(String executeTime) {
        this.executeTime = executeTime;
    }

    public long getLastExecuteTime() {
        return lastExecuteTime;
    }

    public void setLastExecuteTime(long lastExecuteTime) {
        this.lastExecuteTime = lastExecuteTime;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }
}
