package com.dp.serverrest.service.api;

import com.fasterxml.jackson.databind.JsonNode;

import java.net.Socket;
import java.util.Map;

/**
 * Created by jed on 19-7-10.
 */
public interface CenterControlService extends BaseService {

    String messageHandle(JsonNode rootNode, int socketInt, int type, Socket socket1) throws Exception;

    Map<String, String> startServer(int port, String serverKey, String server) throws Exception;
}
