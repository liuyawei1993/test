/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.vo;
/** 
	* @author author zhangchao: 
	* @version 创建时间：2019年8月17日 下午3:12:32 
	* 
	*/

public class SensorStatusInfoVo {

}
