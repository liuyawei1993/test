package com.dp.serverrest.vo;

public class SensorCfgVoWithBLOBs extends SensorCfgVo {
    
    private String trafficPolicy;

    
    private String attackPolicy;

    
    public String getTrafficPolicy() {
        return trafficPolicy;
    }

    
    public void setTrafficPolicy(String trafficPolicy) {
        this.trafficPolicy = trafficPolicy;
    }

    
    public String getAttackPolicy() {
        return attackPolicy;
    }

    
    public void setAttackPolicy(String attackPolicy) {
        this.attackPolicy = attackPolicy;
    }
}