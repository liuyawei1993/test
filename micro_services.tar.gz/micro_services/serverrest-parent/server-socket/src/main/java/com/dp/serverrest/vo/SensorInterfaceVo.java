package com.dp.serverrest.vo;

public class SensorInterfaceVo {

    private Integer infId;


    private Integer sensorId;


    private String name;


    private String ip;


    private String mac;


    private String status;


    private String type;

    private Integer flowStatus;

    private Integer attackStatus;


    public Integer getInfId() {
        return infId;
    }


    public void setInfId(Integer infId) {
        this.infId = infId;
    }


    public Integer getSensorId() {
        return sensorId;
    }


    public void setSensorId(Integer sensorId) {
        this.sensorId = sensorId;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public String getIp() {
        return ip;
    }


    public void setIp(String ip) {
        this.ip = ip;
    }


    public String getMac() {
        return mac;
    }


    public void setMac(String mac) {
        this.mac = mac;
    }


    public String getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = status;
    }


    public String getType() {
        return type;
    }


    public void setType(String type) {
        this.type = type;
    }

    public Integer getFlowStatus() {
        return flowStatus;
    }

    public void setFlowStatus(Integer flowStatus) {
        this.flowStatus = flowStatus;
    }

    public Integer getAttackStatus() {
        return attackStatus;
    }

    public void setAttackStatus(Integer attackStatus) {
        this.attackStatus = attackStatus;
    }
}