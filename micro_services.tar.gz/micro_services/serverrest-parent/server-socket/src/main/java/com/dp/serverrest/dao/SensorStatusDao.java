package com.dp.serverrest.dao;

import com.dp.serverrest.bean.SensorStatus;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface SensorStatusDao {

    /**
     * sensorStatus插入一条数据
     * @param sensorStatus
     * @return
     */
    int insertSensorStatus(SensorStatus sensorStatus);


}
