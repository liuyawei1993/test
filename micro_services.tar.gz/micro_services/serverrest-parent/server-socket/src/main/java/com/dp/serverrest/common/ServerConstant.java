package com.dp.serverrest.common;

public interface ServerConstant {
    /**
     * 心跳 1
     */
    int HEART = 1;

    /**
     * 控制 2
     */
    int CONTROL = 2;

    /**
     * 信息关联 1100
     */
    int OPERATOR_INFORELATION = 1100;
    /**
     * 信息初始化 1101
     */
    int OPERATOR_INITINFO = 1101;

    /**
     * 探针配置获取 1002
     */
    int OPERATOR_SENSORCONFIG = 1102;
    /**
     * 版本下发
     */
    int OPERATOR_FILE_ISSUED = 1103;

    /**
     * 任务配置获取 1004
     */
    int OPERATOR_TASKCONFIG = 1004;

    /**
     * 整改通报确认 1007
     */
    int OPERATOR_HOSTINFO = 1007;

    /**
     * 消息--任务启动 1004
     */
    int OPERATOR_TASK_START = 1004;

    /**
     * 探针文件上报
     */
    int OPERATOR_FILE_REPORTED = 1010;

    /**
     * 客户端未连接
     */
    String ERROR = "ERROR";

    /**
     * 客户端连接超时
     */
    String TIMEOUT = "TIMEOUT";
    /**
     * 未认证
     */
    String UNVERIFIED = "待初始化";
    /**
     * 在线
     */
    String ONLINE = "正常";
    /**
     * 离线
     */
    String OFFLINE = "离线";

}
