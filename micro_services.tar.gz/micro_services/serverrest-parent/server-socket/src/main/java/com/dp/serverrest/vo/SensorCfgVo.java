package com.dp.serverrest.vo;

public class SensorCfgVo {
    
    private Integer sensorId;

    
    private Integer trafficEnable;

    
    private Integer attackEnable;

    
    private String trafficLogIp;

    
    private String attackLogIp;

    
    private String softVersion;

    
    private String sigVersion;

    
    public Integer getSensorId() {
        return sensorId;
    }

    
    public void setSensorId(Integer sensorId) {
        this.sensorId = sensorId;
    }

    
    public Integer getTrafficEnable() {
        return trafficEnable;
    }

    
    public void setTrafficEnable(Integer trafficEnable) {
        this.trafficEnable = trafficEnable;
    }

    
    public Integer getAttackEnable() {
        return attackEnable;
    }

    
    public void setAttackEnable(Integer attackEnable) {
        this.attackEnable = attackEnable;
    }

    
    public String getTrafficLogIp() {
        return trafficLogIp;
    }

    
    public void setTrafficLogIp(String trafficLogIp) {
        this.trafficLogIp = trafficLogIp;
    }

    
    public String getAttackLogIp() {
        return attackLogIp;
    }

    
    public void setAttackLogIp(String attackLogIp) {
        this.attackLogIp = attackLogIp;
    }

    
    public String getSoftVersion() {
        return softVersion;
    }

    
    public void setSoftVersion(String softVersion) {
        this.softVersion = softVersion;
    }

    
    public String getSigVersion() {
        return sigVersion;
    }

    
    public void setSigVersion(String sigVersion) {
        this.sigVersion = sigVersion;
    }
}