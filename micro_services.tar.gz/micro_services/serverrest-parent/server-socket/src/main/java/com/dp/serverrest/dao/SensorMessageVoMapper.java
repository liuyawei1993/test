package com.dp.serverrest.dao;

import com.dp.serverrest.vo.SensorMessageVo;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface SensorMessageVoMapper {

    /**
     * 更新消息状态
     * @param sensorMessageBean
     * @return
     */

    int updateSensorMessage(SensorMessageVo sensorMessageBean);

    /**
     * 获取未下发的消息
     * @return
     */
    List<SensorMessageVo> getNoDeployMessageList();

    /**
     * 保存信息
     * @param sensorMessageBean
     */
   void saveSensorMessage(SensorMessageVo sensorMessageBean);
}
