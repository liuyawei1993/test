package com.dp.jni;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.springframework.util.StringUtils;

import com.dp.serverrest.common.ServerConstant;
import com.dp.serverrest.service.api.CenterControlService;
import com.dp.serverrest.service.api.SensorManageService;
import com.dp.serverrest.service.impl.SensorManageServiceImpl;
import com.dp.serverrest.service.util.ApplicationContextUtil;
import com.dp.serverrest.service.util.LogUtil;
import com.dp.serverrest.service.util.PropertiesUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


public class SocketServer {

    private volatile static SocketServer instance = null;
    public static SocketServer getInstance() {
        if (instance == null) {
            synchronized (SocketServer.class) {
                if (instance == null) {
                    instance = new SocketServer();
                }
            }
        }

        return instance;
    }

    PropertiesUtil propertiesUtil = new PropertiesUtil();
    LogUtil logUtil = new LogUtil(SensorManageServiceImpl.class);
    private ServerSocket serverSocket;
    private ArrayList<Socket> sockets = new ArrayList<>();
    private boolean flag = true;

    private boolean socketFlag = true;
    /**
     * //线程池
     */
    ExecutorService exec;
    /**
     * 线程池数量
     */
    private int threadPoolSize = Integer.valueOf(propertiesUtil.getProperty("threadPoolSize"));
    /**
     * 心跳超时次数
     */
    private int heartTimeOutNum = Integer.valueOf(propertiesUtil.getProperty("heartTimeOutNum"));

    /**
     * 日志开关
     */
    private String logSwitch = propertiesUtil.getProperty("logSwitch");

    private SocketServer() {
//        System.load(System.getProperty("user.dir") + "/../source/libdpssl.so");
    }

    public void closeSocket(Socket socket) throws Exception {
        socket.shutdownOutput();
        socket.shutdownInput();
        socket.close();

        if (sockets.contains(socket)) {
            sockets.remove(socket);
        }

    }

    public Map<String, String> start(int port) {
        Map<String, String> result = new HashMap<>();

        try {
            serverSocket = new ServerSocket(port);
            logUtil.info("Server socket start success", "on");
            result.put("result", "true");
        } catch (Exception e) {
            e.printStackTrace();
            logUtil.info("Server socket start error", "on");
            result.put("result", "error");
        }

        flag = true;
        socketFlag = true;

        exec = new ThreadPoolExecutor(threadPoolSize, threadPoolSize, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue());

        exec.execute(new Runnable() {
            @Override
            public void run() {
                while (flag) {
                    try {
                        Socket socket = serverSocket.accept();
                        //若长时间没有连接则断开
                        socket.setKeepAlive(true);
                        //允许发送紧急数据，不做处理
//                        socket.setOOBInline(true);
                        socket.setSoTimeout(5000);
                        logUtil.info("socket=" + socket, logSwitch);
                        sockets.add(socket);

                        exec.execute(new Runnable() {
                            @Override
                            public void run() {

                                try {
                                    int num = 1;//超时次数
                                    String sensorUUID = "";//探针uuid
                                    int type = ServerConstant.HEART;//1 心跳  2控制

                                    CenterControlService centerControlService = (CenterControlService) ApplicationContextUtil.getBean(CenterControlService.class);

                                    SensorManageService sensorManageService = (SensorManageService) ApplicationContextUtil.getBean(SensorManageService.class);

                                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                                    BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                    while (socketFlag) {

                                        String recieve = "";
                                        try {
                                            recieve = br.readLine();
                                        } catch (SocketTimeoutException e) {
                                            if (num >= heartTimeOutNum) {
                                                logUtil.info("客户端超时次数达到" + heartTimeOutNum + "次", "on");
                                                closeSocket(socket);
                                                //探针修改成下线
                                                if (!StringUtils.isEmpty(sensorUUID)) {
                                                    sensorManageService.sensorTimeOut(sensorUUID);
                                                }
                                                break;
                                            }
                                            logUtil.info("探针连接超时" + num + "次", "on");
                                            num++;

                                            continue;
                                        }

                                        logUtil.info("msg=" + recieve, logSwitch);

                                        if (recieve != null) {
                                            num = 1;
//
                                            //交互数据处理
                                            ObjectMapper mapper = new ObjectMapper();
                                            JsonNode rootNode = mapper.readTree(recieve);
                                            type = rootNode.get("type").asInt();
                                            sensorUUID = rootNode.get("deviceUUID").asText();

                                            String response = centerControlService.messageHandle(rootNode, 0,1,socket);
//                                            String response = "{\"result\":\"ok\",\"deviceUUID\":\"11111111\"}";

                                            if (response != "") {
                                                bw.write(response);
                                                bw.flush();
                                            }
                                            logUtil.info("结果：" + response, logSwitch);
                                            if (type == ServerConstant.CONTROL) {
                                                closeSocket(socket);
                                                break;
                                            }
                                        } else {
                                            logUtil.info("客户端断开连接", "on");
                                            closeSocket(socket);

                                            //探针修改成下线
                                            if (!StringUtils.isEmpty(sensorUUID)) {
                                                sensorManageService.sensorTimeOut(sensorUUID);
                                            }
                                            break;
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    try {
                                        logUtil.info("系统报错，关闭连接", "on");
                                        closeSocket(socket);
                                    }catch (Exception e1){
                                        e1.printStackTrace();
                                    }
                                }

                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        return result;
    }

    public void stop() {
        try {
            if (serverSocket != null) {
                flag = false;
                socketFlag = false;
                Thread.sleep(6000);

                if (exec != null) {
                    exec.shutdownNow();
                }

                for (Socket socket : sockets) {
                    socket.shutdownOutput();
                    socket.shutdownInput();
                    socket.close();
                }

                serverSocket.close();

                sockets.clear();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}