package com.dp.serverrest.service.api;

import java.util.Map;

/**
 * Created by jed on 19-7-8.
 */
public interface CertificateService extends BaseService {

    public Map<String, String> certificateApply(String param);

}
