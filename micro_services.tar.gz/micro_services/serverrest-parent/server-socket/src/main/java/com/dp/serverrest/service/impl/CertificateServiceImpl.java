package com.dp.serverrest.service.impl;

import com.dp.serverrest.service.util.CmdUtil;
import com.dp.serverrest.service.util.LogUtil;
import com.dp.serverrest.service.api.CertificateService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by jxl on 19-8-9.
 */
@Service
public class CertificateServiceImpl implements CertificateService {
    LogUtil logUtil = new LogUtil(CertificateServiceImpl.class);

    @Value("${logSwitch}")
    private String logSwitch;

    private String rootPath = System.getProperty("user.dir") + "/../source/certificateApply/";

    @Override
    public Map<String, String> certificateApply(String param) {
        Map<String, String> result = new HashMap<>();
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(param);

            String policyFormat = node.get("policyFormat").asText().toLowerCase();
            String country = node.get("country").asText();
            String province = node.get("province").asText();
            String city = node.get("city").asText();
            String company = node.get("company").asText();
            String dupe = node.get("dupe").asText();
            String policyName = node.get("policyName").asText();

            StringBuffer sbu = new StringBuffer("gmssl ecparam -genkey -name sm2p256v1 -text -out " + rootPath + "Root.key && ")
                    .append("gmssl req -new -key " + rootPath + "Root.key -out " + rootPath + policyName+"."+policyFormat+" -subj \"/C=" + country + "/ST=" + province + "/L=" + city + "/O=" + company + "/OU=" + dupe + "/CN=" + policyName + "\" &&")
                    .append("tar zcvf " + rootPath + policyName + ".tar.gz " + rootPath + "Root.key " + rootPath + policyName + "." + policyFormat);
//                    .append("gmssl x509 -req -days 3650 -sm3 -in " + rootPath + "Root.req -signkey " + rootPath + "Root.key -out " + rootPath + "RootCA." + policyFormat);

            String[] execute = {"/bin/sh", "-c", sbu.toString()};

            String data = CmdUtil.executeCMD4Res(execute);

            logUtil.info("证书申请结果：" + data, logSwitch);

//            if (data.contains("Signature ok")) {
                result.put("result", "true");
//            } else {
//                result.put("result", "false");
//            }

        } catch (Exception e) {
            result.put("result", "false");
            e.printStackTrace();
            logUtil.info("证书申请失败", logSwitch);
        }
        return result;
    }


}
