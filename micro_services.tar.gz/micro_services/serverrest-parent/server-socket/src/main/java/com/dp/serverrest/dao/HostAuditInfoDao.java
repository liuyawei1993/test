package com.dp.serverrest.dao;

import com.dp.serverrest.bean.HostAuditInfo;
import org.springframework.stereotype.Repository;

@Repository
public interface HostAuditInfoDao {

    void insertInfo(HostAuditInfo hostAuditInfo);

    void deleteInfoByhostId(String hostId);

}
