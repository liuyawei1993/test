package com.dp.serverrest.bean;

/**
 * Created by jed on 19-7-8.
 * 资产信息
 */
public class AssetInfo {
    private String assetIp;
    private String sensorIp;
    private String assetType;
    private String assetGeo;
    private String assetGroup;

    public void setAssetGeo(String assetGeo) {
        this.assetGeo = assetGeo;
    }

    public String getAssetGeo() {
        return assetGeo;
    }

    public void setAssetGroup(String assetGroup) {
        this.assetGroup = assetGroup;
    }

    public String getAssetGroup() {
        return assetGroup;
    }

    public void setAssetIp(String assetIp) {
        this.assetIp = assetIp;
    }

    public String getAssetIp() {
        return assetIp;
    }

    public void setAssetType(String assetType) {
        this.assetType = assetType;
    }

    public String getAssetType() {
        return assetType;
    }

    public void setSensorIp(String sensorIp) {
        this.sensorIp = sensorIp;
    }

    public String getSensorIp() {
        return sensorIp;
    }
}
