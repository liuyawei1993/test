package com.dp.serverrest.dao;


import com.dp.serverrest.vo.SensorPolicyVo;

import java.util.List;

public interface SensorPolicyVoMapper extends BaseVoMapper{
    
    int deleteByPrimaryKey(Integer id);

    int insert(SensorPolicyVo record);

    int insertSelective(SensorPolicyVo record);

    List<SensorPolicyVo> selectAll();

    SensorPolicyVo selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(SensorPolicyVo record);

    int updateByPrimaryKeySelective(SensorPolicyVo record);
}