package com.dp.serverrest;

import java.util.LinkedList;

/**
 * Created by jed on 19-7-8.
 */
public class Test {

    public static void main(String[] args) {
        LinkedList<String> list = new LinkedList<>();
        list.add("a1");
        list.add("a2");
        list.add("a3");

        System.out.println(list.pop());
        System.out.println(list);
    }
}
