package com.dp.serverrest;


import com.dp.serverrest.service.api.CenterControlService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ServerRestApplicationTests {
    @Autowired
    private CenterControlService centerControlService;


    @Test
    public void contextLoads() {

    }

    @Test
    public void hearttest() {
        ObjectMapper mapper = new ObjectMapper();
        try {
//            String str = mapper.writeValueAsString(map);
            String str="{\n" +
                    "\"deviceUUID\": \"1\",\n" +
                    "\"deviceType\": \"\",\n" +
                    "\"type\": 1,\n" +
                    "\"data\":{\n" +
                    "\"status\":{\n" +
                    "\"cpu_usage\":0.4,\n" +
                    "\"mem_usage\":0.5,\n" +
                    "\"disk_usage\":0.6,\n" +
                    "\"interfaces\":[\n" +
                    "{\n" +
                    "\"name\":\"eth0\",\n" +
                    "\"in_bytes\": 1000,\n" +
                    "\t\n" +
                    "\t \t\"out_bytes\": 2000,\n" +
                    "\t\n" +
                    "\t \t\"in_packages\": 0,\n" +
                    "\t\n" +
                    "\t \t\"out_packages\": 0\n" +
                    "}\n" +
                    "]\n" +
                    "\n" +
                    "}\n" +
                    "\n" +
                    "}\n" +
                    "\n" +
                    "}";
            JsonNode rootNode=mapper.readTree(str);
            System.out.println(str);
            System.out.println(centerControlService.messageHandle(rootNode,1,1,null));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Test
    public void operator1100test() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("deviceUUID", "");
        map.put("deviceType", "");
        map.put("type", "2");

        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("operator", "1100");

        Map<String, Object> map2 = new HashMap<String, Object>();
        map2.put("deviceName", "10.1.1.1");
        map2.put("cpu_proc", "1");
        map2.put("cpu_freq", "1.79GHz");
        map2.put("cpu_name", "Intel(R) Xeon(R) CPU E5-2606 v4 @");
        map2.put("mem_size", 32667428);
        map2.put("disk_size", 52403200);
        map1.put("info", map2);
        map.put("data", map1);
        ObjectMapper mapper = new ObjectMapper();
        try {
            String str = mapper.writeValueAsString(map);
            System.out.println(str);
            JsonNode rootNode=mapper.readTree(str);
            System.out.println(centerControlService.messageHandle(rootNode,1,1,null));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Test
    public void operator1101test() {
        ObjectMapper mapper = new ObjectMapper();
        try {
//            String str = mapper.writeValueAsString(map);
            String str="{\n" +
                    "\t\"deviceUUID\":\"1\",\n" +
                    "\t\"deviceType\":\"\",\n" +
                    "\t\"type\":2,\n" +
                    "\t\"data\":{\n" +
                    "\t\t\"operator\": 1101,\n" +
                    "\t\t\"info\":{\n" +
                    "\t\t\t\"cpu_proc\": 16,\n" +
                    "            \"cpu_freq\": \"1.70GHz\",\n" +
                    "            \"cpu_name\": \"Intel(R) Xeon(R) CPU E5-2606 v4 @\",\n" +
                    "            \"mem_size\": 32667428,\n" +
                    "            \"disk_size\": 52403200,\n" +
                    "\t    \"softupdate\":\"0.2\",\n" +
                    "\t    \"ruleupdate\":\"0.3\",\n" +
                    "            \"interfaces\":[{\n" +
                    "                \"index\": \"\",\n" +
                    "                \"name\": \"eth0\",\n" +
                    "                \"status\": \"up\",\n" +
                    "                \"mac\": \"00:00:00:00:00:00\",\n" +
                    "                \"addrs\": [\"192.168.1.1/24\"],\n" +
                    "                \"type\": \"normal\"\n" +
                    "\t\t\t}],\n" +
                    "            \"modules\": [{\n" +
                    "                \"name\": \"audit\",\n" +
                    "                \"status\": \"1\",\n" +
                    "                \"logaddr\": \"10.121.21.21\",\n" +
                    "                \"loghostname\": \"\",\n" +
                    "                \"policy\": [\"http\",\"sss\"],\n" +
                    "                \"netcfg\": [\"eth0\"],\n" +
                    "                \"fileextract\": \"\",\n" +
                    "                \"fileType\": []\n" +
                    "            },{\n" +
                    "                \"name\": \"attack\",\n" +
                    "                \"status\": \"0\",\n" +
                    "                \"logaddr\": \"10.121.21.22\",\n" +
                    "                \"loghostname\": \"\",\n" +
                    "                \"policy\": [],\n" +
                    "                \"netcfg\": [],\n" +
                    "                \"fileextract\": \"\",\n" +
                    "                \"fileType\": []\n" +
                    "            }]\n" +
                    "\t\t}\n" +
                    "\t}\n" +
                    "}";
            System.out.println(str);
            JsonNode rootNode=mapper.readTree(str);
            System.out.println(centerControlService.messageHandle(rootNode,1,1,null));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    @Test
    public void operator1102test() {

        ObjectMapper mapper = new ObjectMapper();
        try {
//            String str = mapper.writeValueAsString(map);
            String str="{\n" +
                    "\t\"deviceUUID\":\"1\",\n" +
                    "\t\"deviceType\":\"\",\n" +
                    "\t\"type\":2,\n" +
                    "\t\"data\":{\n" +
                    "\t\t\"operator\": 1102,\n" +
                    "\t\t\"info\": \"\"\n" +
                    "\t}\n" +
                    "}";
            System.out.println(str);
            JsonNode rootNode=mapper.readTree(str);
            System.out.println(centerControlService.messageHandle(rootNode,1,1,null));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    @Test
    public void operator1007test() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("deviceUUID", "2b2007e0-a92e-11e9-97b6-13b0fb884053");
        map.put("deviceType", "");
        map.put("type", "2");

        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("operator", "1007");

        List<Map<String,Object>> list=new ArrayList<>();
        Map<String, Object> map2 = new HashMap<String, Object>();
        map2.put("ip", "10.121.201.235");
        map2.put("vul_id", "71085");
        map2.put("id", "10.121.201.16910.121.201.246");
        list.add(map2);

        Map<String, Object> map3 = new HashMap<String, Object>();
        map3.put("ip", "192.2");
        map3.put("vul_id", "123");
        map3.put("id", "AWvgFcS-h2jI2c3FaxhR");
//        list.add(map3);
        map1.put("report_info", list);
        map.put("data", map1);
        ObjectMapper mapper = new ObjectMapper();
        try {
            String str = mapper.writeValueAsString(map);
            System.out.println(str);
            JsonNode rootNode=mapper.readTree(str);
            System.out.println(centerControlService.messageHandle(rootNode,1,1,null));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Test
    public void operator1009test() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("deviceUUID", "48e052b0-bca4-11e9-b6d9-eb0fef4f7cc7");
        map.put("deviceType", "");
        map.put("type", "2");

        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("operator", "1009");

        List<Map<String,Object>> list=new ArrayList<>();
        Map<String, Object> map2 = new HashMap<String, Object>();
        map2.put("fileName", "tmp.docx");
        map2.put("fileLength", "223656");
        map2.put("md5", "4d0e700c66e98d3e99c3021a5b86b255");

        map1.put("info", map2);
        map.put("data", map1);
        ObjectMapper mapper = new ObjectMapper();
        try {
            String str = mapper.writeValueAsString(map);
            System.out.println(str);
            JsonNode rootNode=mapper.readTree(str);
            System.out.println(centerControlService.messageHandle(rootNode,1,1,null));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    public void operator1010test() {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("deviceUUID", "48e052b0-bca4-11e9-b6d9-eb0fef4f7cc7");
        map.put("deviceType", "");
        map.put("type", "2");

        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("operator", "1010");

        List<Map<String,Object>> list=new ArrayList<>();
        Map<String, Object> map2 = new HashMap<String, Object>();
        map2.put("fileName", "1.txt");
        map2.put("fileLength", "223656");
        map2.put("md5", "4d0e700c66e98d3e99c3021a5b86b255");

        map2.put("desc", "asfasfasfas");

        map2.put("id", "2");

        map1.put("info", map2);
        map.put("data", map1);
        ObjectMapper mapper = new ObjectMapper();
        try {
            String str = mapper.writeValueAsString(map);
            System.out.println(str);
            JsonNode rootNode=mapper.readTree(str);
            System.out.println(centerControlService.messageHandle(rootNode,1,1,null));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
