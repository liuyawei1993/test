/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.InterfaceManagePo;
import com.dp.serverrest.po.PlatformCfgPo;
import com.dp.serverrest.po.RoutePo;
import com.dp.serverrest.po.VersionLogPo;
import com.dp.serverrest.service.api.*;
import com.dp.serverrest.service.util.PageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 上午11:04:36
 */
@RestController
@RequestMapping(value = "/stap/systemManage/sysConfig")
public class SysConfigController {
    private static final Logger log = LoggerFactory.getLogger(SysConfigController.class);

    /**
     * 平台配置
     */
    @Autowired
    private PlatformCfgService platformCfgService;

    /**
     * 平台级联信息
     */
    @Autowired
    private PlatformConnectService platformConnectService;

    @Autowired
    private RouteVoService routeVoService;

    @Autowired
    private VersionLogVoService versionLogVoService;

    @Autowired
    private InterfaceManageVoService interfaceManageVoService;


    //==========================平台级联=============================
    //TODO 平台级联待定
    /**
     * 平台级联 删除下级平台
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/platform/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deletePlatformById(@PathVariable("id") Integer id) {

        return platformConnectService.deletePlatformCfgVo(id);
    }


    /**
     * 平台级联 获取配置
     *
     * @return
     */
    @RequestMapping(value = "/platformConnect/config", method = RequestMethod.GET)
    public PlatformCfgPo platformConnectConfig() {
        return platformConnectService.getPlatformCfgVo();
    }


    /**
     * 获取平台管理 配置信息
     *
     * @return
     */
    @GetMapping("/platformConfig/config")
    public PlatformCfgPo getPlatformConfig() {
        return platformCfgService.getPlatformCfg();
    }


    /**
     * 添加 平台 配置
     *
     * @param platformCfgVo
     * @return
     */
    @RequestMapping(value = "/platformConnect/config", method = RequestMethod.POST)
    public Map<String, String> platformConnectConfigAdd(@RequestBody PlatformCfgPo platformCfgVo) {
        return platformConnectService.addPlatformCfgVo(platformCfgVo);
    }


    //======================路由管理===============================

    /**
     * 添加路由配置
     *
     * @return
     */
    @RequestMapping(value = "/routeManage/config", method = RequestMethod.POST)
    public Map<String, Object> addRouteManage(@RequestBody RoutePo routeVo) {
        return routeVoService.addRouteVo(routeVo);
    }

    /**
     * 路由管理--删除
     *
     * @param
     * @return
     */
    @RequestMapping(value = "routeManage/config/{ip}/{subMask}/{gateway}/{devName}", method = RequestMethod.DELETE)
    public Map<String, Object> deleteRouteVo(@PathVariable String ip,
                                             @PathVariable String subMask,
                                             @PathVariable String gateway,
                                             @PathVariable String devName) {
        RoutePo routePo = new RoutePo();
        routePo.setIp(ip);
        routePo.setSubMask(subMask);
        routePo.setGateway(gateway);
        routePo.setDevName(devName);
        return routeVoService.deleteRouteVo(routePo);
    }


    /**
     * 路由管理--修改
     *
     * @param
     * @param
     * @return
     */
    @RequestMapping(value = "routeManage/config/{ip}/{subMask}/{gateway}/{devName}", method = RequestMethod.PUT)
    public Map<String, Object> modifyRouteVo(@RequestBody RoutePo newRoutePo,
                                             @PathVariable String ip,
                                             @PathVariable String subMask,
                                             @PathVariable String gateway,
                                             @PathVariable String devName) {
        RoutePo oldRoutePo = new RoutePo();
        oldRoutePo.setIp(ip);
        oldRoutePo.setSubMask(subMask);
        oldRoutePo.setGateway(gateway);
        oldRoutePo.setDevName(devName);
        return routeVoService.modifyRouteVo(oldRoutePo, newRoutePo);
    }
    /**
     * 路由管理 获取路由配置
     *
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping(value = "/routeManage/config", method = RequestMethod.GET)
    public PageDTO<RoutePo> getRouteManage(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit) {
        PageUtils<RoutePo> alarmVoPageUtils = new PageUtils<>();
        PageDTO<RoutePo> alarmVoPageDTO = alarmVoPageUtils.pageUtil(routeVoService.getRouteVoList(page, limit));
        return alarmVoPageDTO;
    }


    //========================日志设置===========================
    /**
     * TODO 没有分页
     * 获取当前日志配置
     *
     * @return
     */
    @RequestMapping(value = "/logManage/config", method = RequestMethod.GET)
    public List<VersionLogPo> getVersionLogVo() {
//        Integer page, Integer limit
//        PageUtils<VersionLogVo> VersionLogVoPageUtils = new PageUtils<>();
//        PageDTO<VersionLogVo> VersionLogVoPageDTO = VersionLogVoPageUtils.pageUtil( versionLogVoService.getVersionLogVoList(page,limit));
        return versionLogVoService.getVersionLogVoAll();
    }


    //======================接口管理=========================
    /**
     * 获取 接口列表
     *
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping(value = "/portConfig/config", method = RequestMethod.GET)
    public PageDTO<InterfaceManagePo> getInterfaceManageVo(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit) {
        PageUtils<InterfaceManagePo> InterfaceManageVoPageUtils = new PageUtils<>();
        PageDTO<InterfaceManagePo> InterfaceManageVoPageDTO = InterfaceManageVoPageUtils.pageUtil(interfaceManageVoService.getInterfaceManageVoList(page, limit));
        return InterfaceManageVoPageDTO;
    }

    /**
     * 修改网关状态
     *
     * @param interfaceManageVo
     * @return
     */
    @RequestMapping(value = "/portConfig/status/{interfaceName}", method = RequestMethod.PUT)
    public Map<String, Object> modifyPort(@PathVariable("interfaceName") String name, @RequestBody InterfaceManagePo interfaceManageVo) {
        return interfaceManageVoService.modifyInterfaceManagePo(name, interfaceManageVo);
    }

}
