package com.dp.serverrest.service.util.file;

import java.io.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @className: FileUtil
 * @description: 文件上传工具类
 * @author: yuanyubo
 * @create: 2019-08-31
 */
public class FileUtil {

    /**
     * 文件上传
     *
     * @param file
     * @param filePath
     * @param fileName
     */
    public static void uploadFile(byte[] file, String filePath, String fileName) throws IOException {
        File targetFile = new File(filePath);
        if (!targetFile.exists()) {
            targetFile.mkdir();
        }
        FileOutputStream outputStream = new FileOutputStream(filePath + fileName);
        outputStream.write(file);
        outputStream.flush();
        outputStream.close();
    }

    /**
     * 删除 文件
     *
     * @param fileName
     * @return
     */
    public static boolean deleteFile(String fileName) {
        File file = new File(fileName);
        //如果文件路径所对应的文件存在，并且是一个文件，则直接删除
        if (file.exists() && file.isFile()) {
            if (file.delete()){
                return true;
            }else{
                return false;
            }
        }else {
            return false;
        }
    }

    /**
     * 对上传的文件进行重命名 保存到数据库
     * @param fileName
     * @return
     */
    public static String renameToUUID(String fileName){
        return UUID.randomUUID()+"."+fileName.substring(fileName.lastIndexOf(".")+1);
    }

    /**
     * @Description: 修改配置文件（修改配置，新增配置）
     * @Param: pathname configMap
     * @return: boolean
     * @Author: ZhangPeng
     * @Date: 2019/9/5
     */
    public static boolean changeConfig(String pathname, Map<String, String> configMap) throws IOException {
        final File file = new File(pathname);
        if (!file.exists()) {
            throw new IOException(pathname + " 不存在");
        }
        final File tmpFile = new File(pathname + ".old");
        PrintWriter pw = new PrintWriter(tmpFile);
        BufferedReader br = new BufferedReader(new FileReader(file));
        Pattern pattern = Pattern.compile("=");
        //查找配置并修改
        for (String line; (line = br.readLine()) != null; ) {
            String[] strings = pattern.split(line, 2);
            if (strings.length == 2 && configMap.containsKey(strings[0])) {
                line = strings[0] + '=' + '"' + configMap.get(strings[0]) + '"';
                configMap.remove(strings[0]);
            }
            pw.println(line);
        }
        //添加配置
        if (configMap.size() > 0) {
            for (Map.Entry<String, String> entry : configMap.entrySet()) {
                pw.println(entry.getKey() + '=' + '"' + entry.getValue() + '"');
            }
        }
        br.close();
        pw.close();
        tmpFile.renameTo(file);
        return true;
    }

    /**
     * @Description: 读取配置文件
     * @Param: File file
     * @return: Map
     * @Author: ZhangPeng
     * @Date: 2019/9/5
     */
    public static Map<String, String> getConfigMap(File file) throws IOException {
        Map<String, String> map = new LinkedHashMap<>();
        BufferedReader br = new BufferedReader(new FileReader(file));
        Pattern splitPattern = Pattern.compile("=");
        Pattern valuePattern = Pattern.compile("(?<=^\").+(?=\"$)");
        for (String line; (line = br.readLine()) != null; ) {
            String[] strings = splitPattern.split(line, 2);
            if (strings.length == 2) {
                Matcher matcher = valuePattern.matcher(strings[1]);
                String value = matcher.find() ? matcher.group() : strings[1];
                map.put(strings[0], value);
            }
        }
        return map;
    }
}
