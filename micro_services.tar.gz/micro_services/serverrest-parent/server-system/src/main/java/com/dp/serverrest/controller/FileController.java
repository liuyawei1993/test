package com.dp.serverrest.controller;

import com.dp.serverrest.config.FileConfig;
import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.FilePo;
import com.dp.serverrest.service.api.FileService;
import com.dp.serverrest.service.util.PageUtils;
import com.dp.serverrest.service.util.TimeUtils;
import com.dp.serverrest.service.util.file.FileTypeUtil;
import com.dp.serverrest.service.util.file.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * @className: UploadController
 * @description: 文件上传下载类
 * @author: yuanyubo
 * @create: 2019-08-31
 */
@RestController
@RequestMapping(value = "/stap/systemManage/systemFile")
public class FileController {

    @Autowired
    private FileService fileService;

    @Autowired
    private FileConfig fileConfig;

    /**
     * 分页查询 已上传文件信息
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/file")
    public PageDTO<FilePo> selectFilePage(Integer page, Integer limit) {
        PageUtils<FilePo> filePoPageUtils = new PageUtils<>();
        PageDTO<FilePo> filePoPageDTO = filePoPageUtils.pageUtil(fileService.selectPage(page, limit));
        return filePoPageDTO;
    }


    /**
     * 文件上传接口
     *
     * @param multipartFile
     * @param request
     * @return
     */
    @PostMapping("/upload")
    public Map<String, Object> upload(@RequestParam("file") MultipartFile multipartFile, HttpServletRequest request) {
        HashMap<String, Object> stringObjectHashMap = new HashMap<>(16);
        String originalFilename = multipartFile.getOriginalFilename();

        /**
         * 设置文件名,使用UUID区分 也可以不设置文件名，直接原文件名上传
         */
        //originalFilename = FileUtil.renameToUUID(originalFilename);
        FilePo filePo = new FilePo(FileTypeUtil.fileType(originalFilename), "/files/" + originalFilename, TimeUtils.getCurrentTime());

        try {
            FileUtil.uploadFile(multipartFile.getBytes(), fileConfig.getUploadPath(), originalFilename);
        } catch (IOException e) {
            e.printStackTrace();
            stringObjectHashMap.put("err", "文件上传异常");
            return stringObjectHashMap;
        }
        if (fileService.save(filePo) > 0) {
            stringObjectHashMap.put("success", "文件上传成功");
            return stringObjectHashMap;
        }
        stringObjectHashMap.put("err", "文件上传失败");
        return stringObjectHashMap;
    }

    /**
     * 文件删除
     *
     * @param id
     * @return
     */
    @DeleteMapping("/remove/{id}")
    public Map<String, Object> removeFile(@PathVariable("id") Integer id) {
        String fileName = fileConfig.getUploadPath() + fileService.get(id).getFileUrl().replace("/files/", "");
        HashMap<String, Object> stringObjectHashMap = new HashMap<>();
        if (fileService.remove(id) > 0) {
            boolean b = FileUtil.deleteFile(fileName);
            if (!b) {
                stringObjectHashMap.put("err", "数据库记录删除成功，文件删除失败");
                return stringObjectHashMap;
            }
            stringObjectHashMap.put("success", "文件删除成功");
            return stringObjectHashMap;
        } else {
            stringObjectHashMap.put("err", "文件删除失败");
            return stringObjectHashMap;
        }
    }

    /**
     * 文件下载接口
     *
     * @param filePath
     * @param response
     */
    @GetMapping("/download")
    public void downloadFile(String filePath, HttpServletResponse response) {
        String fileName = filePath.replace("/files/", "");
        filePath = fileConfig.getUploadPath() + fileName;
        response.setHeader("content-type", "application/octet-stream");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        byte[] buff = new byte[1024];
        BufferedInputStream bis = null;
        OutputStream os = null;

        try {
            os = response.getOutputStream();
            bis = new BufferedInputStream(new FileInputStream(new File(filePath)));
            int i = bis.read(buff);
            while (i != -1) {
                os.write(buff, 0, buff.length);
                os.flush();
                i = bis.read(buff);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
//        System.out.println("下载成功！");
    }


    /**
     * 文件上传实现方法
     *
     * @param multipartFile
     * @return
     */
//    @PostMapping("/upload1")
    public Map<String, Object> upload1(MultipartFile multipartFile) {

        HashMap<String, Object> stringObjectHashMap = new HashMap<>(16);
        if (multipartFile.isEmpty()) {
            stringObjectHashMap.put("err", "上传文件为空！");
            return stringObjectHashMap;
        }
        String name = multipartFile.getName();
        long size = multipartFile.getSize();
        System.out.println("需要上传的文件名为：" + name + "，文件大小为：" + size);

        String path = "D://upload";
        //设置父级目录
        File file = new File(path + "/" + name);

        //判断父级目录是否存在,如果不存在则创建新的目录
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdir();
        }

        try {
            //保存文件
            multipartFile.transferTo(file);
            stringObjectHashMap.put("success", "文件上传成功");
            return stringObjectHashMap;
        } catch (IOException e) {
            e.printStackTrace();
        }
        stringObjectHashMap.put("err", "文件上传失败");
        return null;
    }

}
