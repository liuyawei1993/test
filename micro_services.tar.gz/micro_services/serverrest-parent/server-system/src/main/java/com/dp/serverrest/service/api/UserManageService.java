/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.api;

import java.util.List;
import java.util.Map;

import com.dp.serverrest.po.UserPo;
import com.github.pagehelper.PageInfo;

/**
 * @author chaozhang
 *
 */
public interface UserManageService extends BaseService{

	/**
	 * 新增 用户
	 * @param user
	 * @return
	 */
	public Map<String, String> addUser(UserPo user);

	/**
	 * 修改 用户
	 * @param id
	 * @param user
	 * @return
	 */
	public Map<String, String> modifyUser(int id, UserPo user);

	/**
	 * 删除 用户
	 * @param id
	 * @return
	 */
	public Map<String, String> deleteUser(int id);

	/**
	 * 查询 用户
	 * @param page
	 * @param limit
	 * @return
	 */
	public List<UserPo> getUserList(int page, int limit);

	/**
	 * 分页查询 用户
	 * @param page
	 * @param limit
	 * @return
	 */
	public PageInfo<UserPo> getUserPage(int page, int limit,Integer userId);

	/**
	 * 根据id查询用户信息
	 * @param userId
	 * @return
	 */
	UserPo selectById(Integer userId);
}
