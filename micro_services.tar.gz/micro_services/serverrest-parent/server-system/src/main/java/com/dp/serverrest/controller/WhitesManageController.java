/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.util.Map;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.AttackWhitelistPo;
import com.dp.serverrest.po.IpWhitelistPo;
import com.dp.serverrest.service.api.WhitesManageService;
import com.dp.serverrest.service.util.PageUtils;
import com.dp.serverrest.po.VulnerabilityWhitelistPo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 上午10:49:54
 * 信任列表接口
 */
@RestController
@RequestMapping(value = "/stap/systemManage/whitesManage")
public class WhitesManageController {
    private static final Logger log = LoggerFactory.getLogger(WhitesManageController.class);


    @Autowired
    private WhitesManageService whitesManageService;


    //=======================攻击白名单==========================

    /**
     * 添加 攻击白名单
     *
     * @param attackWhitelistPo
     * @return
     */
    @RequestMapping(value = "/attackWhitelistPo", method = RequestMethod.POST)
    public Map<String, String> addAttackWhitelistPo(@RequestBody AttackWhitelistPo attackWhitelistPo) {
        return whitesManageService.addAttackWhitelistPo(attackWhitelistPo);
    }

    /**
     * 修改 攻击白名单
     *
     * @param id
     * @param attackWhitelistPo
     * @return
     */
    @RequestMapping(value = "/attackWhitelistPo/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyAttackWhitelistPo(@PathVariable("id") Integer id,
                                                       @RequestBody AttackWhitelistPo attackWhitelistPo) {
        return whitesManageService.modifyAttackWhitelistPo(id, attackWhitelistPo);
    }

    /**
     * 删除 攻击白名单
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/attackWhitelistPo/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deleteAttackWhitelistPo(@PathVariable("id") Integer id) {
        return whitesManageService.deleteAttackWhitelistPo(id);
    }

    /**
     * 获取 攻击白名单
     *
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping(value = "/attackWhitelistPo", method = RequestMethod.GET)
    public PageDTO<AttackWhitelistPo> getAttackWhitelistPoAll(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit) {
        PageUtils<AttackWhitelistPo> attackWhitelistPoPageUtils = new PageUtils<>();
        PageDTO<AttackWhitelistPo> attackWhitelistPoPageDTO = attackWhitelistPoPageUtils.pageUtil(whitesManageService.getAttackWhitelistPoList(page, limit));

        return attackWhitelistPoPageDTO;
    }


    //==========================IP白名单===========================

    /**
     * 添加 IP白名单
     *
     * @param ipWhitelistPo
     * @return
     */
    @RequestMapping(value = "/ipWhitelistPo", method = RequestMethod.POST)
    public Map<String, String> addIpWhitelistPo(@RequestBody IpWhitelistPo ipWhitelistPo) {
        return whitesManageService.addIpWhitelistPo(ipWhitelistPo);
    }

    /**
     * 修改 IP白名单
     *
     * @param id
     * @param ipWhitelistPo
     * @return
     */
    @RequestMapping(value = "/ipWhitelistPo/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyIpWhitelistPo(@PathVariable("id") Integer id,
                                                   @RequestBody IpWhitelistPo ipWhitelistPo) {
        return whitesManageService.modifyIpWhitelistPoWhites(id, ipWhitelistPo);
    }

    /**
     * 删除 IP白名单
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/ipWhitelistPo/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deleteIpWhitelistPo(@PathVariable("id") Integer id) {
        return whitesManageService.deleteIpWhitelistPoWhites(id);
    }

    /**
     * 获取 IP白名单
     *
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping(value = "/ipWhitelistPo", method = RequestMethod.GET)
    public PageDTO<IpWhitelistPo> getIpWhitelistPoAll(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit) {
        PageUtils<IpWhitelistPo> ipWhitelistPoPageUtils = new PageUtils<>();
        PageDTO<IpWhitelistPo> ipWhitelistPoPageDTO = ipWhitelistPoPageUtils.pageUtil(whitesManageService.getIpWhitelistPoList(page, limit));

        return ipWhitelistPoPageDTO;
    }


    //==========================漏洞白名单=========================

    /**
     * 添加 漏洞白名单
     *
     * @param vulnerabilityWhitelistVo
     * @return
     */
    @RequestMapping(value = "vulnerableWhites", method = RequestMethod.POST)
    public Map<String, String> addVulnerabilityWhitelistVo(@RequestBody VulnerabilityWhitelistPo vulnerabilityWhitelistVo) {
        return whitesManageService.addVulnerableWhites(vulnerabilityWhitelistVo);
    }

    /**
     * 修改 漏洞白名单
     *
     * @param id
     * @param vulnerabilityWhitelistVo
     * @return
     */
    @RequestMapping(value = "vulnerableWhites/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyVulnerabilityWhitelistVo(@PathVariable("id") Integer id,
                                                              @RequestBody VulnerabilityWhitelistPo vulnerabilityWhitelistVo) {
        vulnerabilityWhitelistVo.setId(id);
        return whitesManageService.modifyVulnerableWhites(id, vulnerabilityWhitelistVo);
    }

    /**
     * 删除漏洞白名单
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "vulnerableWhites/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deleteVulnerabilityWhitelistVo(@PathVariable("id") Integer id) {
        return whitesManageService.deleteVulnerableWhites(id);
    }

    /**
     * 获取漏洞白名单
     *
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping(value = "vulnerableWhites", method = RequestMethod.GET)
    public PageDTO<VulnerabilityWhitelistPo> getVulnerabilityWhitelistVoAll(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit) {
        PageUtils<VulnerabilityWhitelistPo> globalVulnerabilityWhitelistVoPageUtils = new PageUtils<>();
        PageDTO<VulnerabilityWhitelistPo> globalVulnerabilityWhitelistVoPageDTO = globalVulnerabilityWhitelistVoPageUtils.pageUtil(whitesManageService.getVulnerableWhitesList(page, limit));

        return globalVulnerabilityWhitelistVoPageDTO;
    }

}
