package com.dp.serverrest.dao;

import com.dp.serverrest.po.SensorInterfaceStatusPo;

public interface SensorInterfaceStatusPoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer id);

    
    int insert(SensorInterfaceStatusPo record);

    
    int insertSelective(SensorInterfaceStatusPo record);

    
    SensorInterfaceStatusPo selectByPrimaryKey(Integer id);

    
    int updateByPrimaryKeySelective(SensorInterfaceStatusPo record);

    
    int updateByPrimaryKey(SensorInterfaceStatusPo record);
}