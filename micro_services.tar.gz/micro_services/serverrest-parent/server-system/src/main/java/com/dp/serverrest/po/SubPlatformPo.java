package com.dp.serverrest.po;

public class SubPlatformPo extends BasePo {
    
    private Integer id;

    
    private String name;

    
    private String ip;

    
    private String status;

    
    private String lastTime;

    
    private String message;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getName() {
        return name;
    }

    
    public void setName(String name) {
        this.name = name;
    }

    
    public String getIp() {
        return ip;
    }

    
    public void setIp(String ip) {
        this.ip = ip;
    }

    
    public String getStatus() {
        return status;
    }

    
    public void setStatus(String status) {
        this.status = status;
    }

    
    public String getLastTime() {
        return lastTime;
    }

    
    public void setLastTime(String lastTime) {
        this.lastTime = lastTime;
    }

    
    public String getMessage() {
        return message;
    }

    
    public void setMessage(String message) {
        this.message = message;
    }
}