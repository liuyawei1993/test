package com.dp.serverrest.po;

public class SensorManagePo extends BasePo {
    
    private Integer sensorId;

    
    private String sensorName;

    
    private String sensorIp;

    
    private String sensorType;

    
    private String status;

    
    private Long createTime;

    
    private String cpuName;

    
    private String cpuFreq;

    
    private String cpuProc;

    
    private String memorySize;

    
    private String diskSize;

    
    public Integer getSensorId() {
        return sensorId;
    }

    
    public void setSensorId(Integer sensorId) {
        this.sensorId = sensorId;
    }

    
    public String getSensorName() {
        return sensorName;
    }

    
    public void setSensorName(String sensorName) {
        this.sensorName = sensorName;
    }

    
    public String getSensorIp() {
        return sensorIp;
    }

    
    public void setSensorIp(String sensorIp) {
        this.sensorIp = sensorIp;
    }

    
    public String getSensorType() {
        return sensorType;
    }

    
    public void setSensorType(String sensorType) {
        this.sensorType = sensorType;
    }

    
    public String getStatus() {
        return status;
    }

    
    public void setStatus(String status) {
        this.status = status;
    }

    
    public Long getCreateTime() {
        return createTime;
    }

    
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    
    public String getCpuName() {
        return cpuName;
    }

    
    public void setCpuName(String cpuName) {
        this.cpuName = cpuName;
    }

    
    public String getCpuFreq() {
        return cpuFreq;
    }

    
    public void setCpuFreq(String cpuFreq) {
        this.cpuFreq = cpuFreq;
    }

    
    public String getCpuProc() {
        return cpuProc;
    }

    
    public void setCpuProc(String cpuProc) {
        this.cpuProc = cpuProc;
    }

    
    public String getMemorySize() {
        return memorySize;
    }

    
    public void setMemorySize(String memorySize) {
        this.memorySize = memorySize;
    }

    
    public String getDiskSize() {
        return diskSize;
    }

    
    public void setDiskSize(String diskSize) {
        this.diskSize = diskSize;
    }
}