package com.dp.serverrest.service.util;

import com.dp.serverrest.dto.PageDTO;
import com.github.pagehelper.PageInfo;

/**
 * @className: PageUtils
 * @description: 分页查询结果集处理
 * @author: yuanyubo
 * @create: 2019-08-21
 */
public class PageUtils<T> {

    /**
     * 处理分页数据，返回适合前端使用的结果集
     * @param data
     * @return
     */
    public  PageDTO<T> pageUtil(PageInfo data){

        PageDTO<T> tPageDTO = new PageDTO<>();

        tPageDTO.setTableData(data.getList());
        tPageDTO.setPageSize(data.getPageSize());
        tPageDTO.setPageNum(data.getPageNum());
        tPageDTO.setTotal(data.getTotal());

        return tPageDTO;
    }

}
