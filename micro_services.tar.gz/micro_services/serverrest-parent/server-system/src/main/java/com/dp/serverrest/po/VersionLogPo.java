package com.dp.serverrest.po;

public class VersionLogPo extends BasePo {
    
    private Integer id;

    
    private String oldVersion;

    
    private String newVersion;

    
    private Integer md5;

    
    private String docSize;

    
    private String upTime;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getOldVersion() {
        return oldVersion;
    }

    
    public void setOldVersion(String oldVersion) {
        this.oldVersion = oldVersion;
    }

    
    public String getNewVersion() {
        return newVersion;
    }

    
    public void setNewVersion(String newVersion) {
        this.newVersion = newVersion;
    }

    
    public Integer getMd5() {
        return md5;
    }

    
    public void setMd5(Integer md5) {
        this.md5 = md5;
    }

    
    public String getDocSize() {
        return docSize;
    }

    
    public void setDocSize(String docSize) {
        this.docSize = docSize;
    }

    
    public String getUpTime() {
        return upTime;
    }

    
    public void setUpTime(String upTime) {
        this.upTime = upTime;
    }
}