package com.dp.serverrest.service.util;

/**
 * @className: TimeUtils
 * @description: 时间处理工具类
 * @author: yuanyubo
 * @create: 2019-08-30
 */
public class TimeUtils {

    /**
     * 给当前时间戳+num个小时
     * @param num
     * @return
     */
    public static Long addHour(Integer num){
        Long time = getCurrentTime()+num*60*60*1000;
        return time;
    }

    /**
     * 获取当前时间 时间戳
     * @return
     */
    public static Long getCurrentTime(){
        return System.currentTimeMillis();
    }

}
