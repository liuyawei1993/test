/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.impl;

import java.util.Map;

import com.dp.serverrest.service.api.AlarmManageService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dp.serverrest.dao.AlarmPoMapper;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.AlarmPo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 下午2:58:57
 */
@Service
@Transactional(readOnly = false)
public class AlarmManageServiceImpl implements AlarmManageService {
    @Autowired
    private AlarmPoMapper dao;

    /**
     * 获取告警列表的具体实现
     */
    @Override
    public PageInfo<AlarmPo> getAlarmList(int page, int limit) {
        PageHelper.startPage(page, limit);

        return new PageInfo<AlarmPo>(dao.selectAll());
    }

    /**
     * 修改告警配置
     */
    @Override
    public Map<String, String> modifyAlarmCfg(int id, AlarmPo alarm) {
        alarm.setId(id);
        return CommonUtils.modifyData(id, alarm, dao);
    }

}
