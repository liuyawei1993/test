package com.dp.serverrest.service.impl;

import java.util.Map;

import com.dp.serverrest.dao.PlatformCfgPoMapper;
import com.dp.serverrest.po.PlatformCfgPo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dp.serverrest.service.api.PlatformConnectService;
import com.dp.serverrest.service.util.CommonUtils;

/**
 * @className: PlatformConnectServiceImpl
 * @description: 平台级联
 * @author: yuanyubo
 * @create: 2019-08-19
 */
@Service
@Transactional(readOnly = false)
public class PlatformConnectServiceImpl implements PlatformConnectService {

    @Autowired
    private PlatformCfgPoMapper dao;

    @Override
    public Map<String, String> addPlatformCfgVo(PlatformCfgPo platformCfgVo) {

        return CommonUtils.addData(platformCfgVo, dao);
    }

    @Override
    public Map<String, String> deletePlatformCfgVo(int id) {

        return CommonUtils.deleteData(id,dao);
    }

    @Override
    public PlatformCfgPo getPlatformCfgVo() {
	return dao.selectAll();
    }

    @Override
    public Map<String, String> modifyPlatformCfgVo(int id, PlatformCfgPo policy) {
        return null;
    }
}
