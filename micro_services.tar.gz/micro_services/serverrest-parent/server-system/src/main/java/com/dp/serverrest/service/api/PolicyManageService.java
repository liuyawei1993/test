/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.api;

import java.util.Map;

import com.dp.serverrest.po.SensorPolicyPo;
import com.github.pagehelper.PageInfo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月17日 下午5:09:41
 * 
 */

public interface PolicyManageService extends BaseService {

    public Map<String, String> addPolicy(SensorPolicyPo policy);

    public Map<String, String> deletePolicy(int id);

    public PageInfo<SensorPolicyPo> getPolicyList(int page, int limit);

    public PageInfo<SensorPolicyPo> getPolicyByPage(int page, int limit);

    public Map<String, String> modifyPolicy(int id, SensorPolicyPo policy);
}
