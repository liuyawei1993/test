package com.dp.serverrest.po;

public class SensorPolicyPo extends BasePo {
    
    private Integer id;

    
    private String policyName;

    
    private String policyType;

    
    private Long createTime;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getPolicyName() {
        return policyName;
    }

    
    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    
    public String getPolicyType() {
        return policyType;
    }

    
    public void setPolicyType(String policyType) {
        this.policyType = policyType;
    }

    
    public Long getCreateTime() {
        return createTime;
    }

    
    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }
}