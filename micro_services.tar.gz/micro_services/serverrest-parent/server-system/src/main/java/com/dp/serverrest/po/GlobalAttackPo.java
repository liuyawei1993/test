package com.dp.serverrest.po;

public class GlobalAttackPo extends BasePo {
    
    private Integer id;

    
    private String srcIp;

    
    private String dstIp;

    
    private String domainName;

    
    private String url;

    
    private String attackType;

    
    private String effectiveBranch;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getSrcIp() {
        return srcIp;
    }

    
    public void setSrcIp(String srcIp) {
        this.srcIp = srcIp;
    }

    
    public String getDstIp() {
        return dstIp;
    }

    
    public void setDstIp(String dstIp) {
        this.dstIp = dstIp;
    }

    
    public String getDomainName() {
        return domainName;
    }

    
    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    
    public String getUrl() {
        return url;
    }

    
    public void setUrl(String url) {
        this.url = url;
    }

    
    public String getAttackType() {
        return attackType;
    }

    
    public void setAttackType(String attackType) {
        this.attackType = attackType;
    }

    
    public String getEffectiveBranch() {
        return effectiveBranch;
    }

    
    public void setEffectiveBranch(String effectiveBranch) {
        this.effectiveBranch = effectiveBranch;
    }
}