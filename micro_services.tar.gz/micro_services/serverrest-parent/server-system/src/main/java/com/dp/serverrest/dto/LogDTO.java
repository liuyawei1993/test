package com.dp.serverrest.dto;

/**
 * @className: LogDto
 * @description: 日志查询请求体
 * @author: yuanyubo
 * @create: 2019-08-22
 */
public class LogDTO {

    private String queryStr;

    private Long startTime;

    private Long endTime;

    private Integer page;

    private Integer limit;

    public String getQueryStr() {
        return queryStr;
    }

    public void setQueryStr(String queryStr) {
        this.queryStr = queryStr;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }
}
