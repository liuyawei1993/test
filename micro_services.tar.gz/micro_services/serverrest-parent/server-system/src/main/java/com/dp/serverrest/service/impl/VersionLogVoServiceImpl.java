package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.VersionLogPoMapper;
import com.dp.serverrest.service.api.VersionLogVoService;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.VersionLogPo;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @className: VersionLogVoServiceImpl
 * @description:
 * @author: yuanyubo
 * @create: 2019-08-19
 */
@Service
@Transactional(readOnly = false)
public class VersionLogVoServiceImpl implements VersionLogVoService {

    @Autowired
    private VersionLogPoMapper dao;

    /**
     *  日志设置 添加
     * @param versionLogVo
     * @return
     */
    @Override
    public Map<String, String> addVersionLogVo(VersionLogPo versionLogVo) {
        return CommonUtils.addData(versionLogVo,dao);
    }

    /**
     * 日志设置 修改
     * @param id
     * @param versionLogVo
     * @return
     */
    @Override
    public Map<String, String> modifyVersionLogVo(int id, VersionLogPo versionLogVo) {
        return CommonUtils.modifyData(id,versionLogVo,dao);
    }

    /**
     * 日志设置 删除
     * @param id
     * @return
     */
    @Override
    public Map<String, String> deleteVersionLogVo(int id) {

        return CommonUtils.deleteData(id,dao);
    }

    /**
     * 日志设置 查询
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<VersionLogPo> getVersionLogVoList(int page, int limit) {
        PageHelper.startPage(page,limit);
        return new PageInfo<VersionLogPo>(dao.selectAll()) ;
    }

    /**
     * 日志设置 查询
     * @return
     */
    @Override
    public List<VersionLogPo> getVersionLogVoAll() {

        return dao.selectVersionLogVo();
    }
}
