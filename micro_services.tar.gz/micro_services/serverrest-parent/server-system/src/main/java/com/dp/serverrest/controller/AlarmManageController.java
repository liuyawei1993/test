/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.util.Map;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.service.api.AlarmManageService;
import com.dp.serverrest.service.util.PageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dp.serverrest.po.AlarmPo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 上午9:51:28
 */
@RestController
@RequestMapping(value = "/stap/systemManage/alarmManage")
public class AlarmManageController {
    private static final Logger log = LoggerFactory.getLogger(AlarmManageController.class);
    @Autowired
    private AlarmManageService alarmManageService;

    /**
     * @param page
     * @param limit 获取告警列表的接口
     * @return
     */
    @RequestMapping(value = "/alarm", method = RequestMethod.GET)
    public PageDTO<AlarmPo> getAlarmList(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit) {
        PageUtils<AlarmPo> alarmVoPageUtils = new PageUtils<>();
        PageDTO<AlarmPo> alarmVoPageDTO = alarmVoPageUtils.pageUtil(alarmManageService.getAlarmList(page, limit));
        return alarmVoPageDTO;
    }

    /**
     * @param id
     * @param alarm 修改告警配置的接口
     * @return
     */
    @RequestMapping(value = "alarm/config/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyAlarmCfg(@PathVariable("id") Integer id, @RequestBody AlarmPo alarm) {
        return alarmManageService.modifyAlarmCfg(id, alarm);
    }
}
