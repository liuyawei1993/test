package com.dp.serverrest.dao;

import java.util.List;

import com.dp.serverrest.po.RolePo;
public interface RolePoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer roleId);
    
    int insert(RolePo record);
    
    int insertSelective(RolePo record);

    List<RolePo> selectAll(Integer userId);

    RolePo selectByPrimaryKey(int id);

    RolePo selectRoleVoByName(String roleName);

    int updateByPrimaryKey(RolePo record);
    
    int updateByPrimaryKeySelective(RolePo record);
    
    int updateByPrimaryKeyWithBLOBs(RolePo record);
}