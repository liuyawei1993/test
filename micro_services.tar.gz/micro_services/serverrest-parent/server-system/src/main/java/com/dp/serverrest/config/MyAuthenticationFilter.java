/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.config;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;

import com.alibaba.fastjson.JSON;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年9月5日 下午6:35:46
 * 
 */

public class MyAuthenticationFilter extends FormAuthenticationFilter {
    /*
     * * 未通过认证的请求会返回“code” 302
     * 
     * @see
     * org.apache.shiro.web.filter.authc.FormAuthenticationFilter#onAccessDenied(
     * javax.servlet.ServletRequest, javax.servlet.ServletResponse)
     */
    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
	HttpServletResponse res = (HttpServletResponse) response;
	res.setHeader("Access-Control-Allow-Origin", "*");
	res.setStatus(HttpServletResponse.SC_OK);
	res.setCharacterEncoding("UTF-8");
	PrintWriter writer = res.getWriter();
	Map<String, Object> map = new HashMap<>();
	map.put("code", 302);
	writer.write(JSON.toJSONString(map));
	writer.close();
	return false;
    }

    /**
     * Springboot 先加载了我们自定义的 Filter，然后再加载了 ShiroFilter 解决方法: 在自定义的filter里加上下面的代码
     * 
     * @param filter
     * @return
     */
    @Bean
    public FilterRegistrationBean<MyAuthenticationFilter> registration(MyAuthenticationFilter filter) {
	FilterRegistrationBean<MyAuthenticationFilter> registration = new FilterRegistrationBean<MyAuthenticationFilter>(
		filter);
	registration.setEnabled(false);
	return registration;
    }
}
