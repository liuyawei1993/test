package com.dp.serverrest.po;

/**
 * @className: PlatformModuleVo
 * @description: 系统组件实体类
 * @author: yuanyubo
 * @create: 2019-08-28
 */
public class PlatformModulePo extends BasePo {

    private Integer id;

    private String moduleName;

    private String moduleStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getModuleStatus() {
        return moduleStatus;
    }

    public void setModuleStatus(String moduleStatus) {
        this.moduleStatus = moduleStatus;
    }
}
