/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.util.HashMap;
import java.util.Map;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.service.api.SysSensorManageService;
import com.dp.serverrest.service.util.PageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dp.serverrest.po.SensorBaseInfoPo;
import com.dp.serverrest.po.SensorCfgPo;
import com.dp.serverrest.po.SensorManagePo;
import com.dp.serverrest.po.SensorStatusInfoPo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 上午10:17:33
 */
@RestController
@RequestMapping(value = "/stap/systemManage/sensorManage")
public class SensorManageController {
    private static final Logger log = LoggerFactory.getLogger(SensorManageController.class);
    @Autowired
    private SysSensorManageService sensorManageService;

    /**
     * @param sensor 探针添加
     * @return
     */
    @RequestMapping(value = "sensor", method = RequestMethod.POST)
    public Map<String, String> addSensorCfg(@RequestBody SensorManagePo sensor) {
        return sensorManageService.addSensor(sensor);
    }

    /**
     * @param id 探针删除
     * @return
     */
    @RequestMapping(value = "sensor/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deleteUser(@PathVariable("id") Integer id) {
        return sensorManageService.deleteSensor(id);
    }

    /**
     * 获取探针基本信息
     * @param sensorId
     * @return
     */
    @RequestMapping(value = "sensorBaseInfo/baseInfo/{sensorId}", method = RequestMethod.GET)
    public SensorBaseInfoPo getSensorBaseInfo(@PathVariable("sensorId") Integer sensorId) {
        return sensorManageService.getSensorBaseInfo(sensorId);
    }

    /**
     * @param id 获取探针配置信息
     * @return
     */
    @RequestMapping(value = "sensorConfigInfo/configList/{id}", method = RequestMethod.GET)
    public SensorCfgPo getSensorCfgInfo(@PathVariable("id") Integer id) {
        return sensorManageService.getSensorCfgInfo(id);
    }

    /**
     * 获取探针列表
     * @param page
     * @param limit
     * @return
     */
    @RequestMapping(value = "sensor", method = RequestMethod.GET)
    public PageDTO<SensorManagePo> getSensorList(@RequestParam("page") Integer page,
                                                 @RequestParam("limit") Integer limit) {
        PageUtils<SensorManagePo> sensorManageVoPageUtils = new PageUtils<>();
        PageDTO<SensorManagePo> sensorManageVoPageDTO = sensorManageVoPageUtils.pageUtil(sensorManageService.getSensorList(page, limit));

        return sensorManageVoPageDTO;
    }

    /**
     * @param id 获取探针接口状态列表
     * @return
     */
    @RequestMapping(value = "sensorBaseInfo/sensorStatusInfo/{sensorId}", method = RequestMethod.GET)
    public SensorStatusInfoPo getSensorStatusInfo(@PathVariable("sensorId") Integer id) {
        return sensorManageService.getSensorStatusInfo(id);
    }

    /**
     * @param sensorCfg 修改探针的配置或者下发
     * @return
     */
    // FIXME
    @RequestMapping(value = "sensorConfigInfo/configList/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifySensorCfg(@PathVariable("id") Integer id, @RequestParam("operate") Integer operate,
                                               @RequestBody HashMap<Object, Object> sensorCfg) {
        switch (operate) {
            case 1:
                sensorManageService.modifySensorCfg(id, sensorCfg);
                break;
            case 2:
                sensorManageService.modifySensorCfg(id, sensorCfg);
                break;
            case 3:

                break;
            default:
                break;
        }
        return null;
    }

    /**
     * @param sensor 探针修改
     * @return
     */
    @RequestMapping(value = "sensor/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifySensorCfg(@PathVariable("id") Integer id, @RequestBody SensorManagePo sensor) {
        return sensorManageService.modifySensor(id, sensor);
    }

    /**
     * @param id
     * @param time 探针配置时间同步
     * @return
     */
    // FIXME
    @RequestMapping(value = "sensorConfigInfo/synTime/{id}", method = RequestMethod.POST)
    public Map<String, String> syncCfgTime(@PathVariable("id") Integer id, @RequestBody HashMap<Object, Object> time) {
        Integer timeStamp = (Integer) time.get("time");
        return null;
    }

    /**
     * @param id
     * @param time 探针时间同步
     * @return
     */
    // FIXME
    @RequestMapping(value = "synTime/{id}", method = RequestMethod.POST)
    public Map<String, String> syncTime(@PathVariable("id") Integer id, @RequestBody HashMap<Object, Object> time) {
        Integer timeStamp = (Integer) time.get("time");
        return null;
    }
}
