package com.dp.serverrest.dao;

import com.dp.serverrest.po.SensorUpdateLogPo;

public interface SensorUpdateLogPoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer id);

    
    int insert(SensorUpdateLogPo record);

    
    int insertSelective(SensorUpdateLogPo record);

    
    SensorUpdateLogPo selectByPrimaryKey(Integer id);

    
    int updateByPrimaryKeySelective(SensorUpdateLogPo record);

    
    int updateByPrimaryKey(SensorUpdateLogPo record);
}