package com.dp.serverrest.dao;
import com.dp.serverrest.po.RoutePo;

import java.util.List;
import java.util.Map;

public interface RoutePoMapper extends BasePoMapper {

    int insert(RoutePo record);

    int insertSelective(RoutePo record);

    int deleteByPrimaryKey(Integer id);

    List<RoutePo> selectAll();

    Map<String, String> updateByPrimaryKey();
}