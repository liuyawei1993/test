package com.dp.serverrest.service.api;

import com.dp.serverrest.po.RoutePo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @interfaceName: RouteVoService
 * @description: 路由管理
 * @author: yuanyubo
 * @create: 2019-08-19
 */
public interface RouteVoService {
    public Map<String, Object> addRouteVo(RoutePo routeVo);

    public Map<String, Object> deleteRouteVo(RoutePo routeVo);

    public PageInfo<RoutePo> getRouteVoList(int page, int limit);

    public Map<String, Object> modifyRouteVo(RoutePo oldRoutePo, RoutePo newRoutepo);
}
