package com.dp.serverrest.dao;

import com.dp.serverrest.po.IpWhitelistPo;
import com.dp.serverrest.po.VulnerabilityWhitelistPo;

import java.util.List;

public interface IpWhitelistPoMapper extends BasePoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(IpWhitelistPo record);

    int insertSelective(IpWhitelistPo record);

    IpWhitelistPo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(IpWhitelistPo record);

    int updateByPrimaryKey(IpWhitelistPo record);

    List<VulnerabilityWhitelistPo> selectAll();
}