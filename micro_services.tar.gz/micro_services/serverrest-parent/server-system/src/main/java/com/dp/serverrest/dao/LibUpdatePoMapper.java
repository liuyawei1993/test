package com.dp.serverrest.dao;
import com.dp.serverrest.po.LibUpdatePo;
public interface LibUpdatePoMapper extends BasePoMapper {

    int deleteByPrimaryKey(Integer id);

    int insert(LibUpdatePo record);

    int insertSelective(LibUpdatePo record);

    LibUpdatePo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(LibUpdatePo record);

    int updateByPrimaryKey(LibUpdatePo record);
}