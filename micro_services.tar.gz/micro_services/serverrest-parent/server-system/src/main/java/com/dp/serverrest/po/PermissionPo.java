package com.dp.serverrest.po;

/**
 * @author yuanyubo
 * @date 2019-09-03
 */
public class PermissionPo {
    private Integer id;

    private String perName;

    private String url;

    private String icon;

    private Integer parentId;

    private Byte perType;

    private Byte perLevel;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPerName() {
        return perName;
    }

    public void setPerName(String perName) {
        this.perName = perName == null ? null : perName.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon == null ? null : icon.trim();
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Byte getPerType() {
        return perType;
    }

    public void setPerType(Byte perType) {
        this.perType = perType;
    }

    public Byte getPerLevel() {
        return perLevel;
    }

    public void setPerLevel(Byte perLevel) {
        this.perLevel = perLevel;
    }

    @Override
    public String toString() {
        return "PermissionPo{" +
                "id=" + id +
                ", perName='" + perName + '\'' +
                ", url='" + url + '\'' +
                ", icon='" + icon + '\'' +
                ", parentId=" + parentId +
                ", perType=" + perType +
                ", perLevel=" + perLevel +
                '}';
    }
}