/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.impl;

import java.util.Date;
import java.util.Map;

import com.dp.serverrest.service.api.PolicyManageService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dp.serverrest.dao.SensorPolicyPoMapper;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.SensorPolicyPo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月17日 下午5:14:42
 */
@Service
@Transactional(readOnly = false)
public class PolicyManageServiceImpl implements PolicyManageService {
    @Autowired
    private SensorPolicyPoMapper dao;

    /*
     * 添加策略的具体实现
     */
    @Override
    public Map<String, String> addPolicy(SensorPolicyPo policy) {
        policy.setCreateTime(new Date().getTime());
        return CommonUtils.addData(policy, dao);
    }

    /*
     * 删除策略的具体实现
     */
    @Override
    public Map<String, String> deletePolicy(int id) {
        return CommonUtils.deleteData(id, dao);
    }

    /*
     * 获取策略列表的具体实现
     */
    @Override
    public PageInfo<SensorPolicyPo> getPolicyList(int page, int limit) {
        PageHelper.startPage(page, limit);
        return new  PageInfo<SensorPolicyPo>(dao.selectAll());
    }

    @Override
    public PageInfo<SensorPolicyPo> getPolicyByPage(int page, int limit) {
        PageHelper.startPage(page,limit);
        return new PageInfo<SensorPolicyPo>(dao.selectAll());
    }

    @Override
    public Map<String, String> modifyPolicy(int id, SensorPolicyPo policy) {
        policy.setId(id);
        return CommonUtils.modifyData(id, policy, dao);
    }
}
