/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.api;

import java.util.Map;

import com.dp.serverrest.po.SensorBaseInfoPo;
import com.dp.serverrest.po.SensorCfgPo;
import com.dp.serverrest.po.SensorManagePo;
import com.dp.serverrest.po.SensorStatusInfoPo;
import com.github.pagehelper.PageInfo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月16日 上午10:45:56
 * 
 */

public interface SysSensorManageService extends BaseService {

    public Map<String, String> addSensor(SensorManagePo sensorManage);

    public Map<String, String> deleteSensor(int id);

    public SensorBaseInfoPo getSensorBaseInfo(int id);

    public SensorCfgPo getSensorCfgInfo(int id);

    public PageInfo<SensorManagePo> getSensorList(int page, int limit);

    public SensorStatusInfoPo getSensorStatusInfo(int id);

    public Map<String, String> modifySensor(int id, SensorManagePo sensorManage);

    public Map<String, String> modifySensorCfg(int id, Map<Object, Object> sensorCfg);

}
