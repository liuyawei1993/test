package com.dp.serverrest.service.api;

import com.dp.serverrest.po.InterfaceManagePo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @interfaceName: InterfaceManageVoService
 * @description: 接口管理
 * @author: yuanyubo
 * @create: 2019-08-20
 */
public interface InterfaceManageVoService {

    public PageInfo<InterfaceManagePo> getInterfaceManageVoList(int page, int limit);

    public Map<String, Object> modifyInterfaceManagePo(String name, InterfaceManagePo interfaceManageVo);

}
