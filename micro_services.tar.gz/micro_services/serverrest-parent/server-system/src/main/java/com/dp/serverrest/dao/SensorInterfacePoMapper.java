package com.dp.serverrest.dao;


import java.util.List;

import com.dp.serverrest.po.SensorInterfacePo;

public interface SensorInterfacePoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer infId);

    
    int insert(SensorInterfacePo record);

    
    int insertSelective(SensorInterfacePo record);

    
    SensorInterfacePo selectByPrimaryKey(Integer infId);
    
    List<SensorInterfacePo> selectBySensorId(Integer sensorId);

    
    int updateByPrimaryKeySelective(SensorInterfacePo record);

    
    int updateByPrimaryKey(SensorInterfacePo record);
}