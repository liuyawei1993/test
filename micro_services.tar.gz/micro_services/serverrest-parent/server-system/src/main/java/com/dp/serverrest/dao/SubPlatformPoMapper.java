package com.dp.serverrest.dao;

import com.dp.serverrest.po.SubPlatformPo;

public interface SubPlatformPoMapper extends BasePoMapper {
    
    int insert(SubPlatformPo record);

    
    int insertSelective(SubPlatformPo record);
}