/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dp.serverrest.po.SystemLogPo;
import com.dp.serverrest.service.api.RoleManageService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dp.serverrest.dao.RolePoMapper;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.RolePo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月16日 上午9:11:51
 */
@Service
@Transactional(readOnly = false)
public class RoleManageServiceImpl implements RoleManageService {
    @Autowired
    private RolePoMapper dao;
    @Autowired
    private LoginServiceImpl loginService;

    /**
     * 添加角色的具体实现
     */
    @Override
    public Map<String, String> addRole(RolePo role) {
        RolePo roleVo = dao.selectRoleVoByName(role.getRoleName());
        SystemLogPo systemLogPo = new SystemLogPo();
        if (roleVo==null){
            systemLogPo.setOpt("新增角色");
            return CommonUtils.addData(role, dao);
        }else {
            HashMap<String, String> stringStringHashMap = new HashMap<>(16);
            stringStringHashMap.put("err","角色名重复");
            return stringStringHashMap;
        }
    }

    /**
     * 删除角色的具体实现
     */
    @Override
    public Map<String, String> deleteRole(int id) {
        return CommonUtils.deleteData(id, dao);
    }

    /**
     * 获取角色列表的具体实现
     */
    @Override
    public PageInfo<RolePo> getRoleList(int page, int limit,Integer userId) {

        PageHelper.startPage(page, limit);
        return new PageInfo<RolePo>(dao.selectAll(userId));
    }

    /**
     * 修改角色的具体实现
     */
    @Override
    public Map<String, String> modifyRole(int id, RolePo role) {
        role.setRoleId(id);
        return CommonUtils.modifyData(id, role, dao);
    }

}
