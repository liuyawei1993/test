package com.dp.serverrest.service.impl;

import com.dp.serverrest.po.RoutePo;
import com.dp.serverrest.service.api.RouteVoService;
import com.dp.serverrest.service.util.CommonUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @className: RouteVoServiceImpl
 * @description: 路由管理
 * @author: yuanyubo
 * @create: 2019-08-19
 */
@Service
@Transactional(readOnly = false)
public class RouteVoServiceImpl implements RouteVoService {

    @Override
    public Map<String, Object> addRouteVo(RoutePo routeVo) {
        CommonUtils.ShellResult shellResult;
        shellResult = CommonUtils.callShell(
                "route add -net " + routeVo.getIp()
                        + " gw " + routeVo.getGateway()
                        + " netmask " + routeVo.getSubMask()
                        + " dev " + routeVo.getDevName());
        if (shellResult.isSuccess) {
            //route add 命令成功后写入配置文件，使路由设置在重启后也生效
            shellResult = CommonUtils.callShell("echo \"any net " + routeVo.getIp()
                    + " gw " + routeVo.getGateway() + " netmask "
                    + routeVo.getSubMask() + " dev "
                    + routeVo.getDevName() + "\" >> /etc/sysconfig/static-routes\n");
            if (shellResult.isSuccess) {
                return CommonUtils.getResultMap(true);
            } else {
                return CommonUtils.getResultMap(false, shellResult.message);
            }
        } else {
            return CommonUtils.getResultMap(false, shellResult.message);
        }
    }

    @Override
    public Map<String, Object> deleteRouteVo(RoutePo routeVo) {
        CommonUtils.ShellResult shellResult;
        shellResult = CommonUtils.callShell(
                "route del -net " + routeVo.getIp()
                        + " gw " + routeVo.getGateway()
                        + " netmask " + routeVo.getSubMask()
                        + " dev " + routeVo.getDevName());
        if (shellResult.isSuccess) {
            //route del 命令成功后删除配置文件，使路由设置在重启后也生效
            shellResult = CommonUtils.callShell("sed -i '/any net " + routeVo.getIp() +
                    " gw " + routeVo.getGateway() +
                    " netmask " + routeVo.getSubMask() +
                    " dev " + routeVo.getDevName() +
                    "/d' /etc/sysconfig/static-routes"
            );
            if (shellResult.isSuccess) {
                return CommonUtils.getResultMap(true);
            } else {
                return CommonUtils.getResultMap(false, shellResult.message);
            }
        } else {
            return CommonUtils.getResultMap(false, shellResult.message);
        }
    }

    @Override
    public PageInfo<RoutePo> getRouteVoList(int page, int limit) {
        PageHelper.startPage(page,limit);
        List<RoutePo> routePoList = Lists.newArrayList();
        CommonUtils.ShellResult shellResult;
        //调用shell获取路由信息
        shellResult = CommonUtils.callShell("route -n | awk '{print $1,$2,$3,$8}'");
        if (shellResult.isSuccess) {
            //解析shell返回的结果
            String[] lines = shellResult.message.split("\n");
            for (int i = 2; i < lines.length; i++) {
                RoutePo routePo = new RoutePo();
                System.out.println(lines[i]);
                String[] data = lines[i].split(" ");
                if (data.length == 4) {
                    routePo.setIp(data[0]);
                    routePo.setGateway(data[1]);
                    routePo.setSubMask(data[2]);
                    routePo.setDevName(data[3]);
                }
                routePoList.add(routePo);
            }
        }
        return new PageInfo<RoutePo>(routePoList);
    }

    @Override
    public Map<String, Object> modifyRouteVo(RoutePo oldRouteVo, RoutePo newRouteVo) {
        Map<String, Object> result = deleteRouteVo(oldRouteVo);
        if ((boolean) result.get("result")) {
            result = addRouteVo(newRouteVo);
            if ((boolean) result.get("result")) {
                return CommonUtils.getResultMap(true);
            } else {
                return CommonUtils.getResultMap(false, result.get("errMessage").toString());
            }
        } else {
            return CommonUtils.getResultMap(false, result.get("errMessage").toString());
        }
    }
}
