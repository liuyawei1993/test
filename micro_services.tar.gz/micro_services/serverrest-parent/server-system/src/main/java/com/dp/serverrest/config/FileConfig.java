package com.dp.serverrest.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @className: FileConfig
 * @description: 文件上传下载配置类
 * @author: yuanyubo
 * @create: 2019-08-31
 */
@Component
@ConfigurationProperties(prefix = "dptech")
public class FileConfig {

    /**
     * 上传路径
     */
    private String uploadPath;

    @Override
    public String toString() {
        return "FileConfig{" +
                "uploadPath='" + uploadPath + '\'' +
                '}';
    }

    public String getUploadPath() {
        return uploadPath;
    }

    public void setUploadPath(String uploadPath) {
        this.uploadPath = uploadPath;
    }

}
