package com.dp.serverrest.config.aop;

import com.dp.serverrest.po.SystemLogPo;
import com.dp.serverrest.service.api.SystemLogService;
import com.dp.serverrest.service.api.UserManageService;
import com.dp.serverrest.service.util.HttpContextUtils;
import com.dp.serverrest.service.util.TimeUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * @className: LogAspect
 * @description: aop切面实现类
 * @author: yuanyubo
 * @create: 2019-09-11
 */
@Aspect
@Component
public class LogAspect {

    @Autowired
    private SystemLogService systemLogService;

    @Autowired
    private UserManageService userManageService;

    @Pointcut("@annotation(com.dp.serverrest.config.aop.Log)")
    public void logPointCut() {
    }

    @Around("logPointCut()")
    public Object around(ProceedingJoinPoint point) throws Throwable {
        // 执行方法
        Object result = point.proceed();
        //异步保存日志
        saveLog(point, result);
        return result;
    }

    void saveLog(ProceedingJoinPoint joinPoint, Object result) throws InterruptedException {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        SystemLogPo sysLog = new SystemLogPo();
        Log syslog = method.getAnnotation(Log.class);
        if (syslog != null) {
            // 注解上的描述
            sysLog.setOpt(syslog.value());
        }
        // 获取request 保存操作用户id
        HttpServletRequest request = HttpContextUtils.getHttpServletRequest();
        Integer userId = (Integer) request.getSession().getAttribute("userId");
        //用户id为null时说明登录失败 不予存库
        if (userId != null) {
            sysLog.setUserId(userId);
            sysLog.setUserName(userManageService.selectById(userId).getUserName());
            // 保存当前时间
            sysLog.setOptTime(TimeUtils.getCurrentTime());

            //保存返回信息
            HashMap<String, Object> hashMap = (HashMap<String, Object>) result;
            if (hashMap.containsKey("isSuccess")) {
                boolean isSuccess = (boolean) hashMap.get("isSuccess");
                if (isSuccess) {
                    sysLog.setResult("成功");
                } else {
                    sysLog.setResult("失败");
                }
            } else {
                sysLog.setResult("");
            }
            if (hashMap.containsKey("errMessage")) {
                sysLog.setMessage((String) hashMap.get("errMessage"));
            } else {
                sysLog.setMessage("");
            }
            // 保存系统日志
            systemLogService.insert(sysLog);
        }
    }
}
