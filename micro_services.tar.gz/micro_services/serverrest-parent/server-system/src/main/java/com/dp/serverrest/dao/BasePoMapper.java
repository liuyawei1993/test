/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.dao;

import com.dp.serverrest.po.BasePo;

/** 
	* @author author zhangchao: 
	* @version 创建时间：2019年8月16日 上午9:25:07 
	* 
	*/

public interface BasePoMapper {
    
    int insert(BasePo record);
    
    int updateByPrimaryKey(BasePo vo);

    int updateByPrimaryKeySelective(BasePo vo);

    int deleteByPrimaryKey(int id);
}
