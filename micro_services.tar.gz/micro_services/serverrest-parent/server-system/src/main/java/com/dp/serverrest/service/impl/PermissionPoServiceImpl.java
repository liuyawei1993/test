package com.dp.serverrest.service.impl;

import com.dp.serverrest.dao.PermissionPoMapper;
import com.dp.serverrest.dto.PermissionDTO;
import com.dp.serverrest.po.PermissionPo;
import com.dp.serverrest.service.api.PermissionPoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @className: PermissionPoServiceImpl
 * @description: 菜单权限实现类
 * @author: yuanyubo
 * @create: 2019-09-04
 */
@Service
public class PermissionPoServiceImpl implements PermissionPoService {

    @Autowired
    private PermissionPoMapper permissionPoMapper;

    /**
     * 获取 全部的菜单权限
     *
     * @return
     */
    @Override
    public HashMap<String,Object> selectAll() {

        HashMap<String, Object> result = new HashMap<>(16);


        List<PermissionPo> TopPermissionPo = permissionPoMapper.selectOneAll();
        //二级菜单返回的时候需要判断用户，只有超级管理员能看到用户管理和角色管理
        List<PermissionPo> TwoPermissionPo = permissionPoMapper.selectTowAll();
        List<PermissionPo> ThreePermissionPo = permissionPoMapper.selectThreeAll();

        //1.定义返回接收集合
        ArrayList<Object> objects1 = new ArrayList<>();

        //2.遍历顶级菜单
        for (int i = 0; i < TopPermissionPo.size(); i++) {
            //a.定义接收二级菜单map集合
            HashMap<String, Object> stringObjectHashMap = new HashMap<>(16);
            //定义二级菜单返回list集合
            ArrayList<Object> objects = new ArrayList<>();
            for (int j = 0; j < TwoPermissionPo.size(); j++) {
                //b.定义三级菜单接收map集合
                HashMap<String, Object> stringObjectHashMap2 = new HashMap<>(16);
                //定义三级菜单返回list集合
                ArrayList<Object> objects2 = new ArrayList<>();
                for (int k = 0; k < ThreePermissionPo.size(); k++) {
                    if (ThreePermissionPo.get(k).getParentId().equals(TwoPermissionPo.get(j).getId())) {
                        //c.接收三级菜单列表
                        PermissionDTO permissionDTO = new PermissionDTO();
                        permissionDTO.setId(ThreePermissionPo.get(k).getId());
                        permissionDTO.setIcon(ThreePermissionPo.get(k).getIcon());
                        permissionDTO.setName(ThreePermissionPo.get(k).getPerName());
                        permissionDTO.setParentId(ThreePermissionPo.get(k).getParentId());
                        permissionDTO.setPerLevel(ThreePermissionPo.get(k).getPerLevel());
                        permissionDTO.setUrl(ThreePermissionPo.get(k).getUrl());
                        objects2.add(permissionDTO);
                    }
                }
                //封装二级返回map
                stringObjectHashMap2.put("children", objects2);
                stringObjectHashMap2.put("name", TwoPermissionPo.get(j).getPerName());
                stringObjectHashMap2.put("url", TwoPermissionPo.get(j).getUrl());
                stringObjectHashMap2.put("id", TwoPermissionPo.get(j).getId());
                stringObjectHashMap2.put("icon", TwoPermissionPo.get(j).getIcon());
                stringObjectHashMap2.put("perLevel", TwoPermissionPo.get(j).getPerLevel());
                if (TopPermissionPo.get(i).getId().equals(TwoPermissionPo.get(j).getParentId())) {
                    //接收二级菜单列表
                    objects.add(stringObjectHashMap2);
                }
            }
            //封装一级菜单返回map集合
            stringObjectHashMap.put("children", objects);
            stringObjectHashMap.put("name", TopPermissionPo.get(i).getPerName());
            stringObjectHashMap.put("url", TopPermissionPo.get(i).getUrl());
            stringObjectHashMap.put("icon", TopPermissionPo.get(i).getIcon());
            stringObjectHashMap.put("id",TopPermissionPo.get(i).getId());
            stringObjectHashMap.put("perLevel", TopPermissionPo.get(i).getPerLevel());
            //封装一级菜单列表
            objects1.add(stringObjectHashMap);
        }

        //封装数据返回map
        result.put("menu", objects1);
        result.put("isSuccess", true);

        return result;
    }
}
