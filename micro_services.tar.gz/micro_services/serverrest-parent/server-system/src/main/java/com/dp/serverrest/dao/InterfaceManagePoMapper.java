package com.dp.serverrest.dao;
import com.dp.serverrest.po.InterfaceManagePo;

import java.util.List;

public interface InterfaceManagePoMapper extends BasePoMapper {

    int deleteByPrimaryKey(Integer id);

    int insert(InterfaceManagePo record);

    int insertSelective(InterfaceManagePo record);

    InterfaceManagePo selectByPrimaryKey(Integer id);

    List<InterfaceManagePo> selectAll();

    int updateByPrimaryKeySelective(InterfaceManagePo record);

    int updateByPrimaryKeyWithBLOBs(InterfaceManagePo record);

    int updateByPrimaryKey(InterfaceManagePo record);
}