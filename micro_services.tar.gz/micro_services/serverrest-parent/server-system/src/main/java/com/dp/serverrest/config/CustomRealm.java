/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.config;

import java.util.HashSet;
import java.util.Set;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AccountException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import com.dp.serverrest.dao.UserPoMapper;
import com.dp.serverrest.po.UserPo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年9月4日 下午8:27:58
 * 
 */
public class CustomRealm extends AuthorizingRealm {

    @Autowired
    private UserPoMapper dao;

    /**
     * 获取即将需要认证的信息
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken)
	    throws AuthenticationException {
	System.out.println("-------身份认证方法--------");
	String userName = (String) authenticationToken.getPrincipal();
	UserPo user = dao.selectByName(userName);
	if (user == null) {
	    throw new AccountException("用户名不正确");
	}
	SimpleAuthenticationInfo info = new SimpleAuthenticationInfo(user, user.getUserPassword(), getName());
	return info;
    }

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
	String username = (String) SecurityUtils.getSubject().getPrincipal();
	SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
	Set<String> stringSet = new HashSet<>();
	stringSet.add("user:show");
	stringSet.add("user:admin");
	info.setStringPermissions(stringSet);
	return info;
    }
}
