package com.dp.serverrest.dao;


import com.dp.serverrest.po.SensorManagePo;

import java.util.List;

public interface SensorManagePoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer sensorId);

    
    int insert(SensorManagePo record);

    
    int insertSelective(SensorManagePo record);

    
    SensorManagePo selectByPrimaryKey(Integer sensorId);
    
    List<SensorManagePo> selectAll();

    
    int updateByPrimaryKeySelective(SensorManagePo record);

    
    int updateByPrimaryKey(SensorManagePo record);

    /**
     * 根据探针ID查询探针信息
     * @param sensorName
     * @return
     */
    SensorManagePo selectByName(String sensorName);
}