package com.dp.serverrest.dao;


import java.util.List;

import com.dp.serverrest.po.SensorPolicyPo;

public interface SensorPolicyPoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer id);

    int insert(SensorPolicyPo record);

    int insertSelective(SensorPolicyPo record);

    List<SensorPolicyPo> selectAll();

    SensorPolicyPo selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(SensorPolicyPo record);

    int updateByPrimaryKeySelective(SensorPolicyPo record);
}