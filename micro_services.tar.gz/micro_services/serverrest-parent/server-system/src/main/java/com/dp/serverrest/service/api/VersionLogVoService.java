package com.dp.serverrest.service.api;

import com.dp.serverrest.po.VersionLogPo;
import com.github.pagehelper.PageInfo;

import java.util.List;
import java.util.Map;

/**
 * @interfaceName: VersionLogVoService
 * @description: 日志设置
 * @author: yuanyubo
 * @create: 2019-08-19
 */
public interface VersionLogVoService {

    public Map<String, String> addVersionLogVo(VersionLogPo versionLogVo);

    public Map<String, String> modifyVersionLogVo(int id, VersionLogPo versionLogVo);

    public Map<String, String> deleteVersionLogVo(int id);

    public PageInfo<VersionLogPo> getVersionLogVoList(int page, int limit);

    public List<VersionLogPo> getVersionLogVoAll();
}
