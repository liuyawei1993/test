package com.dp.serverrest.dao;

import com.dp.serverrest.po.SensorCfgPo;
import com.dp.serverrest.po.SensorCfgPoWithBLOBs;

public interface SensorCfgPoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer sensorId);

    
    int insert(SensorCfgPoWithBLOBs record);

    
    int insertSelective(SensorCfgPoWithBLOBs record);

    
    SensorCfgPoWithBLOBs selectByPrimaryKey(Integer sensorId);

    
    int updateByPrimaryKey(SensorCfgPo record);

    
    int updateByPrimaryKeySelective(SensorCfgPoWithBLOBs record);

    
    int updateByPrimaryKeyWithBLOBs(SensorCfgPoWithBLOBs record);
}