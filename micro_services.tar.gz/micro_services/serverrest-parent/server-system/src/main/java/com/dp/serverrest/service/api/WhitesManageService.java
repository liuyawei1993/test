/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.api;

import com.dp.serverrest.po.AttackWhitelistPo;
import com.dp.serverrest.po.IpWhitelistPo;
import com.dp.serverrest.po.VulnerabilityWhitelistPo;
import com.github.pagehelper.PageInfo;

import java.util.Map;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 下午4:24:22
 * 信任列表接口类
 */

public interface WhitesManageService {

    //========================攻击白名单==============================
    /**
     * 新增 攻击白名单
     *
     * @param attackWhitelistPo
     * @return
     */
    Map<String, String> addAttackWhitelistPo(AttackWhitelistPo attackWhitelistPo);

    /**
     * 修改 攻击白名单
     * @param id
     * @param attackWhitelistPo
     * @return
     */
    Map<String, String> modifyAttackWhitelistPo(int id, AttackWhitelistPo attackWhitelistPo);

    /**
     * 删除 攻击白名单
     * @param id
     * @return
     */
    Map<String, String> deleteAttackWhitelistPo(int id);

    /**
     * 分页查询 攻击白名单
     * @param page
     * @param limit
     * @return
     */
    PageInfo<AttackWhitelistPo> getAttackWhitelistPoList(int page, int limit);



    //=========================IP白名单===============================

    /**
     * 新增 IP白名单
     *
     * @param ipWhitelistPo
     * @return
     */
    Map<String, String> addIpWhitelistPo(IpWhitelistPo ipWhitelistPo);

    /**
     * 修改 IP白名单
     * @param id
     * @param ipWhitelistPo
     * @return
     */
    Map<String, String> modifyIpWhitelistPoWhites(int id, IpWhitelistPo ipWhitelistPo);

    /**
     * 删除 IP白名单
     * @param id
     * @return
     */
    Map<String, String> deleteIpWhitelistPoWhites(int id);

    /**
     * 分页查询 IP白名单
     * @param page
     * @param limit
     * @return
     */
    PageInfo<VulnerabilityWhitelistPo> getIpWhitelistPoList(int page, int limit);


    //========================漏洞白名单==============================
    /**
     * 新增 漏洞白名单
     *
     * @param vulnerabilityWhitelistVo
     * @return
     */
    Map<String, String> addVulnerableWhites(VulnerabilityWhitelistPo vulnerabilityWhitelistVo);

    /**
     * 修改漏洞白名单
     * @param id
     * @param vulnerabilityWhitelistVo
     * @return
     */
    Map<String, String> modifyVulnerableWhites(int id, VulnerabilityWhitelistPo vulnerabilityWhitelistVo);

    /**
     * 删除 漏洞白名单
     * @param id
     * @return
     */
    Map<String, String> deleteVulnerableWhites(int id);

    /**
     * 分页查询 漏洞白名单
     * @param page
     * @param limit
     * @return
     */
    PageInfo<VulnerabilityWhitelistPo> getVulnerableWhitesList(int page, int limit);


}
