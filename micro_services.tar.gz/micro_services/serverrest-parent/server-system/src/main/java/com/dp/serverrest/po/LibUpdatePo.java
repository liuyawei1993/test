package com.dp.serverrest.po;

public class LibUpdatePo extends BasePo {
    
    private Integer id;

    
    private String name;

    
    private String currentVersion;

    
    private String latestVersion;

    
    private String cloudVersion;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getName() {
        return name;
    }

    
    public void setName(String name) {
        this.name = name;
    }

    
    public String getCurrentVersion() {
        return currentVersion;
    }

    
    public void setCurrentVersion(String currentVersion) {
        this.currentVersion = currentVersion;
    }

    
    public String getLatestVersion() {
        return latestVersion;
    }

    
    public void setLatestVersion(String latestVersion) {
        this.latestVersion = latestVersion;
    }

    
    public String getCloudVersion() {
        return cloudVersion;
    }

    
    public void setCloudVersion(String cloudVersion) {
        this.cloudVersion = cloudVersion;
    }
}