/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.api;

import com.dp.serverrest.po.PlatformCfgPo;

import java.util.Map;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月17日 下午8:04:22
 */
public interface PlatformCfgService extends BaseService {

	/**
	 * 查询平台配置
	 * @return
	 */
    public PlatformCfgPo getPlatformCfg();

	/**
	 * 修改平台配置
	 * @param platformCfgPo
	 * @return
	 */
	public Map<String, String> modifyPlatformCfg(PlatformCfgPo platformCfgPo);

}
