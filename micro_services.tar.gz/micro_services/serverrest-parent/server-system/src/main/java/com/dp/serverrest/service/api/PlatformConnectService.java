package com.dp.serverrest.service.api;

import com.dp.serverrest.po.PlatformCfgPo;

import java.util.Map;

/**
 * @interfaceName: PlatformConnectService
 * @description: 平台级联
 * @author: yuanyubo
 * @create: 2019-08-19
 */
public interface PlatformConnectService {

    public Map<String, String> addPlatformCfgVo(PlatformCfgPo platformCfgVo);

    public Map<String, String> deletePlatformCfgVo(int id);

    public PlatformCfgPo getPlatformCfgVo();

    public Map<String, String> modifyPlatformCfgVo(int id, PlatformCfgPo policy);

}
