package com.dp.serverrest.service.impl;

import com.dp.serverrest.po.InterfaceManagePo;
import com.dp.serverrest.service.api.InterfaceManageVoService;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.service.util.file.FileUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @className: InterfaceManageVoServiceImpl
 * @description: 接口管理
 * @author: yuanyubo
 * @create: 2019-08-20
 */
@Service
@Transactional(readOnly = false)
public class InterfaceManageVoServiceImpl implements InterfaceManageVoService {

    /**
     * 获取 接口列表
     *
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<InterfaceManagePo> getInterfaceManageVoList(int page, int limit) {
        PageHelper.startPage(page, limit);
        List<InterfaceManagePo> interfaceManagePoList = Lists.newArrayList();

        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface networkInterface = interfaces.nextElement();
                String name = networkInterface.getDisplayName();
                //跳过本地回环接口
                if (networkInterface.isLoopback()) {
                    continue;
                }
                InterfaceManagePo interfaceManagePo = new InterfaceManagePo();
                interfaceManagePo.setInterfaceName(name);
                interfaceManagePo.setNetworkStatus(networkInterface.isUp() ? 1 : 0);
                //调用shell用接口名获取网关
                String cmd = "route -n |grep UG|grep " + name + " | awk 'NR==1{print $2}'";
                String gateway = CommonUtils.callShell(cmd).message;
                interfaceManagePo.setGateway(gateway == null ? "" : gateway);
                //使用java获取其他网络信息
                for (InterfaceAddress interfaceAddress : networkInterface.getInterfaceAddresses()) {
                    int npf = interfaceAddress.getNetworkPrefixLength();
                    InetAddress address = interfaceAddress.getAddress();
                    String addressStr = address == null ? "" : address.getHostAddress();
                    if (CommonUtils.validIPv4Address(addressStr)) {
                        interfaceManagePo.setIp(addressStr);
                        interfaceManagePo.setNetMask(Integer.toString(npf));
                    }
                }
                interfaceManagePoList.add(interfaceManagePo);
            }
        } catch (SocketException e) {
            e.printStackTrace();
        }
        return new PageInfo<InterfaceManagePo>(interfaceManagePoList);
    }

    /**
     * 修改 接口
     *
     * @param interfaceManageVo
     * @return
     */
    @Override
    public Map<String, Object> modifyInterfaceManagePo(String name, InterfaceManagePo interfaceManageVo) {
        Map<String, String> map = new HashMap<>();
        Map<String, Object> result = Maps.newHashMap();

        map.put("IPADDR", interfaceManageVo.getIp());
        map.put("PREFIX", interfaceManageVo.getNetMask());
        map.put("GATEWAY", interfaceManageVo.getGateway());
        try {
            //修改配置文件
            FileUtil.changeConfig("/etc/sysconfig/network-scripts/ifcfg-" + name, map);
            //up 或者 down 接口
            String cmd = "if" + (interfaceManageVo.getNetworkStatus() == 1 ? "up " : "down ") + name;
            CommonUtils.callShell(cmd);
            result = CommonUtils.getResultMap(true);
        } catch (IOException e) {
            e.printStackTrace();
            result = CommonUtils.getResultMap(false, e.getMessage());
        } finally {
            return result;
        }
    }
}
