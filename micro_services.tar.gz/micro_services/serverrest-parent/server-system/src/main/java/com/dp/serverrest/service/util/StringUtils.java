package com.dp.serverrest.service.util;

import com.alibaba.fastjson.JSONArray;

import java.util.List;

/**
 * @className: StringUtils
 * @description: String工具类
 * @author: yuanyubo
 * @create: 2019-08-22
 */
public class StringUtils {

    /**
     * 字符串转json数组
     * @param string
     * @return
     */
    public static List stringToList(String string){
        JSONArray jsonArray = JSONArray.parseArray(string);
        return jsonArray;
    }




}
