/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import com.dp.serverrest.po.PlatformCfgPo;
import com.dp.serverrest.service.impl.PlatformCfgServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** 
	* @author author zhangchao: 
	* @version 创建时间：2019年8月15日 上午11:07:23 
	* 
	*/
@RestController
@RequestMapping(value = "/stap/systemManage/baseConfig")
public class BaseConfigController {

	@Autowired
	private PlatformCfgServiceImpl platformCfgService;

	/**
	 * 平台时间更新 同步管理
	 * @param platformCfgPo
	 * @return
	 */
	@PostMapping("/platformConfig/timeUpdate")
	public Map<String,String> modifyPlatformCfg(@RequestBody PlatformCfgPo platformCfgPo){
        return platformCfgService.modifyPlatformCfg(platformCfgPo);
    }

}
