package com.dp.serverrest.dao;

import com.dp.serverrest.po.SystemLogPo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author
 */
public interface SystemLogPoMapper extends BasePoMapper {

    /**
     * 根据主键进行日志删除
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 新增 日志
     * @param record
     * @return
     */
    int insert(SystemLogPo record);

    /**
     * 字段非空新增
     * @param record
     * @return
     */
    int insertSelective(SystemLogPo record);

    /**
     * 根据主键查询日志
     * @param id
     * @return
     */
    SystemLogPo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SystemLogPo record);
    
    int updateByPrimaryKeyWithBLOBs(SystemLogPo record);

    int updateByPrimaryKey(SystemLogPo record);

    /**
     * 查询全部日志
     * @return
     */
    List<SystemLogPo> selectAll();

    /**
     * 根据用户id获取日志
     * @param userId
     * @return
     */
    List<SystemLogPo> selectAllByUserId(Integer userId);

    /**
     *  根据时间段查询日志
     * @param startTime
     * @param endTime
     * @param userId
     * @return
     */
    List<SystemLogPo> selectByTime(@Param("startTime") Long startTime, @Param("endTime") Long endTime,@Param("userId") Integer userId);

    /**
     * 根据关键字查询日志
     * @param queryStr
     * @param userId
     * @return
     */
    List<SystemLogPo> selectByString(@Param("queryStr") String queryStr,@Param("userId") Integer userId);

}