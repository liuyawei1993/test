package com.dp.serverrest.dao;

import com.dp.serverrest.po.GlobalAttackPo;

import java.util.List;

public interface GlobalAttackPoMapper extends BasePoMapper {

    int deleteByPrimaryKey(Integer id);

    int insert(GlobalAttackPo record);

    int insertSelective(GlobalAttackPo record);

    List<GlobalAttackPo> selectByPrimaryKey();

    List<GlobalAttackPo> selectAll();

    int updateByPrimaryKeySelective(GlobalAttackPo record);

    int updateByPrimaryKey(GlobalAttackPo record);
}