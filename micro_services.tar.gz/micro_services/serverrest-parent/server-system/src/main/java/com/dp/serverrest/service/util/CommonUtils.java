/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.util;

import com.dp.serverrest.dao.BasePoMapper;
import com.dp.serverrest.po.BasePo;
import com.google.common.collect.Maps;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 上午11:48:45 公共方法类
 */

public class CommonUtils {

    /**
     * @param dao
     *            新增的通用方法
     * @return
     */
    public static Map<String, String> addData(BasePo vo, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        try {
            dao.insert(vo);
            result.put("success", "add success!");
        } catch (Exception e) {
            result.put("err", "add err!check it!");
        }
        return result;
    }

    /**
     * @param id
     * @param dao
     *            删除的通用方法
     * @return
     */
    public static Map<String, String> deleteData(int id, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.deleteByPrimaryKey(id);
        if (res > 0) {
            result.put("success", "delete success!");
        } else {
            result.put("err", "delete err!check it!");
        }
        return result;
    }

    /**
     * @Description: 获取resultMap
     * @Author: ZhangPeng
     * @Date: 2019/9/11
     */
    public static Map<String, Object> getResultMap(boolean isSuccess, String message) {
        Map<String, Object> result = new HashMap<>();
        result.put("result", isSuccess);
        result.put("errMessage", message);
        return result;
    }

    public static Map<String, Object> getResultMap(boolean isSuccess) {
        Map<String, Object> result = new HashMap<>();
        result.put("result", isSuccess);
        return result;
    }

    /**
     * 得到验证码图片
     *
     * @param out
     * @param number
     *            验证数字
     * @throws ServletException
     * @throws IOException
     */
    public static void getImage(OutputStream out, String number) throws ServletException, IOException {
        // 0.创建空白图片
        BufferedImage image = new BufferedImage(100, 30, BufferedImage.TYPE_INT_RGB);
        // 1.获取图片画笔
        Graphics g = image.getGraphics();
        Random r = new Random();
        // 2.设置画笔颜色(Random类中的nextInt(n)返回一个大于等于0，小于n的随机数)
        g.setColor(new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255)));
        // 3.绘制矩形的背景
        g.fillRect(0, 0, 100, 30);
        // 4.调用自定义的方法，获取长度为4的字母数字组合的字符串
        g.setColor(new Color(0, 0, 0));
        g.setFont(new Font(null, Font.BOLD, 24));
        // 5.设置颜色字体后，绘制字符串（x/y,最左边字符所处的位置）
        g.drawString(number, 20, 24);
        // 6.绘制8条干扰线(alpha表示透明度)
        for (int i = 0; i < 8; i++) {
            g.setColor(new Color(r.nextInt(255), r.nextInt(255), r.nextInt(255), r.nextInt(255)));
            g.drawLine(r.nextInt(100), r.nextInt(30), r.nextInt(100), r.nextInt(30));
        }
        ImageIO.write(image, "jpeg", out);
    }

    // 自定义方法，获取长度为size的字母数字组合的字符串
    public static String getNumber(int size) {
        String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        String number = "";
        Random r = new Random();
        for (int i = 0; i < size; i++) {
            number += str.charAt(r.nextInt(str.length()));
        }
        return number;
    }

    /**
     * @param dao
     *            修改的通用方法
     * @return
     */
    public static Map<String, String> modifyData(Integer id, BasePo vo, BasePoMapper dao) {
        Map<String, String> result = Maps.newHashMap();
        int res = dao.updateByPrimaryKey(vo);
        if (res > 0) {
            result.put("success", "modify success!");
        } else {
            result.put("err", "modify err!check it!");
        }
        return result;
    }

    /**
     * @Description: 校验是否是IPv4地址
     * @Param: IP
     * @return: boolean
     * @Author: ZhangPeng
     * @Date: 2019/9/5
     */
    public static boolean validIPv4Address(String IP) {
        if (IP == null) {
            return false;
        }
        String regex0 = "(\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5])";
        String regexIPv4 = regex0 + "(\\." + regex0 + "){3}";
        if (IP.matches(regexIPv4)) {
            return true;
        }
        return false;
    }

    public static ShellResult callShell(String commend) {
        ShellResult shellResult = new ShellResult();
        String[] cmd = {
                "/bin/bash",
                "-c",
                commend
        };
        try {
            Process process = Runtime.getRuntime().exec(cmd);
            BufferedReader stdInput = new BufferedReader(new InputStreamReader(process.getInputStream()));
            BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            int exitValue = process.waitFor();
            String line;
            StringBuilder result = new StringBuilder();
            if (exitValue == 0) {
                while ((line = stdInput.readLine()) != null) {
                    result.append(line).append("\n");
                }
                shellResult.isSuccess = true;
                shellResult.message = result.toString();
            } else {
                while ((line = stdError.readLine()) != null) {
                    result.append(line).append("\n");
                }
                shellResult.isSuccess = false;
                shellResult.message = result.toString();
            }
            stdInput.close();
            stdError.close();
            return shellResult;
        } catch (Throwable e) {
            shellResult.isSuccess = false;
            shellResult.message = e.getMessage();
            return shellResult;
        }
    }

    /**
     * @Description: 调用shell
     * @Author: ZhangPeng
     * @Date: 2019/9/11
     */
    public static class ShellResult {
        public boolean isSuccess;
        public String message;
    }
}
