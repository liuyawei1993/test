package com.dp.serverrest.po;

public class SensorCfgPo extends BasePo {
    
    private Integer sensorId;

    
    private Boolean trafficEnable;

    
    private Boolean attackEnable;

    
    private String trafficLogIp;

    
    private String attackLogIp;

    
    private String softVersion;

    
    private String sigVersion;

    
    public Integer getSensorId() {
        return sensorId;
    }

    
    public void setSensorId(Integer sensorId) {
        this.sensorId = sensorId;
    }

    
    public Boolean getTrafficEnable() {
        return trafficEnable;
    }

    
    public void setTrafficEnable(Boolean trafficEnable) {
        this.trafficEnable = trafficEnable;
    }

    
    public Boolean getAttackEnable() {
        return attackEnable;
    }

    
    public void setAttackEnable(Boolean attackEnable) {
        this.attackEnable = attackEnable;
    }

    
    public String getTrafficLogIp() {
        return trafficLogIp;
    }

    
    public void setTrafficLogIp(String trafficLogIp) {
        this.trafficLogIp = trafficLogIp;
    }

    
    public String getAttackLogIp() {
        return attackLogIp;
    }

    
    public void setAttackLogIp(String attackLogIp) {
        this.attackLogIp = attackLogIp;
    }

    
    public String getSoftVersion() {
        return softVersion;
    }

    
    public void setSoftVersion(String softVersion) {
        this.softVersion = softVersion;
    }

    
    public String getSigVersion() {
        return sigVersion;
    }

    
    public void setSigVersion(String sigVersion) {
        this.sigVersion = sigVersion;
    }
}