package com.dp.serverrest.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @className: FilePathConfig
 * @description: 配置文件映射路径 用于获取文件（图片）
 * spring boot2.x 使用 implements WebMvcConfigurer 代替废弃的 WebMvcConfigurerAdapter
 * @author: yuanyubo
 * @create: 2019-08-31
 */
@Configuration
public class FilePathConfig implements WebMvcConfigurer {

    @Autowired
    private FileConfig fileConfig;

    /**
     * 配置文件资源映射路径
     *
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/files/**").addResourceLocations("file:" + fileConfig.getUploadPath());
    }


}
