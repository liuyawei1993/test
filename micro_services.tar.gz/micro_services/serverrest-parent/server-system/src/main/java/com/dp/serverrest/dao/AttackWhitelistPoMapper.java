package com.dp.serverrest.dao;

import com.dp.serverrest.po.AttackWhitelistPo;

import java.util.List;

public interface AttackWhitelistPoMapper extends BasePoMapper{
    int deleteByPrimaryKey(Integer id);

    int insert(AttackWhitelistPo record);

    int insertSelective(AttackWhitelistPo record);

    AttackWhitelistPo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AttackWhitelistPo record);

    int updateByPrimaryKey(AttackWhitelistPo record);

    List<AttackWhitelistPo> selectAll();
}