/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import com.dp.serverrest.dto.LogDTO;
import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.service.impl.SystemLogServiceImpl;
import com.dp.serverrest.service.util.PageUtils;
import com.dp.serverrest.po.SystemLogPo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/** 
	* @author author zhangchao: 
	* @version 创建时间：2019年8月15日 上午10:44:48 
	* 
	*/
@RestController
@RequestMapping(value = "/stap/systemManage/systemLog")
public class SystemLogController {

	@Autowired
	private SystemLogServiceImpl systemLogService;

	@RequestMapping(value = "/logList",method = RequestMethod.POST)
	public PageDTO<SystemLogPo> logList(@RequestBody LogDTO logDto, HttpServletRequest request){
		Integer userId = (Integer) request.getSession().getAttribute("userId");
		if (logDto.getQueryStr()!=null&&logDto.getQueryStr()!=""){
			//根据关键字搜索日志信息
			PageUtils<SystemLogPo> systemLogVoPageUtils = new PageUtils<>();
			PageDTO<SystemLogPo> systemLogVoPageDTO = systemLogVoPageUtils.pageUtil(systemLogService.systemLogByQueryStr(logDto.getQueryStr(),logDto.getPage(), logDto.getLimit(),userId));
			return systemLogVoPageDTO;
		}else if (logDto.getStartTime()!=null&&logDto.getEndTime()!=null){
			//根据时间段搜索
			PageUtils<SystemLogPo> systemLogVoPageUtils = new PageUtils<>();
			PageDTO<SystemLogPo> systemLogVoPageDTO = systemLogVoPageUtils.pageUtil(systemLogService.systemLogByTime(logDto.getStartTime(),logDto.getEndTime(),logDto.getPage(), logDto.getLimit(),userId));
			return systemLogVoPageDTO;
		}else {
			PageUtils<SystemLogPo> systemLogVoPageUtils = new PageUtils<>();
			PageDTO<SystemLogPo> systemLogVoPageDTO = systemLogVoPageUtils.pageUtil(systemLogService.systemLogByUserId(logDto.getPage(),logDto.getLimit(),userId));
			return systemLogVoPageDTO;
		}
	}

}
