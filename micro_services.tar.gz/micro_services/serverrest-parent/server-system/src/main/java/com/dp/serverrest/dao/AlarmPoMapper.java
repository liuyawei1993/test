package com.dp.serverrest.dao;

import com.dp.serverrest.po.AlarmPo;

import java.util.List;

public interface AlarmPoMapper extends BasePoMapper {

    int deleteByPrimaryKey(Integer id);

    int insert(AlarmPo record);

    int insertSelective(AlarmPo record);

    List<AlarmPo> selectByPrimaryKey();

    List<AlarmPo> selectAll();

    int updateByPrimaryKeySelective(AlarmPo record);
    
    int updateByPrimaryKey(AlarmPo record);
}