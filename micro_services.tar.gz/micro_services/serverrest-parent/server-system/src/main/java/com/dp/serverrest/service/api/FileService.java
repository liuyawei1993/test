package com.dp.serverrest.service.api;

import com.dp.serverrest.po.FilePo;
import com.github.pagehelper.PageInfo;

/**
 * @interfaceName: FileService
 * @description: 文件上传Service接口
 * @author: yuanyubo
 * @create: 2019-08-31
 */
public interface FileService {

    /**
     * 新增 文件
     * @param filePo
     * @return
     */
    int save(FilePo filePo);

    /**
     * 删除 文件
     * @param id
     * @return
     */
    int remove(Integer id);

    /**
     * 根据ID查询文件信息
     * @param id
     * @return
     */
    FilePo get(Integer id);

    /**
     * 分页查询已上传的文件信息
     * @param page
     * @param limit
     * @return
     */
    PageInfo<FilePo> selectPage(Integer page,Integer limit);

}
