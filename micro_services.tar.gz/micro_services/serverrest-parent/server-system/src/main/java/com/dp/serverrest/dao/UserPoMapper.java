package com.dp.serverrest.dao;


import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.dp.serverrest.po.UserPo;

public interface UserPoMapper extends BasePoMapper {

    /**
     * 根据ID删除用户
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     * 新增用户
     * @param record
     * @return
     */
    int insert(UserPo record);

    /**
     * 新增用户(字段不为空)
     * @param record
     * @return
     */
    int insertSelective(UserPo record);

    /**
     * 用户登录
     * @param userName
     * @param password
     * @return
     */
    UserPo selectByNameAndPassword(@Param(value = "userName") String userName,
                                   @Param(value = "password") String password);

    /**
     * 查询全部用户
     * @return
     */
    List<UserPo> selectAll();


    /**
     * 查询用户创建的用
     * @param userId
     * @return
     */
    List<UserPo> selectAllById(Integer userId);

    /**
     * 根据用户名 查询用户信息
     * @param userName
     * @return
     */
    UserPo selectByName(@Param(value = "userName") String userName);

    /**
     * 根据ID查询用户信息
     * @param userId
     * @return
     */
    UserPo selectById(@Param(value = "userId") Integer userId);

    /**
     * 根据主键进行更新
     * @param record
     * @return
     */
    int updateByPrimaryKey(UserPo record);

    /**
     * 根据主键 进行字段非空更新
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(UserPo record);


    UserPo selectReturnUser(String userName);
}