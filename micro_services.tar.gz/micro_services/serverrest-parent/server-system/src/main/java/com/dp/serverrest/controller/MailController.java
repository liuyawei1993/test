package com.dp.serverrest.controller;

import com.dp.serverrest.dto.PlatformDTO;
import com.dp.serverrest.dto.ReturnDTO;
import com.dp.serverrest.service.impl.MailServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;
import java.util.Map;

/**
 * @className: MailController
 * @description: 邮件发送接口
 * @author: yuanyubo
 * @create: 2019-08-26
 */
@RestController
@RequestMapping(value = "/stap/systemManage/sysConfig")
public class MailController {
    @Autowired
    private MailServiceImpl mailService;

    /**
     * 邮件发送
     * @param mailDTO
     * @return
     */
    @PostMapping("/platformConfig/config")
    public Map<String,String> sendSimpleMail(@RequestBody PlatformDTO mailDTO){
        try {
            mailService.sendSimpleMail(mailDTO);
        } catch (MessagingException e) {
            e.printStackTrace();
            return ReturnDTO.error("err","邮件发送失败");
        }
        return ReturnDTO.ok("success","邮件发送成功");
    }

//    @PostMapping("sendSimpleMail")
//    public Map<String,Object> sendSimpleMail(String mailRecipient,String subject,String content ){
//        HashMap<String, Object> stringObjectHashMap = new HashMap<>();
//        try {
//            mailService.sendSimpleMail(mailRecipient,subject,content);
//        } catch (MessagingException e) {
//            e.printStackTrace();
//            stringObjectHashMap.put("err","邮件发送失败");
//            return stringObjectHashMap;
//        }
//        stringObjectHashMap.put("success","邮件发送成功");
//        return stringObjectHashMap;
//    }
}
