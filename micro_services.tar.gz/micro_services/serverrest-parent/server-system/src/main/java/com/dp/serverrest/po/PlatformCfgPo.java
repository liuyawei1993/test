package com.dp.serverrest.po;

/**
 * @author yuanyubo
 * @date 2019-09-03
 */
public class PlatformCfgPo extends BasePo {
    private Integer id;

    private Boolean cpuStatus;

    private Boolean memoryStatus;

    private Boolean diskStatus;

    private String name;

    private Long timeSetting;

    private Long lockTime;

    private Long timeOut;

    private String emailSend;

    private String smtp;

    private Integer port;

    private String emailPassword;

    private String emailGet;

    private Boolean simpleMode;

    private Boolean certificateEnable;

    private Boolean hdfs;

    private Boolean yarn;

    private Boolean mapreduce2;

    private Boolean tez;

    private Boolean hive;

    private Boolean hbase;

    private Boolean pig;

    private Boolean zookeeper;

    private Boolean storm;

    private Boolean ambarimetrics;

    private Boolean kafka;

    private Boolean spark;

    private Boolean spark2;

    private Boolean zeppelin;

    private Boolean notebook;

    private Boolean elasticsearch;

    private Boolean metron;

    private Boolean slinder;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getCpuStatus() {
        return cpuStatus;
    }

    public void setCpuStatus(Boolean cpuStatus) {
        this.cpuStatus = cpuStatus;
    }

    public Boolean getMemoryStatus() {
        return memoryStatus;
    }

    public void setMemoryStatus(Boolean memoryStatus) {
        this.memoryStatus = memoryStatus;
    }

    public Boolean getDiskStatus() {
        return diskStatus;
    }

    public void setDiskStatus(Boolean diskStatus) {
        this.diskStatus = diskStatus;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Long getTimeSetting() {
        return timeSetting;
    }

    public void setTimeSetting(Long timeSetting) {
        this.timeSetting = timeSetting;
    }

    public Long getLockTime() {
        return lockTime;
    }

    public void setLockTime(Long lockTime) {
        this.lockTime = lockTime;
    }

    public Long getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(Long timeOut) {
        this.timeOut = timeOut;
    }

    public String getEmailSend() {
        return emailSend;
    }

    public void setEmailSend(String emailSend) {
        this.emailSend = emailSend == null ? null : emailSend.trim();
    }

    public String getSmtp() {
        return smtp;
    }

    public void setSmtp(String smtp) {
        this.smtp = smtp == null ? null : smtp.trim();
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getEmailPassword() {
        return emailPassword;
    }

    public void setEmailPassword(String emailPassword) {
        this.emailPassword = emailPassword == null ? null : emailPassword.trim();
    }

    public String getEmailGet() {
        return emailGet;
    }

    public void setEmailGet(String emailGet) {
        this.emailGet = emailGet == null ? null : emailGet.trim();
    }

    public Boolean getSimpleMode() {
        return simpleMode;
    }

    public void setSimpleMode(Boolean simpleMode) {
        this.simpleMode = simpleMode;
    }

    public Boolean getCertificateEnable() {
        return certificateEnable;
    }

    public void setCertificateEnable(Boolean certificateEnable) {
        this.certificateEnable = certificateEnable;
    }

    public Boolean getHdfs() {
        return hdfs;
    }

    public void setHdfs(Boolean hdfs) {
        this.hdfs = hdfs;
    }

    public Boolean getYarn() {
        return yarn;
    }

    public void setYarn(Boolean yarn) {
        this.yarn = yarn;
    }

    public Boolean getMapreduce2() {
        return mapreduce2;
    }

    public void setMapreduce2(Boolean mapreduce2) {
        this.mapreduce2 = mapreduce2;
    }

    public Boolean getTez() {
        return tez;
    }

    public void setTez(Boolean tez) {
        this.tez = tez;
    }

    public Boolean getHive() {
        return hive;
    }

    public void setHive(Boolean hive) {
        this.hive = hive;
    }

    public Boolean getHbase() {
        return hbase;
    }

    public void setHbase(Boolean hbase) {
        this.hbase = hbase;
    }

    public Boolean getPig() {
        return pig;
    }

    public void setPig(Boolean pig) {
        this.pig = pig;
    }

    public Boolean getZookeeper() {
        return zookeeper;
    }

    public void setZookeeper(Boolean zookeeper) {
        this.zookeeper = zookeeper;
    }

    public Boolean getStorm() {
        return storm;
    }

    public void setStorm(Boolean storm) {
        this.storm = storm;
    }

    public Boolean getAmbarimetrics() {
        return ambarimetrics;
    }

    public void setAmbarimetrics(Boolean ambarimetrics) {
        this.ambarimetrics = ambarimetrics;
    }

    public Boolean getKafka() {
        return kafka;
    }

    public void setKafka(Boolean kafka) {
        this.kafka = kafka;
    }

    public Boolean getSpark() {
        return spark;
    }

    public void setSpark(Boolean spark) {
        this.spark = spark;
    }

    public Boolean getSpark2() {
        return spark2;
    }

    public void setSpark2(Boolean spark2) {
        this.spark2 = spark2;
    }

    public Boolean getZeppelin() {
        return zeppelin;
    }

    public void setZeppelin(Boolean zeppelin) {
        this.zeppelin = zeppelin;
    }

    public Boolean getNotebook() {
        return notebook;
    }

    public void setNotebook(Boolean notebook) {
        this.notebook = notebook;
    }

    public Boolean getElasticsearch() {
        return elasticsearch;
    }

    public void setElasticsearch(Boolean elasticsearch) {
        this.elasticsearch = elasticsearch;
    }

    public Boolean getMetron() {
        return metron;
    }

    public void setMetron(Boolean metron) {
        this.metron = metron;
    }

    public Boolean getSlinder() {
        return slinder;
    }

    public void setSlinder(Boolean slinder) {
        this.slinder = slinder;
    }
}