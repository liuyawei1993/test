package com.dp.serverrest.service.impl;

import cn.hutool.core.util.ArrayUtil;
import com.dp.serverrest.dto.PlatformDTO;
import com.dp.serverrest.service.api.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.util.Properties;


/**
 * @className: MailServiceImpl
 * @description: 邮件接口实现
 * @author: yuanyubo
 * @create: 2019-08-26
 */
@Service
public class MailServiceImpl implements MailService {

    @Autowired
    private JavaMailSender mailSender;

    private final String mail="A test mail from DP tech";

    /**
     * 发送简单邮件
     */
    @Override
    public void sendSimpleMail(PlatformDTO platformDTO) throws MessagingException {
        JavaMailSenderImpl jms = new JavaMailSenderImpl();
        jms.setHost(platformDTO.getSMTPMailHost());
        jms.setPort(platformDTO.getMailPort());
        jms.setUsername(platformDTO.getPlatformName());
        jms.setPassword(platformDTO.getMailPass());
        jms.setDefaultEncoding("Utf-8");
        Properties p = new Properties();
        p.setProperty("mail.smtp.auth", "true");
        jms.setJavaMailProperties(p);

        SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
        //发件箱
        simpleMailMessage.setFrom(platformDTO.getMailSender());
        //收件箱
        simpleMailMessage.setTo(platformDTO.getMailUser());
        simpleMailMessage.setSubject(platformDTO.getSubject());
        simpleMailMessage.setText(mail);

        mailSender.send(simpleMailMessage);
    }

    /**
     * 发送HTML邮件
     *
     * @param to      收件人地址
     * @param subject 邮件主题
     * @param content 邮件内容
     * @param cc      抄送地址
     * @throws MessagingException
     */
    @Override
    public void sendHtmlMail(String to, String subject, String content, String... cc) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(content, true);
        if (ArrayUtil.isNotEmpty(cc)) {
            helper.setCc(cc);
        }
        mailSender.send(message);
    }

    @Override
    public void sendAttachmentsMail(String to, String subject, String content, String filePath, String... cc) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();

        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(content, true);
        if (ArrayUtil.isNotEmpty(cc)) {
            helper.setCc(cc);
        }
        FileSystemResource file = new FileSystemResource(new File(filePath));
        String fileName = filePath.substring(filePath.lastIndexOf(File.separator));
        helper.addAttachment(fileName, file);

        mailSender.send(message);
    }

    @Override
    public void sendResourceMail(String to, String subject, String content, String rscPath, String rscId, String... cc) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();

        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(content, true);
        if (ArrayUtil.isNotEmpty(cc)) {
            helper.setCc(cc);
        }
        FileSystemResource res = new FileSystemResource(new File(rscPath));
        helper.addInline(rscId, res);

        mailSender.send(message);
    }
}
