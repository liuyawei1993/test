package com.dp.serverrest.po;

public class RolePo extends BasePo {
    
    private Integer roleId;

    private String roleName;

    private String roleDesc;

    private String rolePermission;

    private Integer userId;

    
    public Integer getRoleId() {
        return roleId;
    }

    
    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    
    public String getRoleName() {
        return roleName;
    }

    
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    
    public String getRoleDesc() {
        return roleDesc;
    }

    
    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public String getRolePermission() {
        return rolePermission;
    }

    public void setRolePermission(String rolePermission) {
        this.rolePermission = rolePermission;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}