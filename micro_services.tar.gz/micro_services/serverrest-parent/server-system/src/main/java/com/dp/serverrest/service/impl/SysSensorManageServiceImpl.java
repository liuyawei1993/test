/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.impl;

import java.util.List;
import java.util.Map;

import com.dp.serverrest.dto.ReturnDTO;
import com.dp.serverrest.service.api.SysSensorManageService;
import com.dp.serverrest.service.util.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dp.serverrest.dao.SensorCfgPoMapper;
import com.dp.serverrest.dao.SensorInterfacePoMapper;
import com.dp.serverrest.dao.SensorManagePoMapper;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.SensorBaseInfoPo;
import com.dp.serverrest.po.SensorCfgPo;
import com.dp.serverrest.po.SensorInterfacePo;
import com.dp.serverrest.po.SensorManagePo;
import com.dp.serverrest.po.SensorStatusInfoPo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月16日 上午10:47:50
 */
@Service
@Transactional(readOnly = false)
public class SysSensorManageServiceImpl implements SysSensorManageService {
    @Autowired
    private SensorManagePoMapper dao;
    @Autowired
    private SensorInterfacePoMapper interfaceDao;
    @Autowired
    private SensorCfgPoMapper cfgDao;

    /**
     * 添加探针的具体实现
     */
    @Override
    public Map<String, String> addSensor(SensorManagePo sensorManage) {
        SensorManagePo sensorManagePo = dao.selectByName(sensorManage.getSensorName());
        if (sensorManagePo!=null){
            return ReturnDTO.error("err","探针名重复");
        }else {
            sensorManage.setCreateTime(TimeUtils.getCurrentTime());
            sensorManage.setStatus("正常");
            return CommonUtils.addData(sensorManage, dao);
        }

    }

    /**
     * 删除探针的具体实现
     */
    @Override
    public Map<String, String> deleteSensor(int id) {
        return CommonUtils.deleteData(id, dao);
    }

    /**
     * 获取探针的基本信息
     */
    @Override
    public SensorBaseInfoPo getSensorBaseInfo(int id) {
        SensorManagePo sensorManageVo = dao.selectByPrimaryKey(id);
        List<SensorInterfacePo> interfaceInfo = interfaceDao.selectBySensorId(id);
        SensorBaseInfoPo sensorBaseInfoVo = new SensorBaseInfoPo();
        SensorBaseInfoPo.HardWareVo hardWareVo = new SensorBaseInfoPo.HardWareVo()
                .setCpuFreq(sensorManageVo.getCpuFreq()).setCpuName(sensorManageVo.getCpuName())
                .setCpuProc(sensorManageVo.getCpuProc()).setMemorySize(sensorManageVo.getMemorySize())
                .setDiskSize(sensorManageVo.getDiskSize());
        sensorBaseInfoVo.setSensorId(sensorManageVo.getSensorId()).setHardWareVo(hardWareVo)
                .setSensorInterfaceList(interfaceInfo).setSensorIp(sensorManageVo.getSensorIp())
                .setSensorName(sensorManageVo.getSensorName()).setStatus(sensorManageVo.getStatus());
        return sensorBaseInfoVo;
    }

    /**
     * 获取探针配置信息的具体实现
     */
    @Override
    public SensorCfgPo getSensorCfgInfo(int id) {
        return cfgDao.selectByPrimaryKey(id);
    }

    /**
     * 获取探针列表的具体实现
     */
    @Override
    public PageInfo<SensorManagePo> getSensorList(int page, int limit) {
        PageHelper.startPage(page, limit);
        return new PageInfo<SensorManagePo>(dao.selectAll());
    }

    /**
     * 获取探针状态的具体实现
     */
    // FIXME
    @Override
    public SensorStatusInfoPo getSensorStatusInfo(int id) {
        return null;
    }

    /**
     * 修改探针的具体实现
     */
    @Override
    public Map<String, String> modifySensor(int id, SensorManagePo sensorManage) {
        sensorManage.setSensorId(id);
        int i = dao.updateByPrimaryKeySelective(sensorManage);
        if (i==0){
            return ReturnDTO.error("err","修改异常");
        }else {
            return ReturnDTO.ok("success","修改成功");
        }
    }

    /**
     * 修改探针配置的实现
     */
    // FIXME
    @Override
    public Map<String, String> modifySensorCfg(int id, Map<Object, Object> sensorCfg) {
        SensorCfgPo sensorCfgVo = new SensorCfgPo();
        return CommonUtils.modifyData(id, sensorCfgVo, cfgDao);
    }

}
