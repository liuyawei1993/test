package com.dp.serverrest.dao;

import com.dp.serverrest.po.SupPlatformPo;

public interface SupPlatformPoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(String supIp);

    
    int insert(SupPlatformPo record);

    
    int insertSelective(SupPlatformPo record);

    
    SupPlatformPo selectByPrimaryKey(String supIp);

    
    int updateByPrimaryKeySelective(SupPlatformPo record);

    
    int updateByPrimaryKey(SupPlatformPo record);
}