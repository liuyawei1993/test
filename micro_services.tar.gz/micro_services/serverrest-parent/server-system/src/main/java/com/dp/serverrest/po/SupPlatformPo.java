package com.dp.serverrest.po;

public class SupPlatformPo extends BasePo {
    
    private String supIp;

    
    private String assetInfo;

    
    private String securityEvent;

    
    private String vulnerableRisk;

    
    public String getSupIp() {
        return supIp;
    }

    
    public void setSupIp(String supIp) {
        this.supIp = supIp;
    }

    
    public String getAssetInfo() {
        return assetInfo;
    }

    
    public void setAssetInfo(String assetInfo) {
        this.assetInfo = assetInfo;
    }

    
    public String getSecurityEvent() {
        return securityEvent;
    }

    
    public void setSecurityEvent(String securityEvent) {
        this.securityEvent = securityEvent;
    }

    
    public String getVulnerableRisk() {
        return vulnerableRisk;
    }

    
    public void setVulnerableRisk(String vulnerableRisk) {
        this.vulnerableRisk = vulnerableRisk;
    }
}