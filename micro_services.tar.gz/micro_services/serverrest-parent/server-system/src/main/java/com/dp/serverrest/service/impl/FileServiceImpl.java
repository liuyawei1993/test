package com.dp.serverrest.service.impl;

import com.dp.serverrest.config.FileConfig;
import com.dp.serverrest.dao.FilePoMapper;
import com.dp.serverrest.po.FilePo;
import com.dp.serverrest.service.api.FileService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @className: FileServiceImpl
 * @description: 文件上传实现类
 * @author: yuanyubo
 * @create: 2019-08-31
 */
@Service
public class FileServiceImpl implements FileService {

    @Autowired
    private FilePoMapper dao;

    /**
     * 新增 文件
     * @param filePo
     * @return
     */
    @Override
    public int save(FilePo filePo) {

        return dao.insert(filePo);
    }

    /**
     * 删除 文件
     * @param id
     * @return
     */
    @Override
    public int remove(Integer id) {
        return dao.deleteByPrimaryKey(id);
    }

    /**
     * 根据ID查询文件信息
     * @param id
     * @return
     */
    @Override
    public FilePo get(Integer id) {
        return dao.selectByPrimaryKey(id);
    }

    /**
     * 分页查询已上传的文件信息
     *
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<FilePo> selectPage(Integer page, Integer limit) {
        PageHelper.startPage(page,limit);
        return new PageInfo<FilePo>(dao.selectAll());
    }
}
