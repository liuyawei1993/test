/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import com.dp.serverrest.service.util.TimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dp.serverrest.dao.PermissionPoMapper;
import com.dp.serverrest.dao.RolePoMapper;
import com.dp.serverrest.dao.SystemLogPoMapper;
import com.dp.serverrest.dao.UserPoMapper;
import com.dp.serverrest.dto.PermissionDTO;
import com.dp.serverrest.po.PermissionPo;
import com.dp.serverrest.po.RolePo;
import com.dp.serverrest.po.UserPo;
import com.dp.serverrest.service.api.LoginService;
import com.google.common.collect.Maps;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月19日 下午4:25:19
 */
@Service
@Transactional(readOnly = false)
public class LoginServiceImpl implements LoginService {
    @Autowired
    private UserPoMapper userDao;
    @Autowired
    private RolePoMapper roleDao;
    @Autowired
    private PermissionPoMapper permissionPoMapper;
    @Autowired
    private SystemLogPoMapper systemLogPoMapper;

    /**
     * 用户登录接口
     *
     * @param userName
     * @param password
     * @return
     */
    @Override
    public Map<String, Object> login(String userName, String password) {
        Map<String, Object> result = Maps.newHashMap();
        try {
            password = Base64.getEncoder().encodeToString(password.getBytes("utf-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        UserPo user = userDao.selectByNameAndPassword(userName, password);
        if (user == null) {
            result.put("isSuccess", false);
        } else {
            //1.根据用户信息获得用户角色
            RolePo role = roleDao.selectByPrimaryKey(user.getRoleId());
            if (role != null) {

                //2.获取角色信息 转换成数组
                String rolePermission = role.getRolePermission();
                JSONArray roleArray = JSONArray.parseArray(rolePermission);
                //3.遍历数组
                //设置顶级菜单的集合
                ArrayList<PermissionDTO> TopPermissionPo = new ArrayList<>();
                //设置二级菜单集合;
                ArrayList<PermissionDTO> TwoPermissionPo = new ArrayList<>();
                //设置三级菜单集合
                ArrayList<PermissionDTO> ThreePermissionPo = new ArrayList<>();

                //4.获取三级菜单集合
                // TODO 查询可优化
                for (int i = 0; i < roleArray.size(); i++) {
                    PermissionDTO permissionDTO = new PermissionDTO();
                    //a.将读取到的元素转换为json对象
                    JSONObject jsonObject = (JSONObject) roleArray.get(i);
                    //b.读取对象中的权限类型和ID
                    Integer perType = (Integer) jsonObject.get("type");
                    Integer id = (Integer) jsonObject.get("id");
                    //c.根据权限ID查询菜单等级
                    PermissionPo permissionPo = permissionPoMapper.selectByPrimaryKey(id);
                    if (permissionPo.getPerLevel() == 1) {
                        permissionDTO.setUrl(permissionPo.getUrl());
                        permissionDTO.setPerLevel(permissionPo.getPerLevel());
                        permissionDTO.setParentId(permissionPo.getParentId());
                        permissionDTO.setName(permissionPo.getPerName());
                        permissionDTO.setIcon(permissionPo.getIcon());
                        permissionDTO.setId(permissionPo.getId());
                        permissionDTO.setPerType(perType);
                        TopPermissionPo.add(permissionDTO);
                    } else if (permissionPo.getPerLevel() == 2) {
                        permissionDTO.setUrl(permissionPo.getUrl());
                        permissionDTO.setPerLevel(permissionPo.getPerLevel());
                        permissionDTO.setParentId(permissionPo.getParentId());
                        permissionDTO.setName(permissionPo.getPerName());
                        permissionDTO.setIcon(permissionPo.getIcon());
                        permissionDTO.setId(permissionPo.getId());
                        permissionDTO.setPerType(perType);
                        TwoPermissionPo.add(permissionDTO);
                    } else if (permissionPo.getPerLevel() == 3) {
                        permissionDTO.setUrl(permissionPo.getUrl());
                        permissionDTO.setPerLevel(permissionPo.getPerLevel());
                        permissionDTO.setParentId(permissionPo.getParentId());
                        permissionDTO.setName(permissionPo.getPerName());
                        permissionDTO.setIcon(permissionPo.getIcon());
                        permissionDTO.setId(permissionPo.getId());
                        permissionDTO.setPerType(perType);
                        ThreePermissionPo.add(permissionDTO);
                    }
                }

                //1.定义返回接收集合
                ArrayList<Object> objects1 = new ArrayList<>();

                //2.遍历顶级菜单
                for (int i = 0; i < TopPermissionPo.size(); i++) {
                    //a.定义接收二级菜单map集合
                    HashMap<String, Object> stringObjectHashMap = new HashMap<>(16);
                    //定义二级菜单返回list集合
                    ArrayList<Object> objects = new ArrayList<>();
                    for (int j = 0; j < TwoPermissionPo.size(); j++) {
                        //b.定义三级菜单接收map集合
                        HashMap<String, Object> stringObjectHashMap2 = new HashMap<>(16);
                        //定义三级菜单返回list集合
                        ArrayList<Object> objects2 = new ArrayList<>();
                        for (int k = 0; k < ThreePermissionPo.size(); k++) {
                            if (ThreePermissionPo.get(k).getParentId().equals(TwoPermissionPo.get(j).getId())) {
                                //c.接收三级菜单列表
                                PermissionDTO permissionDTO = new PermissionDTO();
                                permissionDTO.setId(ThreePermissionPo.get(k).getId());
                                permissionDTO.setIcon(ThreePermissionPo.get(k).getIcon());
                                permissionDTO.setName(ThreePermissionPo.get(k).getName());
                                permissionDTO.setParentId(ThreePermissionPo.get(k).getParentId());
                                permissionDTO.setPerLevel(ThreePermissionPo.get(k).getPerLevel());
                                permissionDTO.setPerType(ThreePermissionPo.get(k).getPerType());
                                permissionDTO.setUrl(ThreePermissionPo.get(k).getUrl());
                                objects2.add(permissionDTO);
                            }
                        }
                        //封装二级返回map
                        stringObjectHashMap2.put("children", objects2);
                        stringObjectHashMap2.put("name", TwoPermissionPo.get(j).getName());
                        stringObjectHashMap2.put("url", TwoPermissionPo.get(j).getUrl());
                        stringObjectHashMap2.put("perType", TwoPermissionPo.get(j).getPerType());
                        stringObjectHashMap2.put("id", TwoPermissionPo.get(j).getId());
                        stringObjectHashMap2.put("perLevel", TwoPermissionPo.get(j).getPerLevel());
                        stringObjectHashMap2.put("icon", TwoPermissionPo.get(j).getIcon());
                        if (TopPermissionPo.get(i).getId().equals(TwoPermissionPo.get(j).getParentId())) {
                            //接收二级菜单列表
                            objects.add(stringObjectHashMap2);
                        }
                    }
                    //封装一级菜单返回map集合
                    stringObjectHashMap.put("children", objects);
                    stringObjectHashMap.put("name", TopPermissionPo.get(i).getName());
                    stringObjectHashMap.put("url", TopPermissionPo.get(i).getUrl());
                    stringObjectHashMap.put("icon", TopPermissionPo.get(i).getIcon());
                    stringObjectHashMap.put("perType", TopPermissionPo.get(i).getPerType());
                    stringObjectHashMap.put("id", TopPermissionPo.get(i).getId());
                    stringObjectHashMap.put("perLevel", TopPermissionPo.get(i).getPerLevel());
                    //封装一级菜单列表
                    objects1.add(stringObjectHashMap);
                }

                //封装数据返回map
                result.put("menu", objects1);
                result.put("isSuccess", true);
                /**
                 * 返回用户信息
                 */
                UserPo userPo = userDao.selectReturnUser(userName);
                result.put("user",userPo);
            } else {
                result.put("isSuccess", false);
            }
        }
        return result;
    }

}
