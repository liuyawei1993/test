/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.api;

import java.util.Map;

import com.dp.serverrest.po.RolePo;
import com.github.pagehelper.PageInfo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月16日 上午9:07:38
 * 
 */

public interface RoleManageService extends BaseService{

    /**
     * 新增权限
     * @param role
     * @return
     */
    public Map<String, String> addRole(RolePo role);

    /**
     * 修改权限
     * @param id
     * @param role
     * @return
     */
    public Map<String, String> modifyRole(int id, RolePo role);

    /**
     * 删除权限
     * @param id
     * @return
     */
    public Map<String, String> deleteRole(int id);

    /**
     * 权限查询
     * @param page
     * @param limit
     * @param userId
     * @return
     */
    public PageInfo<RolePo> getRoleList(int page, int limit,Integer userId);
}
