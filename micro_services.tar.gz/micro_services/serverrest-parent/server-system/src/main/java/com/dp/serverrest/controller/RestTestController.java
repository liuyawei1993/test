package com.dp.serverrest.controller;

import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author chaozhang
 *
 */
@RestController
@RequestMapping(value = "/test")
public class RestTestController {
    private static final Logger log = LoggerFactory.getLogger(RestTestController.class);
    
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    @RequestMapping(value = "test", method = RequestMethod.GET)  
    public String get() {  
	System.err.println();
        return "Hello from get";  
    } 
    
    /*
     * @Scheduled(fixedRate = 5000) public void reportCurrentTime() {
     * log.info("The time is now {}", dateFormat.format(new Date())); }
     */

}
