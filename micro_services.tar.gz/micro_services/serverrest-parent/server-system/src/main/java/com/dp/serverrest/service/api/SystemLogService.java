package com.dp.serverrest.service.api;

import com.dp.serverrest.po.SystemLogPo;
import com.github.pagehelper.PageInfo;

/**
 * @interfaceName: SystemLogService
 * @description: 系统日志查询
 * @author: yuanyubo
 * @create: 2019-08-21
 */
public interface SystemLogService {

    /**
     * 根据时间查询日志信息
     * @param startTime
     * @param endTime
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<SystemLogPo> systemLogByTime(Long startTime, Long endTime, Integer page, Integer limit,Integer userId);

    /**
     * 根据关键字搜索日志信息
     * @param queryStr
     * @param page
     * @param limit
     * @return
     */
    public PageInfo<SystemLogPo> systemLogByQueryStr(String queryStr, Integer page, Integer limit,Integer userId);

    /**
     * 新增 日志
     * @param record
     * @return
     */
    void insert(SystemLogPo record);

    /**
     * 初始化系统日志
     * @param userId
     * @return
     */
    PageInfo systemLogByUserId(Integer page, Integer limit,Integer userId);
}
