/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dp.serverrest.dto.ReturnDTO;
import com.dp.serverrest.service.api.UserManageService;
import com.dp.serverrest.service.util.TimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dp.serverrest.dao.UserPoMapper;
import com.dp.serverrest.service.util.CommonUtils;
import com.dp.serverrest.po.UserPo;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * @author chaozhang
 */
@Service
@Transactional(readOnly = false)
public class UserManageServiceImpl implements UserManageService {
    @Autowired
    private UserPoMapper dao;

    /**
     * 添加用户的具体实现
     */
    @Override
    public Map<String, String> addUser(UserPo user) {

        UserPo userVo = dao.selectByName(user.getUserName());
        if (userVo == null) {
            try {
                user.setUserPassword(Base64.getEncoder().encodeToString(user.getUserPassword().getBytes("utf-8")));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            user.setCreateTime(TimeUtils.getCurrentTime());
            user.setRecentOptTime(TimeUtils.getCurrentTime());
            return CommonUtils.addData(user, dao);
        } else {
            Map<String, String> stringStringMap = new HashMap<>(16);
            stringStringMap.put("err", "用户名重复");
            return stringStringMap;
        }
    }

    /**
     * 删除用户的具体实现
     */
    @Override
    public Map<String, String> deleteUser(int id) {
        return CommonUtils.deleteData(id, dao);
    }

    /**
     * 获取用户列表的具体实现
     */
    @Override
    public List<UserPo> getUserList(int page, int limit) {
        return null;
    }

    /**
     * 分页查询
     *
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<UserPo> getUserPage(int page, int limit,Integer userId) {
        PageHelper.startPage(page, limit);
        return new PageInfo<UserPo>(dao.selectAllById(userId));
    }

    /**
     * 根据id查询用户信息
     *
     * @param userId
     * @return
     */
    @Override
    public UserPo selectById(Integer userId) {
        return dao.selectById(userId);
    }

    /**
     * 修改用户的具体实现
     */
    @Override
    public Map<String, String> modifyUser(int id, UserPo user) {
        //1.判断是否有用户名修改，如果没有，则不判断用户名重复，直接修改用户数据---->不修改用户名
        user.setUserId(id);
        if (user.getUserName() == null) {
            try {
                user.setUserPassword(Base64.getEncoder().encodeToString(user.getUserPassword().getBytes("utf-8")));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            user.setRecentOptTime(TimeUtils.getCurrentTime());
            return CommonUtils.modifyData(id, user, dao);
        }
        //2.如果有用户名修改，则判断是否已存在，并且判断不能为空---->修改用户名
        UserPo userPo = dao.selectByName(user.getUserName());
        if(userPo!=null){
            //判断查询出的数据是否是同一条数据
            if (!userPo.getUserId().equals(user.getUserId())) {
                return ReturnDTO.error("err", "用户名重复");
            } else if (user.getUserName() == "") {
                return ReturnDTO.error("err","用户名不能为空");
            } else {
                try {
                    user.setUserPassword(Base64.getEncoder().encodeToString(user.getUserPassword().getBytes("utf-8")));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                user.setRecentOptTime(TimeUtils.getCurrentTime());
                return CommonUtils.modifyData(id, user, dao);
            }
        }else {
            try {
                user.setUserPassword(Base64.getEncoder().encodeToString(user.getUserPassword().getBytes("utf-8")));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            user.setRecentOptTime(TimeUtils.getCurrentTime());
            return CommonUtils.modifyData(id, user, dao);
        }

    }
}
