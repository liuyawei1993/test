package com.dp.serverrest.dto;

import java.util.List;

/**
 * @className: PageDTO
 * @description: 分页查询返回结果集
 * @author: yuanyubo
 * @create: 2019-08-21
 */
public class PageDTO<T> {

    private Long total;  //查询总数

    private Integer pageNum;  //当前页码

    private Integer pageSize;  //每页数量

    private List<T> tableData;  //返回结果集

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<T> getTableData() {
        return tableData;
    }

    public void setTableData(List<T> tableData) {
        this.tableData = tableData;
    }

    //    public List<T> getData() {
//        return data;
//    }
//
//    public void setData(List<T> data) {
//        this.data = data;
//    }
}
