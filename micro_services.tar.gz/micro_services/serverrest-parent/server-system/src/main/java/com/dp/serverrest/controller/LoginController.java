/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Map;

import com.dp.serverrest.config.aop.Log;
import com.dp.serverrest.po.SystemLogPo;
import com.dp.serverrest.service.api.SystemLogService;
import com.dp.serverrest.service.util.TimeUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.ExcessiveAttemptsException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dp.serverrest.po.UserPo;
import com.dp.serverrest.service.api.LoginService;
import com.google.common.collect.Maps;

import javax.servlet.http.HttpServletRequest;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月19日 下午4:11:18
 */
@RestController
@RequestMapping(value = "/login")
public class LoginController {
    @Autowired
    private LoginService loginService;

    @Autowired
	private SystemLogService systemLogService;

    /*
     * @RequestMapping(value = "/check",method={RequestMethod.GET})
     *
     * @ResponseBody public void check(HttpServletRequest req) { try {
     * HttpServletResponse response = req.getResponse();
     * response.setContentType("application/octet-stream");
     * response.addHeader("Content-Disposition", "attachment;filename=" +
     * "vcode.jpeg"); String number = CommonUtils.getNumber(4);
     * CommonUtils.getImage(response.getOutputStream(), number); } catch (Exception
     * e) {
     *
     * } }
     */

    @Log(value = "用户登录")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> login(@RequestBody UserPo user, HttpServletRequest request) {
        Map<String, Object> result = Maps.newHashMap();
        // 从SecurityUtils里边创建一个 subject
        Subject subject = SecurityUtils.getSubject();
        // 在认证提交前准备 token（令牌）
        UsernamePasswordToken token;
        // 执行登录认证
        try {
            token = new UsernamePasswordToken(user.getUserName(),
                    Base64.getEncoder().encodeToString(user.getUserPassword().getBytes("utf-8")));
            subject.login(token);
            if (subject.isAuthenticated()) {
                result = loginService.login(user.getUserName(), user.getUserPassword());
                result.put("errMessage","登录成功");
                UserPo user1 = (UserPo) result.get("user");
                request.getSession().setAttribute("userId",user1.getUserId());
                result.put("errMessage","登录成功");
			} else {
                token.clear();
                result.put("isSuccess", false);
                result.put("errMessage", "登录失败");
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (UnknownAccountException uae) {
            result.put("isSuccess", false);
            result.put("errMessage", "未知账户");
        } catch (IncorrectCredentialsException ice) {
            result.put("isSuccess", false);
            result.put("errMessage", "密码不正确");
        } catch (LockedAccountException lae) {
            result.put("isSuccess", false);
            result.put("errMessage", "账户已锁定");
        } catch (ExcessiveAttemptsException eae) {
            result.put("isSuccess", false);
            result.put("errMessage", "用户名或密码错误次数过多");
        } catch (AuthenticationException ae) {
            result.put("isSuccess", false);
            result.put("errMessage", "用户名或密码不正确！");
        }
        return result;
    }

    @RequestMapping(value = "logout", method = RequestMethod.DELETE)
    @ResponseBody
    public Map<String, Object> logout() {
        Subject subject = SecurityUtils.getSubject();
        subject.logout();
        Map<String, Object> result = Maps.newHashMap();
        result.put("isLogin", false);
        return result;
    }
}
