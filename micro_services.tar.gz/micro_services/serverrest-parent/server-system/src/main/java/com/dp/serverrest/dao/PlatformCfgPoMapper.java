package com.dp.serverrest.dao;

import com.dp.serverrest.po.PlatformCfgPo;

public interface PlatformCfgPoMapper extends BasePoMapper{
    int deleteByPrimaryKey(Integer id);

    int insert(PlatformCfgPo record);

    int insertSelective(PlatformCfgPo record);

    PlatformCfgPo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(PlatformCfgPo record);

    int updateByPrimaryKey(PlatformCfgPo record);

    PlatformCfgPo selectAll();
}