package com.dp.serverrest.po;

public class SensorUpdateLogPo extends BasePo {
    
    private Integer id;

    
    private String sensorName;

    
    private String version;

    
    private String lastUpdateTime;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getSensorName() {
        return sensorName;
    }

    
    public void setSensorName(String sensorName) {
        this.sensorName = sensorName;
    }

    
    public String getVersion() {
        return version;
    }

    
    public void setVersion(String version) {
        this.version = version;
    }

    
    public String getLastUpdateTime() {
        return lastUpdateTime;
    }

    
    public void setLastUpdateTime(String lastUpdateTime) {
        this.lastUpdateTime = lastUpdateTime;
    }
}