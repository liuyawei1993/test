/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.PermissionPo;
import com.dp.serverrest.service.api.PermissionPoService;
import com.dp.serverrest.service.api.RoleManageService;
import com.dp.serverrest.service.util.PageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.dp.serverrest.po.RolePo;

import javax.servlet.http.HttpServletRequest;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月14日 下午5:59:29 角色管理的restController
 */
@RestController
@RequestMapping(value = "/stap/systemManage/roleManage")
public class RoleManageController {
    private static final Logger log = LoggerFactory.getLogger(RoleManageController.class);
    @Autowired
    private RoleManageService roleManageService;

    @Autowired
    private PermissionPoService permissionPoService;


    /**
     * @param role 角色 添加角色的接口
     * @return
     */
    @RequestMapping(value = "role", method = RequestMethod.POST)
    public Map<String, String> addRole(@RequestBody RolePo role,HttpServletRequest request) {
        Integer userId = (Integer) request.getSession().getAttribute("userId");
        role.setUserId(userId);
        return roleManageService.addRole(role);
    }

    /**
     * @param role 角色 修改角色的接口
     * @return
     */
    @RequestMapping(value = "role/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyRole(@PathVariable("id") Integer id, @RequestBody RolePo role) {
        return roleManageService.modifyRole(id, role);
    }

    /**
     * @param id 删除角色的接口
     * @return
     */
    @RequestMapping(value = "role/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deleteRole(@PathVariable("id") Integer id) {
        return roleManageService.deleteRole(id);
    }

    /**
     * @param page
     * @param limit 获取角色列表的接口 分页查询
     * @return
     */
    @RequestMapping(value = "role", method = RequestMethod.GET)
    public PageDTO<RolePo> getroleVoList(@RequestParam("page") Integer page,
                                         @RequestParam("limit") Integer limit,
                                         HttpServletRequest request) {
        PageUtils<RolePo> roleVoPageUtils = new PageUtils<>();
        Integer userId = (Integer) request.getSession().getAttribute("userId");
        PageDTO<RolePo> roleVoPageDTO = roleVoPageUtils.pageUtil(roleManageService.getRoleList(page, limit,userId));

        return roleVoPageDTO;
    }


    /**
     * 返回所有菜单权限列表
     *
     * @return
     */
    @GetMapping("/permission")
    public HashMap<String, Object> getPermission() {
        return permissionPoService.selectAll();
    }

}
