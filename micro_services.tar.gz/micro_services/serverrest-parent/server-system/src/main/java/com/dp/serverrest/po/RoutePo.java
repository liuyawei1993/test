package com.dp.serverrest.po;

public class RoutePo extends BasePo {
    private String ip;
    private String subMask;

    public String getSubMask() {
        return subMask;
    }

    public void setSubMask(String subMask) {
        this.subMask = subMask;
    }

    private String gateway;
    private String devName;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getGateway() {
        return gateway;
    }

    public void setGateway(String gateway) {
        this.gateway = gateway;
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

}