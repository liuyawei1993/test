/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.config;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.Filter;

import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年9月4日 下午8:27:08
 * 
 */

@Configuration
public class ShiroConfig {

    /**
     * 认证方法
     * 
     * @return
     */
    @Bean
    public CustomRealm customRealm() {
	CustomRealm customRealm = new CustomRealm();
	return customRealm;
    }

    /**
     * @return
     */
    @Bean
    public SecurityManager securityManager() {
	DefaultWebSecurityManager defaultSecurityManager = new DefaultWebSecurityManager();
	defaultSecurityManager.setRealm(customRealm());
	defaultSecurityManager.setSessionManager(sessionManager());
	return defaultSecurityManager;
    }

    /**
     * 全局超时时间的设定
     * 
     * @return
     */
    @Bean(name = "sessionManager")
    public DefaultWebSessionManager sessionManager() {
    	DefaultWebSessionManager sessionManager = new DefaultWebSessionManager();
    	// 设置session过期时间3600s
	sessionManager.setGlobalSessionTimeout(3600000L);
    	return sessionManager;
    }

    /**
     * 全局的筛选器
     * 
     * @param securityManager
     * @return
     */
    @Bean(name = "shiroFilter")
    public ShiroFilterFactoryBean shiroFilter(SecurityManager securityManager) {
	ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
	Map<String, Filter> filters = shiroFilterFactoryBean.getFilters();
	filters.put("myauthc", new MyAuthenticationFilter());
	shiroFilterFactoryBean.setSecurityManager(securityManager);
	shiroFilterFactoryBean.setUnauthorizedUrl("/notRole");
	Map<String, String> filterChainDefinitionMap = new LinkedHashMap<>();
	// <!-- authc:所有url都必须认证通过才可以访问; anon:所有url都都可以匿名访问-->
	// 主要这行代码必须放在所有权限设置的最后，不然会导致所有 url 都被拦截 剩余的都需要认证
	filterChainDefinitionMap.put("/login/**", "anon");
	filterChainDefinitionMap.put("/**", "myauthc");
	shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
	return shiroFilterFactoryBean;

    }
}
