/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.util.HashMap;
import java.util.Map;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.service.api.PolicyManageService;
import com.dp.serverrest.service.util.PageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dp.serverrest.po.SensorPolicyPo;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月15日 上午10:41:51
 */
@RestController
@RequestMapping(value = "/stap/systemManage/policyManage")
public class PolicyManageController {
    private static final Logger log = LoggerFactory.getLogger(PolicyManageController.class);
    @Autowired
    private PolicyManageService policyManageService;
    //======================策略管理==========================
    /**
     * @param policy 添加策略
     * @return
     */
    @RequestMapping(value = "policy", method = RequestMethod.POST)
    public Map<String, String> addPolicy(@RequestBody SensorPolicyPo policy) {
        return policyManageService.addPolicy(policy);
    }

    /**
     * @param policy 配置的下发
     * @return
     */
    //FIXME暂无具体实现
    @RequestMapping(value = "policyApply/{id}", method = RequestMethod.POST)
    public Map<String, String> applyPolicy(@PathVariable("id") Integer id) {
        return null;
    }

    /**
     * @param id 策略删除
     * @return
     */
    @RequestMapping(value = "policy/{id}", method = RequestMethod.DELETE)
    public Map<String, String> deletePolicy(@PathVariable("id") Integer id) {
        return policyManageService.deletePolicy(id);
    }

    /**
     *
     * @param page 页码数
     * @param limit 每页数据
     * @return
     */
    @RequestMapping(value = "policy", method = RequestMethod.GET)
    public PageDTO<SensorPolicyPo> getPolicyList(@RequestParam("page") Integer page, @RequestParam("limit") Integer limit) {

        //使用分页工具类处理查询到的结果集，封装成前端需要的数据
        PageUtils<SensorPolicyPo> sensorPolicyVoPageUtils = new PageUtils<>();
        PageDTO<SensorPolicyPo> sensorPolicyVoPageDTO = sensorPolicyVoPageUtils.pageUtil(policyManageService.getPolicyByPage(page, limit));

        return sensorPolicyVoPageDTO;
    }

    /**
     * 修改策略配置
     * @param id
     * @param policy
     * @return
     */
    @RequestMapping(value = "policy/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyPolicy(@PathVariable("id") Integer id, @RequestBody SensorPolicyPo policy) {
        return policyManageService.modifyPolicy(id, policy);
    }

    /**
     * @param id
     * @param time 探针时间同步
     * @return
     */
    // FIXME
    @RequestMapping(value = "synTime/{id}", method = RequestMethod.POST)
    public Map<String, String> syncTime(@PathVariable("id") Integer id, @RequestBody HashMap<Object, Object> time) {
        Integer timeStamp = (Integer) time.get("time");
        return null;
    }
}
