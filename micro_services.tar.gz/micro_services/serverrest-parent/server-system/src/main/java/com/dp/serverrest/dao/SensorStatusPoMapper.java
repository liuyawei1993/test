package com.dp.serverrest.dao;

import com.dp.serverrest.po.SensorStatusPo;

public interface SensorStatusPoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer id);

    
    int insert(SensorStatusPo record);

    
    int insertSelective(SensorStatusPo record);

    
    SensorStatusPo selectByPrimaryKey(Integer id);

    
    int updateByPrimaryKeySelective(SensorStatusPo record);

    
    int updateByPrimaryKey(SensorStatusPo record);
}