package com.dp.serverrest.dao;

import com.dp.serverrest.po.VersionLogPo;

import java.util.List;

public interface VersionLogPoMapper extends BasePoMapper {
    
    int deleteByPrimaryKey(Integer id);

    
    int insert(VersionLogPo record);

    
    int insertSelective(VersionLogPo record);

    
    VersionLogPo selectByPrimaryKey(Integer id);

    List<VersionLogPo> selectVersionLogVo();
    List<VersionLogPo> selectAll();

    
    int updateByPrimaryKeySelective(VersionLogPo record);

    
    int updateByPrimaryKey(VersionLogPo record);
}