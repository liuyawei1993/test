package com.dp.serverrest.po;

public class IpWhitelistPo extends BasePo {
    private Integer id;

    private String url;

    private Long createTime;

    private String attackOperation;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public String getAttackOperation() {
        return attackOperation;
    }

    public void setAttackOperation(String attackOperation) {
        this.attackOperation = attackOperation == null ? null : attackOperation.trim();
    }
}