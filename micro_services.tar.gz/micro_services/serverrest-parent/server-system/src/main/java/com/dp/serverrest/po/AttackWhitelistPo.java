package com.dp.serverrest.po;

/**
 * @apiNote 攻击白名单
 * @author yuanyubo
 */
public class AttackWhitelistPo extends BasePo {
    private Integer id;

    private String attackType;

    private Long createTime;

    private String attackName;

    private String attackLevel;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAttackType() {
        return attackType;
    }

    public void setAttackType(String attackType) {
        this.attackType = attackType == null ? null : attackType.trim();
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public String getAttackName() {
        return attackName;
    }

    public void setAttackName(String attackName) {
        this.attackName = attackName == null ? null : attackName.trim();
    }

    public String getAttackLevel() {
        return attackLevel;
    }

    public void setAttackLevel(String attackLevel) {
        this.attackLevel = attackLevel;
    }
}