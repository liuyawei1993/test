package com.dp.serverrest.po;

public class AlarmPo extends BasePo {
    
    private Integer id;

    
    private String name;

    
    private String type;

    
    private String alarmMode;

    
    private String reciver;

    
    private Boolean status;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public String getName() {
        return name;
    }

    
    public void setName(String name) {
        this.name = name;
    }

    
    public String getType() {
        return type;
    }

    
    public void setType(String type) {
        this.type = type;
    }

    
    public String getAlarmMode() {
        return alarmMode;
    }

    
    public void setAlarmMode(String alarmMode) {
        this.alarmMode = alarmMode;
    }

    
    public String getReciver() {
        return reciver;
    }

    
    public void setReciver(String reciver) {
        this.reciver = reciver;
    }

    
    public Boolean getStatus() {
        return status;
    }

    
    public void setStatus(Boolean status) {
        this.status = status;
    }
}