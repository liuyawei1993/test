package com.dp.serverrest.service.api;

import com.dp.serverrest.po.PermissionPo;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;

/**
 * @interfaceName: PermissionPoService
 * @description: 权限菜单接口
 * @author: yuanyubo
 * @create: 2019-09-04
 */
public interface PermissionPoService {

    /**
     * 获取 全部的菜单权限
     * @return
     */
    HashMap<String,Object> selectAll();

}
