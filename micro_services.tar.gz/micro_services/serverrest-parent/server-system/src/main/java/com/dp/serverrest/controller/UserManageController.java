/*
 * Copyright (c) 2018 DPtech, Inc. and others. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 */
package com.dp.serverrest.controller;

import java.util.List;
import java.util.Map;

import com.dp.serverrest.dto.PageDTO;
import com.dp.serverrest.po.PermissionPo;
import com.dp.serverrest.service.api.PermissionPoService;
import com.dp.serverrest.service.api.UserManageService;
import com.dp.serverrest.service.util.PageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.dp.serverrest.po.UserPo;

import javax.servlet.http.HttpServletRequest;

/**
 * @author author zhangchao:
 * @version 创建时间：2019年8月14日 下午5:59:29
 * 用户管理的restController
 */
@RestController
@RequestMapping(value = "/stap/systemManage/userManage")
public class UserManageController {
    private static final Logger log = LoggerFactory.getLogger(UserManageController.class);
    @Autowired
    private UserManageService userManageService;

    /**
     * @param user 用户对象
     *             添加用户的接口
     * @return
     */
    @RequestMapping(value = "user", method = RequestMethod.POST)
    public Map<String, String> addUser(@RequestBody UserPo user, HttpServletRequest request) {
        //从session中获取当前用户ID，放入新添加用的创建者ID中
        Integer userId = (Integer) request.getSession().getAttribute("userId");
        user.setCreateUserId(userId);
        return userManageService.addUser(user);
    }

    /**
     * @param id
     * @param user 修改用户信息的接口
     * @return
     */
    @RequestMapping(value = "user/{id}", method = RequestMethod.PUT)
    public Map<String, String> modifyUser(@PathVariable("id") Integer id, @RequestBody UserPo user) {
        return userManageService.modifyUser(id, user);
    }

    /**
     * @param id 删除用户信息的接口
     * @return
     */
    @RequestMapping(value = "user/{userId}", method = RequestMethod.DELETE)
    public Map<String, String> deleteUser(@PathVariable("userId") Integer id) {
        return userManageService.deleteUser(id);
    }

    /**
     * @param page
     * @param limit 获取用户列表的接口 分页查询
     * @return
     */
    @RequestMapping(value = "user", method = RequestMethod.GET)
    public PageDTO<UserPo> getUserList(@RequestParam("page") Integer page,
                                       @RequestParam("limit") Integer limit,
                                       HttpServletRequest request) {
        Integer userId = (Integer) request.getSession().getAttribute("userId");
        //使用分页工具类处理查询到的结果集，封装成前端需要的数据
        PageUtils<UserPo> userVoPageUtils = new PageUtils<>();
        PageDTO<UserPo> userVoPageDTO = userVoPageUtils.pageUtil(userManageService.getUserPage(page, limit,userId));

        return userVoPageDTO;
    }

}
