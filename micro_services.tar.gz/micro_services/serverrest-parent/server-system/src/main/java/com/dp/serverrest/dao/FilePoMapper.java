package com.dp.serverrest.dao;

import com.dp.serverrest.po.FilePo;

import java.util.List;

/**
 * @interfaceName: FilePoMapper
 * @description: 文件上传dao接口
 * @author: yuanyubo
 * @create: 2019-08-31
 */
public interface FilePoMapper {

    /**
     * 根据文件ID删除文件
     *
     * @param fileId
     * @return
     */
    int deleteByPrimaryKey(Integer fileId);

    /**
     * 新增 文件
     *
     * @param record
     * @return
     */
    int insert(FilePo record);

    /**
     * 新增 字段不为空 文件
     *
     * @param record
     * @return
     */
    int insertSelective(FilePo record);

    /**
     * 根据主键 查询文件信息
     *
     * @param fileId
     * @return
     */
    FilePo selectByPrimaryKey(Integer fileId);

    /**
     * 根据主键 更新字段不为空的文件信息
     *
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(FilePo record);

    /**
     * 根据主键 更新全部字段
     *
     * @param record
     * @return
     */
    int updateByPrimaryKey(FilePo record);

    /**
     * 查询全部已上传文件信息
     *
     * @return
     */
    List<FilePo> selectAll();

}
