package com.dp.serverrest.service.impl;


import com.dp.serverrest.dao.SystemLogPoMapper;
import com.dp.serverrest.service.api.SystemLogService;
import com.dp.serverrest.po.SystemLogPo;
import com.dp.serverrest.service.util.TimeUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @className: SystemLogServiceImpl
 * @description: 日志查询
 * @author: yuanyubo
 * @create: 2019-08-21
 */
@Service
public class SystemLogServiceImpl implements SystemLogService {

    @Autowired
    private SystemLogPoMapper dao;

    /**
     * 根据时间段进行分页查询
     * @param startTime
     * @param endTime
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<SystemLogPo> systemLogByTime(Long startTime, Long endTime, Integer page, Integer limit,Integer userId) {
        PageHelper.startPage(page,limit);
        return new PageInfo<SystemLogPo>(dao.selectByTime(startTime,endTime,userId));
    }

    /**
     * 根据关键字进行分页查询
     * @param queryStr
     * @param page
     * @param limit
     * @return
     */
    @Override
    public PageInfo<SystemLogPo> systemLogByQueryStr(String queryStr, Integer page, Integer limit,Integer userId) {
        PageHelper.startPage(page,limit);
        return new PageInfo<SystemLogPo>(dao.selectByString(queryStr,userId));
    }

    /**
     * 新增 日志
     *
     * @param record
     * @return
     */
    @Override
    public void insert(SystemLogPo record) {
        record.setOptTime(TimeUtils.getCurrentTime());
        dao.insert(record);
    }

    /**
     * 初始化系统日志
     *
     * @param userId
     * @return
     */
    @Override
    public PageInfo<SystemLogPo> systemLogByUserId(Integer page, Integer limit,Integer userId) {
        PageHelper.startPage(page,limit);
        return new PageInfo<SystemLogPo>(dao.selectAllByUserId(userId));
    }
}
