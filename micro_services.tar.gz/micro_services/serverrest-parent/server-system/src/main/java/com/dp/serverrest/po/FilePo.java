package com.dp.serverrest.po;

/**
 * @className: FilePo
 * @description: 文件上传实体类
 * @author: yuanyubo
 * @create: 2019-08-31
 */
public class FilePo {

    private Integer fileId;

    private Integer fileType;

    private String fileUrl;

    private Long createTime;

    public Integer getFileId() {
        return fileId;
    }

    public void setFileId(Integer fileId) {
        this.fileId = fileId;
    }

    public Integer getFileType() {
        return fileType;
    }

    public void setFileType(Integer fileType) {
        this.fileType = fileType;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl == null ? null : fileUrl.trim();
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

    public FilePo() {
        super();
    }

    public FilePo(Integer fileType, String fileUrl, Long createTime) {
        super();
        this.fileType = fileType;
        this.fileUrl = fileUrl;
        this.createTime = createTime;
    }
}
