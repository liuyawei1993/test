package com.dp.serverrest.po;

public class SensorStatusPo extends BasePo {
    
    private Integer id;

    
    private Integer SensorId;

    
    private Long timeStamp;

    
    private Double cpuUsage;

    
    private Double memoryUsage;

    
    private Double diskUsage;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public Integer getSensorId() {
        return SensorId;
    }

    
    public void setSensorId(Integer SensorId) {
        this.SensorId = SensorId;
    }

    
    public Long getTimeStamp() {
        return timeStamp;
    }

    
    public void setTimeStamp(Long timeStamp) {
        this.timeStamp = timeStamp;
    }

    
    public Double getCpuUsage() {
        return cpuUsage;
    }

    
    public void setCpuUsage(Double cpuUsage) {
        this.cpuUsage = cpuUsage;
    }

    
    public Double getMemoryUsage() {
        return memoryUsage;
    }

    
    public void setMemoryUsage(Double memoryUsage) {
        this.memoryUsage = memoryUsage;
    }

    
    public Double getDiskUsage() {
        return diskUsage;
    }

    
    public void setDiskUsage(Double diskUsage) {
        this.diskUsage = diskUsage;
    }
}