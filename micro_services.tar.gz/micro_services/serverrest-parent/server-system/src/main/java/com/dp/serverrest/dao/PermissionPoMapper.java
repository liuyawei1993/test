package com.dp.serverrest.dao;

import com.dp.serverrest.po.PermissionPo;

import java.util.List;

public interface PermissionPoMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(PermissionPo record);

    int insertSelective(PermissionPo record);

    PermissionPo selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(PermissionPo record);

    int updateByPrimaryKey(PermissionPo record);

    List<PermissionPo> selectAll();

    List<PermissionPo> selectOneAll();
    List<PermissionPo> selectTowAll();
    List<PermissionPo> selectThreeAll();

}