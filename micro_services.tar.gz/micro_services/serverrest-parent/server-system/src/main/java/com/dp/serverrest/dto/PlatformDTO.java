package com.dp.serverrest.dto;

/**
 * @className: PlatformDTO
 * @description: 平台管理DTO
 * @author: yuanyubo
 * @create: 2019-09-09
 */
public class PlatformDTO<T> {

    /**
     * 平台名称
     */
    private String platformName;
    /**
     * 平台时间设置
     */
    private Long time;
    /**
     * 用户锁定时间
     */
    private Long lockTime;
    /**
     * 用户锁定时间
     */
    private Long timeout;
    /**
     * 发件邮箱
     */
    private String mailSender;
    /**
     * 邮件标题
     */
    private String subject;
    /**
     * 邮件内容
     */
    private T data;
    /**
     * smtp服务器
     */
    private String SMTPMailHost;
    /**
     * smtp服务端口
     */
    private Integer mailPort;
    /**
     * 授权码
     */
    private String mailPass;
    /**
     * 收件人
     */
    private String mailUser;

    @Override
    public String toString() {
        return "MailDTO{" +
                "platformName='" + platformName + '\'' +
                ", time=" + time +
                ", lockTime=" + lockTime +
                ", timeout=" + timeout +
                ", mailSender='" + mailSender + '\'' +
//                ", inbox='" + inbox + '\'' +
                ", subject='" + subject + '\'' +
                ", data=" + data +
                ", SMTPMailHost='" + SMTPMailHost + '\'' +
                ", mailPort=" + mailPort +
                ", mailPass='" + mailPass + '\'' +
                ", mailUser='" + mailUser + '\'' +
                '}';
    }

    public String getPlatformName() {
        return platformName;
    }

    public void setPlatformName(String platformName) {
        this.platformName = platformName;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getLockTime() {
        return lockTime;
    }

    public void setLockTime(Long lockTime) {
        this.lockTime = lockTime;
    }

    public Long getTimeout() {
        return timeout;
    }

    public void setTimeout(Long timeout) {
        this.timeout = timeout;
    }

    public String getMailSender() {
        return mailSender;
    }

    public void setMailSender(String mailSender) {
        this.mailSender = mailSender;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getSMTPMailHost() {
        return SMTPMailHost;
    }

    public void setSMTPMailHost(String SMTPMailHost) {
        this.SMTPMailHost = SMTPMailHost;
    }

    public Integer getMailPort() {
        return mailPort;
    }

    public void setMailPort(Integer mailPort) {
        this.mailPort = mailPort;
    }

    public String getMailPass() {
        return mailPass;
    }

    public void setMailPass(String mailPass) {
        this.mailPass = mailPass;
    }

    public String getMailUser() {
        return mailUser;
    }

    public void setMailUser(String mailUser) {
        this.mailUser = mailUser;
    }
}
