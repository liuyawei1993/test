package com.dp.serverrest.po;

public class SystemLogPo extends BasePo {
    
    private Integer id;

    
    private Long optTime;

    
    private String userName;

    
    private String opt;

    
    private String result;

    
    private String message;

    private Integer userId;

    
    public Integer getId() {
        return id;
    }

    
    public void setId(Integer id) {
        this.id = id;
    }

    
    public Long getOptTime() {
        return optTime;
    }

    
    public void setOptTime(Long optTime) {
        this.optTime = optTime;
    }

    
    public String getUserName() {
        return userName;
    }

    
    public void setUserName(String userName) {
        this.userName = userName;
    }

    
    public String getOpt() {
        return opt;
    }

    
    public void setOpt(String opt) {
        this.opt = opt;
    }

    
    public String getResult() {
        return result;
    }

    
    public void setResult(String result) {
        this.result = result;
    }

    
    public String getMessage() {
        return message;
    }

    
    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}