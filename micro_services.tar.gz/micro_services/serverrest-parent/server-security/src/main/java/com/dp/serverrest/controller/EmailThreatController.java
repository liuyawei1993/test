package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @className: EmailThreatController
 * @description:
 * @author: fanxiaopan
 * @create: 2019-09-11
 */
@RestController
@RequestMapping("/stap/securityEvent/emailThreat")
public class EmailThreatController {

    /**
     * 邮件威胁- 列表
     *
     * @param limit
     * @param page
     * @return
     */
    @GetMapping("/list")
    public Map<String, String> getEmailThreatList(Integer limit, Integer page) {
        return null;
    }

    /**
     * 邮件威胁- 图表
     *
     * @return
     */
    @GetMapping("/chart")
    public Map<String, String> getEmailThreatChart() {
        return null;
    }
}
