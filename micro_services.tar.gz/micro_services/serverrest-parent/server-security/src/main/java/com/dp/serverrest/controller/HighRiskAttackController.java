package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @className: HighRiskAttackController
 * @description: 高危攻击接口
 * @author: fanxiaopan
 * @create: 2019-09-11
 */
@RestController
@RequestMapping("/stap/securityEvent/highRiskAttack")
public class HighRiskAttackController {

    /**
     * 高危攻击 - 事件列表 （一级菜单）
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/list")
    public Map<String, String> getHighRiskAttackList(Integer page, Integer limit) {
        return null;
    }

    /**
     * 日志列表-详细信息（原始攻击日志）
     *
     * @param id
     * @return
     */
    @GetMapping("/detailedInformation/log/{id}")
    public Map<String, String> getLogList(@PathVariable("id") Integer id) {
        return null;
    }

    /**
     * 高危攻击-图表（一级菜单）
     *
     * @return
     */
    @GetMapping("/chart")
    public Map<String, String> getHighRiskAttackChart() {
        return null;
    }

    /**
     * 详细信息-攻击日志
     *
     * @param page
     * @param limit
     * @param initiatorIp
     * @param victimIp
     * @return
     */
    @GetMapping("/detailedInformation/list")
    public Map<String, String> getDetailedInformationToList(Integer page, Integer limit, String initiatorIp, String victimIp) {
        return null;
    }

    /**
     * 攻击详情- 详细信息 图表
     *
     * @param initiatorIp
     * @param victimIp
     * @return
     */
    @GetMapping("/detailedInformation/chart")
    public Map<String, String> getDetailInformationToChart(String initiatorIp, String victimIp) {
        return null;
    }


}
