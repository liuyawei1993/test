package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

/**
 * @className: HighRiskVulController
 * @description: 高危漏洞controller
 * @author: yuanyubo
 * @create: 2019-09-11
 */
@RestController
@RequestMapping("/stap/securityEvent/highRiskVul")
public class HighRiskVulController {

    /**
     * 漏洞列表
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/list")
    public HashMap<String, Object> highRiskVulList(@RequestParam("page") Integer page,
                                                   @RequestParam("limit") Integer limit) {
        return null;
    }

    /**
     * 数据汇总
     *
     * @return
     */
    @GetMapping("/chart")
    public HashMap<String, Object> highRiskVulChart() {
        return null;
    }

}
