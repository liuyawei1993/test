package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @className: GeneralViewController
 * @description: 概览
 * @author: fanxiaopan
 * @create: 2019-09-11
 */
@RestController
@RequestMapping("/stap/overview")
public class GeneralViewController {

    /**
     * 威胁概览
     *
     * @return
     */
    @GetMapping("/threat")
    public Map<String, String> getThreatOverview() {
        return null;
    }

    /**
     * 资产状态概览
     *
     * @return
     */
    @GetMapping("/asset/list")
    public Map<String, String> getAssetStatusOverview() {
        return null;
    }

    /**
     * 平台状态概览
     *
     * @return
     */
    @GetMapping("/platform/status")
    public Map<String, String> getPlatformStatusOverview() {
        return null;
    }

    /**
     * 查询某探针CPU、内存、硬盘的使用率
     *
     * @param id
     * @return
     */
    @GetMapping("/sensor/{id}")
    public Map<String, String> selectUsageOfSensor(@PathVariable("id") Integer id) {
        return null;
    }

    /**
     * 探针状态
     *
     * @return
     */
    @GetMapping("/sensor/status")
    public Map<String, String> getSensorStatus() {
        return null;
    }


}
