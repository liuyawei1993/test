package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @className: MaliciousFileController
 * @description: 恶意文件 接口
 * @author: fanxiaopan
 * @create: 2019-09-11
 */
@RestController
@RequestMapping("/stap/securityEvent/maliciousFile")
public class MaliciousFileController {

    /**
     * 恶意文件- 列表
     *
     * @param limit
     * @param page
     * @return
     */
    @GetMapping("/list")
    public Map<String, String> getMaliciousFileList(Integer limit, Integer page) {
        return null;
    }

    /**
     * 恶意文件 - 数据汇总
     *
     * @return
     */
    @GetMapping("/chart")
    public Map<String, String> getMaliciousFileChart() {
        return null;
    }

}
