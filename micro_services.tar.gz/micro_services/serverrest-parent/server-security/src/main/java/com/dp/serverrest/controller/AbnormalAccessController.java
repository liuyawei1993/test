package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

/**
 * @className: AbnormalAccessController
 * @description: 异常访问controller
 * @author: yuanyubo
 * @create: 2019-09-11
 */
@RestController
@RequestMapping("/stap/securityEvent/abnormalAccess")
public class AbnormalAccessController {

    /**
     * 数据汇总
     *
     * @return
     */
    @RequestMapping("/chart")
    public HashMap<String, Object> abnormalAccessChart() {
        return null;
    }

    /**
     * 事件列表
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/list")
    public HashMap<String, Object> abnormalAccessList(@RequestParam("page") Integer page,
                                                      @RequestParam("limit") Integer limit) {
        return null;
    }

}
