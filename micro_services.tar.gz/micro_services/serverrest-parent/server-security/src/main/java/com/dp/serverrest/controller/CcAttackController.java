package com.dp.serverrest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * @className: CCAttackController
 * @description: CC 攻击接口
 * @author: fanxiaopan
 * @create: 2019-09-11
 */
@RestController
@RequestMapping("/stap/securityEvent/CCAttack")
public class CcAttackController {

    /**
     * CC 攻击列表
     *
     * @param page
     * @param limit
     * @return
     */
    @GetMapping("/list")
    public Map<String, String> getCCAttackList(Integer page, Integer limit) {
        return null;
    }

    /**
     * CC 攻击- 数据汇总
     *
     * @return
     */
    @GetMapping("/chart")
    public Map<String, String> getCCAttackChart() {
        return null;
    }

}
