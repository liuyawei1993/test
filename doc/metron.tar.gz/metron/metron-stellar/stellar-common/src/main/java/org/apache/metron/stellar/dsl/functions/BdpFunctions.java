/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license
 * agreements.  See the NOTICE file distributed with this work for additional information regarding
 * copyright ownership.  The ASF licenses this file to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the License.  You may obtain
 * a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package org.apache.metron.stellar.dsl.functions;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.metron.stellar.dsl.BaseStellarFunction;
import org.apache.metron.stellar.dsl.Stellar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class BdpFunctions {
  private static final Logger LOG = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

  @Stellar(name="IP_EXCHANGE"
  		,namespace="BDP_FUNC"
  		,description="IP exchange by attackid. "
  				+ "If the mantissa of attackid is odd number, ip and port of src and dst exchange."
  		,params = {
		  			"attackid - attack id"
		  			,"srcip - source ip"
		  			,"dstip - destination ip"
		  			,"srcip_port - port of source ip"
		  			,"dstip_port - port of destination ip"
  		}
  		,returns = "A Map include fields(\"srcip\" and \"dstip\"). NULL(ERROR) otherwise."
  )
  public static class BdpFuncIpExchange extends BaseStellarFunction {

    @Override
    public Object apply(List<Object> objects) {
    	Object attackid = objects.get(0);
    	Object srcip = objects.get(1);
    	Object dstip = objects.get(2);
    	Object srcip_port = objects.get(3);
    	Object dstip_port = objects.get(4);
    	if (5 != objects.size() || null == attackid || null == srcip_port || null == dstip_port || 
    			false == (srcip instanceof String) || false == (dstip instanceof String)) {
    		LOG.error("BDP_FUNC_IP_EXCHANGE received more or less arguments than expected.");
    		return null;
    	}

    	Integer number = Integer.parseInt(attackid.toString());//forced to become Integer
    	Map<String, Object> ret = new HashMap<String, Object>();
    	if (1 == (number % 2)) {//odd
    		ret.put("srcip", dstip);
        	ret.put("dstip", srcip);
        	ret.put("srcip_port", dstip_port);
        	ret.put("dstip_port", srcip_port);
    	} else {//even
    		ret.put("srcip", srcip);
        	ret.put("dstip", dstip);
        	ret.put("srcip_port", srcip_port);
        	ret.put("dstip_port", dstip_port);
    	}
  
      return ret;
    }
  }
}
