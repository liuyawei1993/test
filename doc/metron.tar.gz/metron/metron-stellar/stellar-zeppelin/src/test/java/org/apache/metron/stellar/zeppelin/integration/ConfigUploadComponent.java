/*
 *
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.metron.stellar.zeppelin.integration;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.imps.CuratorFrameworkState;
import org.apache.metron.integration.InMemoryComponent;
import org.apache.metron.integration.UnableToStartException;

import java.util.Map;

import static org.apache.metron.common.configuration.ConfigurationsUtils.getClient;
import static org.apache.metron.common.configuration.ConfigurationsUtils.writeGlobalConfigToZookeeper;

/**
 * Uploads configuration to Zookeeper.
 */
public class ConfigUploadComponent implements InMemoryComponent {

  private String zookeeperURL;
  private Map<String, Object> globals;

  @Override
  public void start() throws UnableToStartException {
    try {
      upload();

    } catch (Exception e) {
      throw new UnableToStartException(e.getMessage(), e);
    }
  }

  @Override
  public void stop() {
    // nothing to do
  }

  /**
   * Uploads configuration to Zookeeper.
   * @throws Exception
   */
  private void upload() throws Exception {
    assert zookeeperURL != null;
    try(CuratorFramework client = getClient(zookeeperURL)) {
      if(client.getState() != CuratorFrameworkState.STARTED) {
        client.start();
      }

      if (globals != null) {
        writeGlobalConfigToZookeeper(globals, client);
      }
    }
  }


  public ConfigUploadComponent withZookeeperURL(String zookeeperURL) {
    this.zookeeperURL = zookeeperURL;
    return this;
  }

  public ConfigUploadComponent withGlobals(Map<String, Object> globals) {
    this.globals = globals;
    return this;
  }
}