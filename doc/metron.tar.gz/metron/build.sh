#!/bin/sh
cd `dirname $0`
./clean.sh

cd ../
CurrentPath=`pwd`
echo $CurrentPath

setenforce 0
systemctl stop firewalld
systemctl start docker

echo -e "*****mvn metron*****"
cd metron
#npm cache clean
#rm -rf metron-interface
#svn update
mvn clean package -DskipTests -T 2C -P HDP-2.5.0.0,mpack 

echo *****mvn rpm*****
cd metron-deployment/packaging/docker/rpm-docker
#docker save -o
#docker load -i
#systemctl restart docker
mvn clean install -DskipTests -PHDP-2.5.0.0

echo -e "*****copy tar and rpm*****"
cd ../../../../
git checkout Metron_0.5.0

rm -rf ../platform_install/roles/ambari_server/files/*.tar.gz
cp -rf metron-deployment/packaging/ambari/metron-mpack/target/metron_mpack-0.5.0.0.tar.gz ../platform_install/roles/ambari_server/files/
cp -rf metron-deployment/packaging/ambari/elasticsearch-mpack/target/elasticsearch_mpack-0.5.0.0.tar.gz ../platform_install/roles/ambari_server/files/

rm -rf /var/www/html/metron/centos7/*
mkdir -p /var/www/html/metron/centos7
cp -rf metron-deployment/packaging/docker/rpm-docker/target/RPMS/noarch/* /var/www/html/metron/centos7/

echo -e "*****createrepo*****"
cd /var/www/html
createrepo metron/centos7/
tar zcvf metron.tar.gz metron
mv -f /var/www/html/metron.tar.gz ${CurrentPath}/platform_install/roles/repo_server/files/

echo -e "*****clean*****"
cd ${CurrentPath}/metron
./clean.sh
