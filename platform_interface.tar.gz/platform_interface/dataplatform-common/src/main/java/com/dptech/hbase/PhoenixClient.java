package com.dptech.hbase;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;

import java.sql.SQLException;

/**
 * @author jelly * @date 2019-09-08 20:38
 * @ClassName: PhoenixClient
 * @Description: TODO
 */
public final class PhoenixClient {

    private DruidDataSource druidDataSource;

    public PhoenixClient(String url) {
        druidDataSource = new PhoenixDataSourece(url).getDataSource();
    }

    public PhoenixClient(String url, String password) {
        druidDataSource = new PhoenixDataSourece(url, password).getDataSource();
    }

    /**
     * @param sqlString
     * @param param
     * @return
     * @throws SQLException
     */
    public int exec(String sqlString, Object... param) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        return runner.execute(sqlString);
    }

    // insert
    public int insert(String sqlString) throws SQLException {
        return update(sqlString);
    }

    public <T> T insert(String sqlString, Class<T> insert) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        ResultSetHandler<T> handler = new BeanHandler<>(insert);
        return runner.insert(sqlString, handler);
    }

    // batch insert
    public <T> T batchInsert(String sqlString, Class<T> insert, Object[][] params) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        ResultSetHandler<T> handler = new BeanHandler<>(insert);
        return runner.insertBatch(sqlString, handler, params);
    }

    // update
    public int update(String sqlString) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        return runner.update(sqlString);
    }

    // batch update
    public int[] batchUpdate(String sqlString, Object[][] params) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        return runner.batch(sqlString, params);
    }

    // delete
    public int delete(String sqlString) throws SQLException {
        return update(sqlString);
    }

    // batch delete
    public int[] batchDelete(String sqlString, Object[][] params) throws SQLException {
        return batchUpdate(sqlString, params);
    }

    // search
    public <T> T query(String sqlString, Class<T> result) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        ResultSetHandler<T> handler = new BeanHandler<>(result);
        return runner.query(sqlString, handler);
    }
}