package com.dptech.util;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jelly * @date 2018-07-13 13:56
 * @ClassName: IStringUtils
 * @Description: TODO
 */
public final class IStringUtils extends StringUtils {
    private IStringUtils() {
    }

    public static String deleteBetweenAll(String source, String open, String close) {
        if (source == null || isEmpty(open) || isEmpty(close)) {
            return null;
        }
        return source.replace(substringsAll(source, open, close), EMPTY);
    }

    public static String trimAll(String source) {
        if (isEmpty(source)) return source;
        return source.replaceAll("\\s*", EMPTY);
    }

    /*
     * 包含边界
     *
     * @param str
     * @param open
     * @param close
     * @return
     */
    public static String[] substringsBetweenAll(String str, String open, String close) {
        if (str == null || isEmpty(open) || isEmpty(close)) {
            return null;
        }
        int strLen = str.length();
        if (strLen == 0) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        int closeLen = close.length();
        List list = new ArrayList();
        int pos = 0;
        while (pos < (strLen - closeLen)) {
            int start = str.indexOf(open, pos);
            if (start < 0) {
                break;
            }
            int end = str.indexOf(close, start);
            if (end < 0) {
                break;
            }
            end += closeLen;
            list.add(str.substring(start, end));
            pos = end;
        }
        if (list.isEmpty()) {
            return null;
        }
        return (String[]) list.toArray(new String[list.size()]);
    }


    // 包含边界
    public static String substringsAll(String source, String from, String to) {
        int start = source.indexOf(from);
        int end = source.indexOf(to);
        if (start == -1 || end == -1) return EMPTY;
        if (start > 0) {
            start = start - 1;
        }
        end = end + to.length();
        return source.substring(start, end);
    }

    // 包含左边
    public static String substringsLeft(String source, String from, String to) {
        int start = source.indexOf(from);
        int end = source.indexOf(to);
        if (start == -1 || end == -1) return EMPTY;
        if (start > 0) {
            start = start - 1;
        }
        return source.substring(start, end);
    }

    // 包含右边
    public static String substringsRight(String source, String from, String to) {
        int start = source.indexOf(from);
        int end = source.indexOf(to);
        if (start == -1 || end == -1) return EMPTY;
        start = start + from.length();
        end = end + to.length();
        return source.substring(start, end);
    }
}
