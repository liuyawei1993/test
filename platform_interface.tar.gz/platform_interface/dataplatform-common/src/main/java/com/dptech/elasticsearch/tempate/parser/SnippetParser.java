package com.dptech.elasticsearch.tempate.parser;

import org.apache.commons.io.FileUtils;
import org.dom4j.*;

import java.io.File;
import java.util.*;

/**
 * @author jelly * @date 2018-07-11 17:14
 * @ClassName: ExpressionParser
 * @Description: TODO
 */
public final class SnippetParser {
    private final String ATTR_NAME = "TEST";
    private String elementName;
    private Map<String, Object> params;
    private String source;

    public SnippetParser(String elementName, Map<String, Object> params) {
        this.elementName = elementName;
        this.params = params;
    }

    public SnippetParser(String elementName, Map<String, Object> params, String source) {
        this.elementName = elementName;
        this.params = params;
        this.source = source;
    }

    public String parse(String source) throws DocumentException {
        Document document = DocumentHelper.parseText(source);
        documentParse(document.getRootElement());
        return document.getStringValue();
    }

    public String parse() throws DocumentException {
        return this.parse(this.source);
    }

    private void documentParse(Element element) {
        final Attribute testAttribute = element.attribute(ATTR_NAME);
        if (testAttribute != null) {
            String attr = testAttribute.getValue();
            IfExpressionParser ifExpressionParser = new IfExpressionParser();
            if (!ifExpressionParser.parse(attr, params)) {
                element.getParent().remove(element);
            }
        }
        Iterator<Element> it = element.elementIterator(elementName);
        while (it.hasNext()) {
            documentParse(it.next());
        }
    }

    public static void main(String[] args) throws Exception {
        Map<String, Object> params = new HashMap<>();
        params.put("latitude", 30.213845);
        params.put("onlineStatus", "");
        params.put("chargingStatus", "");
        params.put("radius", 30);
        params.put("maxAlarmLevel", "");
        params.put("longitude", 120.202789);
        SnippetParser sp = new SnippetParser("if", params);
        System.out.println(sp.parse(FileUtils.readFileToString(new File("G:\\ecarx_project\\iov-bigdata-20180809\\iov-bigdata\\data-access\\api-newenergy-service\\src\\main\\resources\\es_query_template\\VehicleStatsFilter.tj"), "utf-8")));
    }

}
