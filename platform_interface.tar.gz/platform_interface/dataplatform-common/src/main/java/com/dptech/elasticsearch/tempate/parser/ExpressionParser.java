package com.dptech.elasticsearch.tempate.parser;


import com.dptech.elasticsearch.exception.SnippetParseException;

import java.util.Map;


/**
 * @author jelly * @date 2018-07-11 17:14
 * @ClassName: ExpressionParser
 * @Description: TODO
 */
public interface ExpressionParser {

    boolean parse(String snippet, Map<String, Object> params) throws SnippetParseException;

}
