package com.dptech.elasticsearch.exception;

/**
 * @author jelly.wang
 * @ClassName: EsException
 * @Description:
 * @date 2017/12/14
 */
public class SnippetParseException extends RuntimeException{

    public SnippetParseException(String message) {
        super(message);
    }

    public SnippetParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
