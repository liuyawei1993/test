package com.dptech.elasticsearch.queriers;

import com.dptech.elasticsearch.exception.EsException;
import com.dptech.elasticsearch.tempate.parser.ExpType;
import com.dptech.elasticsearch.tempate.parser.SnippetParser;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author jelly * @date 2018-07-03 17:04
 * @ClassName: EsQuerier
 * @Description: TODO
 */
public abstract class EsQuerier {
    private static final Logger LOGGER = LoggerFactory.getLogger(EsQuerier.class);

    public final static String SWAP_START_STRING = "${";
    public final static String SWAP_END_STRING = "}";
    // es restful 地址
    private String httpHost;
    // 查询模版文件名
    private String tempateFileName;
    // xpack用户名和密码
    private String xpackIdentify;

    public String getHttpHost() {
        return httpHost;
    }

    public void setHttpHost(String httpHost) {
        this.httpHost = httpHost;
    }

    public String getTempateFileName() {
        return tempateFileName;
    }

    public void setTempateFileName(String tempateFileName) {
        this.tempateFileName = tempateFileName;
    }

    public String getXpackIdentify() {
        return xpackIdentify;
    }

    public void setXpackIdentify(String xpackIdentify) {
        this.xpackIdentify = xpackIdentify;
    }

    EsQuerier(String httpHost, String tempateFileName) {
        this(httpHost, tempateFileName, null);
    }


    EsQuerier(String httpHost, String tempateFileName, String xpackIdentify) {
        this.httpHost = httpHost;
        this.tempateFileName = tempateFileName;
        this.xpackIdentify = xpackIdentify;
    }

    public abstract String doQuery(Map<String, Object> rrm) throws EsException, DocumentException, IOException;

    /**
     * @param rrm
     * @param tempString
     * @return
     * @throws EsException
     * @throws DocumentException
     */
    String assign(Map<String, Object> rrm, String tempString) throws EsException, DocumentException {
        tempString = new SnippetParser(ExpType.IF.typeString, rrm).parse(tempString);

        // 查询模版解析
        TempleteStrAssignerchain templeteStrAssignerchain = new TempleteStrAssignerchain();
        templeteStrAssignerchain.register(new TempleteStrAssignerchain.TempleteStrAssigner<String>() {
            @Override
            public String assign(String str) {
                if (rrm != null) {
                    for (Map.Entry<String, Object> p : rrm.entrySet()) {
                        if (null != p.getValue()) {
                            str = str.replace(SWAP_START_STRING + p.getKey() + SWAP_END_STRING, String.valueOf(p.getValue()));
                        }
                    }
                }
                return str;
            }
        }, 0);

        tempString = templeteStrAssignerchain.exec(tempString);
        LOGGER.debug("Query Template: " + tempString);

        if (tempString.indexOf(SWAP_END_STRING) != -1 && tempString.indexOf(SWAP_START_STRING) != -1) {
            throw new EsException("有参数未赋值");
        }

        return tempString.trim();
    }


    /**
     * 模版解析链
     */
    private static class TempleteStrAssignerchain {
        private List<TempleteStrAssigner> chain = new LinkedList<>();

        public <T> T exec(T t) {
            for (TempleteStrAssigner templeteStrAssigner : chain) {
                t = (T) templeteStrAssigner.assign(t);
            }
            return t;
        }

        // order from 0
        public <T> void register(TempleteStrAssigner<T> templeteStrAssigner, int order) {
            int len = chain.size();
            if (order > len) order = len;
            this.chain.add(order, templeteStrAssigner);
        }

        abstract static class TempleteStrAssigner<T> {
            public abstract T assign(T t);
        }
    }
}
