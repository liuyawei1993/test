package com.dptech.elasticsearch.queriers;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidPooledResultSet;
import com.alibaba.druid.pool.ElasticSearchResultSetMetaDataBase;
import com.alibaba.druid.util.jdbc.ResultSetMetaDataBase;
import com.alibaba.fastjson.JSON;
import com.dptech.elasticsearch.client.EsSqlClient;
import com.dptech.elasticsearch.exception.EsException;
import com.dptech.elasticsearch.common.IndexRowData;
import com.dptech.elasticsearch.tempate.entity.ConfigDescriptor;
import com.dptech.util.ConfigUtils;
import com.dptech.util.IStringUtils;
import com.dptech.util.dynamic.AutoLoadClasser;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

/**
 * @author jelly * @date 2018-07-03 17:04
 * @ClassName: EsSqlQuerier
 * @Description: TODO
 */
public class EsSqlQuerier extends EsQuerier {
    private static final Logger LOGGER = LoggerFactory.getLogger(EsSqlQuerier.class);
    private final Map<String, EsSqlClient> ES_SQL_CLIENT_MAP = new HashMap<>();

    /**
     * 在配置中获取host
     *
     * @param tempateFileName
     */
    public EsSqlQuerier(String tempateFileName) {
        this(ConfigUtils.getString("es_rpc_hosts", "localhost:9300"), tempateFileName);
    }

    /**
     * 无密码访问
     *
     * @param httpHost
     * @param tempateFileName
     */
    public EsSqlQuerier(String httpHost, String tempateFileName) {
        this(httpHost, tempateFileName, IStringUtils.EMPTY);
    }

    /**
     * 模版查询 - POST
     *
     * @param httpHost
     * @param tempateFileName
     * @param xpackIdentify
     */
    public EsSqlQuerier(String httpHost, String tempateFileName, String xpackIdentify) {
        super(httpHost, tempateFileName, xpackIdentify);
    }

    @Override
    public String doQuery(Map<String, Object> rrm) throws EsException, DocumentException {
        final Map<String, ConfigDescriptor> esFileCache = AutoLoadClasser.esFileCache;
        ConfigDescriptor fd = esFileCache.get(this.getTempateFileName());
        String indexName = fd.getIndexName();
        String indexType = fd.getIndexType();
        String fields = fd.getFields();

        if (IStringUtils.isEmpty(indexName) || IStringUtils.isEmpty(indexType) || IStringUtils.isEmpty(fields))
            throw new EsException("undefined：[indexName,indexType,fields]");

        String tempString = fd.getQueryTemplate();
        if (IStringUtils.isEmpty(tempString))
            throw new EsException("the query template cannot be empty.");

        tempString = assign(rrm, tempString);

        EsSqlClient esSqlClient = ES_SQL_CLIENT_MAP.get(indexName);
        if (null == esSqlClient) {
            esSqlClient = new EsSqlClient(this.getHttpHost(), this.getXpackIdentify()).init(new HashMap<String, Object>() {{
                put("index", indexName);
            }});

            ES_SQL_CLIENT_MAP.put(indexName,esSqlClient);
        }

        PreparedStatement ps = null;
        Connection connection = null;
        try {
            DruidDataSource dataSource = esSqlClient.getDataSource();
            connection = dataSource.getConnection();
            ps = connection.prepareStatement(tempString);

            final List<IndexRowData> indexRowDatas = new ArrayList<>();
            final DruidPooledResultSet resultSet = (DruidPooledResultSet) ps.executeQuery();
            if (null != resultSet) {
                ElasticSearchResultSetMetaDataBase metaData = (ElasticSearchResultSetMetaDataBase) resultSet.getMetaData();
                List<ResultSetMetaDataBase.ColumnMetaData> columns = metaData.getColumns();

                while (resultSet.next()) {
                    final IndexRowData indexRowData = new IndexRowData();
                    columns.forEach((c) -> {
                        String columnLabel = c.getColumnLabel();
                        try {
                            indexRowData.put(columnLabel, resultSet.getObject(columnLabel));
                        } catch (SQLException e) {
                            LOGGER.error("obtain resultSet exception ", e);
                        }
                    });
                    indexRowDatas.add(indexRowData);
                }
            }
            return JSON.toJSONString(indexRowDatas);
        } catch (Exception e) {
            throw new EsException("sql query failed", e);
        } finally {
            try {
                if (null != ps) ps.close();
                if (null != connection) connection.close();
                // esSqlClient.close();
            } catch (SQLException e) {
                LOGGER.error("datasource is closed failed ", e);
            }
        }
    }
}
