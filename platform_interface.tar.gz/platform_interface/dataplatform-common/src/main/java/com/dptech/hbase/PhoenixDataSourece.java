package com.dptech.hbase;

import com.alibaba.druid.pool.DruidDataSource;
import com.dptech.util.ConfigUtils;
import com.dptech.util.IStringUtils;

/**
 * @author jelly * @date 2019-09-08 20:38
 * @ClassName: PhoenixDataSoureceF
 * @Description: TODO
 */
public final class PhoenixDataSourece {
    private String url;
    private String identify;

    private DruidDataSource dataSource;

    public DruidDataSource getDataSource() {
        return dataSource;
    }

    public PhoenixDataSourece(String url) {
        this(url, null);
    }

    public PhoenixDataSourece(String url, String identify) {
        this.url = url;
        this.identify = identify;
    }

    public void init() {
        dataSource = new DruidDataSource() {{
            setUrl(url);
            if (IStringUtils.isNotEmpty(identify)) {
                String[] userPass = identify.split(":");
                setUsername(userPass[0]);
                setPassword(userPass[1]);
            }

            setDriverClassName(ConfigUtils.getString("phoenix_driverClassName", "org.apache.phoenix.jdbc.PhoenixDriver"));
            setInitialSize(ConfigUtils.getInt("phoenix_initialSize", 0));
            setMaxActive(ConfigUtils.getInt("phoenix_maxActive", 8));
            setMinIdle(ConfigUtils.getInt("phoenix_minIdle", 1));
            setMaxWait(ConfigUtils.getInt("phoenix_maxWait", 1000));
            setTimeBetweenEvictionRunsMillis(ConfigUtils.getInt("phoenix_timeBetweenEvictionRunsMillis", 10000));
        }};
    }

    public void close() {
        if (null != this.dataSource) {
            this.dataSource.close();
        }
    }
}
