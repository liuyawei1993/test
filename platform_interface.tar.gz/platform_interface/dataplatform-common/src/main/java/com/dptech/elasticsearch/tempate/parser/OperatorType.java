package com.dptech.elasticsearch.tempate.parser;

/**
 * @author jelly.wang
 * @ClassName: OperatorType
 * @Description:
 * @date 2017年1月12日
 */
public enum OperatorType {
    GE(">="), GT(">"), LE("<="), LT("<"), NE("!="), EQ("="),NONE("NONE");

    public String typeString;

    OperatorType(String opertor) {
        this.typeString = opertor;
    }


    public static OperatorType setOperatorType(String str) {
        final OperatorType[] values = OperatorType.values();
        for (OperatorType ot : values) {
            if (str.equals(ot.typeString)) return ot;
        }
        return NONE;
    }
}