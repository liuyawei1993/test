package com.dptech.elasticsearch.client;

import com.dptech.elasticsearch.exception.EsException;

import java.io.IOException;
import java.util.Map;

public abstract class AbstractClient {
    private String hosts;
    private String xpackIdentify;

    AbstractClient(String hosts) {
        this.hosts = hosts;
    }

    AbstractClient(String hosts, String xpackIdentify) {
        this.hosts = hosts;
        this.xpackIdentify = xpackIdentify;
    }

    public String getHosts() {
        return hosts;
    }

    public void setHosts(String hosts) {
        this.hosts = hosts;
    }

    public String getXpackIdentify() {
        return xpackIdentify;
    }

    public void setXpackIdentify(String xpackIdentify) {
        this.xpackIdentify = xpackIdentify;
    }

    public abstract AbstractClient init(Map<String, Object> params) throws EsException;

    public abstract void close() throws IOException;
}
