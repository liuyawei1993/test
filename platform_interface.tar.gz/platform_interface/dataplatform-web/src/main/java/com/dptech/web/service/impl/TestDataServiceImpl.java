package com.dptech.web.service.impl;

import com.dptech.web.exception.WebException;
import com.dptech.web.service.DataService;
import com.dptech.web.util.DaoHelper;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class TestDataServiceImpl implements DataService {
    @Override
    public String register() {
        return "bro";
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
//            return DaoHelper.obtainSingleEsSqlClient("bro").doQuery(params);
            return DaoHelper.obtainSingleEsRestClient("bro").doQuery(params);
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
