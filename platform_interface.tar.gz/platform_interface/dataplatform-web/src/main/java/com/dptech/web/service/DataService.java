package com.dptech.web.service;

import com.dptech.web.exception.WebException;
import org.springframework.stereotype.Service;

import java.util.Map;


/**
 * @author jelly.wang
 * @ClassName: DataService
 * @Description:
 * @date 2019/09/08
 */
@Service
public interface DataService {

    String register();

    Object obtainData(Map<String, Object> params) throws WebException;
}
