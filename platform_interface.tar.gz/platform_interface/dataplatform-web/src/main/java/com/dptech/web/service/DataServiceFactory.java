package com.dptech.web.service;


import com.dptech.web.exception.WebException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/**
 * @author jelly.wang
 * @ClassName: DataServiceFactory
 * @Description:
 * @date 2019/09/08
 */
@Service
public class DataServiceFactory {
    private final Map<String, DataService> DATA_SERVICE_MAP = new ConcurrentHashMap<>();

    public DataServiceFactory(List<DataService> dataServices) {
        dataServices.forEach((ds) -> {
            DATA_SERVICE_MAP.put(ds.register(), ds);
        });
    }

    public Object execute(String method, Map<String, Object> params) throws WebException {
        DataService dataService = DATA_SERVICE_MAP.get(method);
        if (null != dataService) {
            return dataService.obtainData(params);
        }
        throw new WebException("method:[" + method + "] does not exist");
    }
}