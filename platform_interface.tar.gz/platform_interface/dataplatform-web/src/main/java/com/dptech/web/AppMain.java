package com.dptech.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource("classpath:spring/spring.xml")
public class AppMain extends SpringBootServletInitializer implements EmbeddedServletContainerCustomizer {
    private static final Logger LOGGER = LoggerFactory.getLogger(AppMain.class);

    public static void main(String[] args) {
        try {
            SpringApplication.run(AppMain.class, args);
        } catch (Exception e) {
            LOGGER.error("spring-boot start exception: ", e);
        }
    }


    @Override
    public void customize(ConfigurableEmbeddedServletContainer container) {
        container.setPort(8060);
    }
}
