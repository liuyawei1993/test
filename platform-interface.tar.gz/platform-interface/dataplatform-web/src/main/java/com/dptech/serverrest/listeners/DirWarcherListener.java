package com.dptech.serverrest.listeners;

import com.dptech.util.dynamic.AutoLoadClasser;
import com.dptech.util.filewatcher.FileMonitor;

import static com.dptech.serverrest.common.WebConstants.REST_TEMPLETE_PATH;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;


/**
 * Created by jenkin.wang on 2017/2/20.
 */
@Component("dirWarcherListener")
public class DirWarcherListener implements ApplicationListener<ContextRefreshedEvent> {
    private final Logger logger = Logger.getLogger(DirWarcherListener.class);

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        logger.info("listening folder =>" + REST_TEMPLETE_PATH);
        try {
            AutoLoadClasser.init(REST_TEMPLETE_PATH);
            new FileMonitor(REST_TEMPLETE_PATH, 30000L).start();
        } catch (Exception e) {
            logger.info("error loading folder =>", e);
        }
    }
}
