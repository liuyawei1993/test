package com.dptech.serverrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableScheduling
public class WebAppMain {

    public static void main(String[] args) {
        SpringApplication.run(WebAppMain.class, args);
    }
}
