package com.dptech.serverrest.service.impl.ccAttack;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.EsResultExtractor;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * @author : wangwei
 * @date : Created in 2019/9/25 上午9:34
 * @description: TODO
 */
@Service
public class CcAttackTop5Impl implements DataService {
    private final String METHOD_NAME = "ccAttackTop5";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
            paramProcess(params);
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                int threadNum = 2;
                ExecutorService executor = Executors.newFixedThreadPool(threadNum);
                CompletionService<Map<String, Object>> completionService = new ExecutorCompletionService<>(executor);
                completionService.submit(new Top5Callable("ip_src_addr", (Map) ObjectUtils.deepClone(params)));
                completionService.submit(new Top5Callable("ip_dst_addr", (Map) ObjectUtils.deepClone(params)));
                try {
                    final Map<String, Object> returnMap = new HashMap<>();

                    while (threadNum-- > 0) {
                        returnMap.putAll(completionService.take().get());
                    }
                    return returnMap;
                } catch (Exception e) {
                    throw new WebException(e.getMessage(), e);
                } finally {
                    executor.shutdown();
                }
            } else {
                // multi index
                return null;
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }


    private class Top5Callable implements Callable<Map<String, Object>> {
        private String type;
        private Map<String, Object> params;

        public Top5Callable(String type, Map<String, Object> params) {
            this.type = type;
            this.params = params;
        }

        @Override
        public Map<String, Object> call() throws Exception {
            params.put("type", type);
            String result = DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
            EsResultExtractor esResultExtractor = new EsResultExtractor();
            EsResultExtractor extract = esResultExtractor.extract(result);
            if (type.endsWith("keyword")) {
                type = type.replace(".keyword", "");
            }
            List<Map<String, Object>> buckets = extract.getParentBucketsMap();
            buckets.forEach(bucket -> {
                bucket.put(type, bucket.remove("key"));
                bucket.put("value", bucket.remove("doc_count"));
                bucket.put("name",bucket.remove(type));
            });
            return new HashMap<String, Object>() {{
                put(type, buckets);
            }};
        }
    }
}
