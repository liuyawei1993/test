package com.dptech.serverrest.controller;

import com.alibaba.fastjson.JSON;
import com.dptech.serverrest.common.RetMessage;
import com.dptech.util.ConfigUtils;
import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataServiceFactory;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.google.common.util.concurrent.RateLimiter;
import org.mortbay.jetty.security.Credential;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.constraints.NotNull;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Controller
@RequestMapping("dataplatform")
public class DataPlatformController {
    private static final Logger LOGGER = LoggerFactory.getLogger(DataPlatformController.class);
    private static final Cache<String, RetMessage> RET_CACHE = Caffeine.newBuilder().expireAfterAccess(ConfigUtils.getInt("cache_size",10), TimeUnit.MINUTES).build();
    private static final RateLimiter rateLimiter = RateLimiter.create(ConfigUtils.getInt("rate_limit", 10));

    @Autowired
    private DataServiceFactory dataServiceFactory;

    @RequestMapping(value = "/search/{method}", method = RequestMethod.POST)
    @ResponseBody
    public RetMessage execute(@NotNull @PathVariable(name = "method") String method, @RequestBody Map<String, Object> params) {
        RetMessage retMessage;
        // RateLimit
        if (rateLimiter.tryAcquire()) {
            //cache
            String key = Credential.MD5.digest(method + JSON.toJSONString(params));
            retMessage = RET_CACHE.getIfPresent(key);
            if (null != retMessage) {
                LOGGER.debug("======> hit cache <======");
                return retMessage;
            }

            retMessage = new RetMessage();
            try {
                retMessage.setData(dataServiceFactory.execute(method, params));
                RET_CACHE.put(key, retMessage);
            } catch (WebException e) {
                retMessage.setCode(RetMessage.RetCode.MES_ERROR.getCode());
                retMessage.setMessage(RetMessage.RetCode.MES_ERROR.getName() + " => " + e.getMessage());
                LOGGER.error("dataservice execute failed ", e);
            }
        } else {
            retMessage = new RetMessage();
            retMessage.setCode(RetMessage.RetCode.MES_OTHER.getCode());
            retMessage.setMessage("access denied");
            LOGGER.debug("======>access denied<======");
        }
        return retMessage;
    }
}
