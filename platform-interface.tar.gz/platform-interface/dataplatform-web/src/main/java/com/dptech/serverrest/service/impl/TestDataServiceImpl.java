package com.dptech.serverrest.service.impl;

import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class TestDataServiceImpl implements DataService {
    @Override
    public String register() {
        return "bro";
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
//            return DaoHelper.obtainSingleEsSqlClient("bro").doQuery(params);
            return DaoHelper.obtainSingleEsRestClient("bro").doQuery(params);
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
