package com.dptech.serverrest.service.impl.emailthreat;

import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.EsResultExtractor;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @className: emailThreatListImpl
 * @description:
 * @author: fanxiaopan
 * @create: 2019-09-26
 */
@Service
public class EmailThreatListImpl implements DataService {

    private final String METHOD_NAME = "emailThreatList";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
            paramProcess(params);
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                String jsonStr = DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
                EsResultExtractor esResultExtractor = new EsResultExtractor();
                EsResultExtractor extract = esResultExtractor.extract(jsonStr);
                Map<String,Object> retMap = new HashMap<>();
                EsResultExtractor.Result result = extract.getResult();
                retMap.put("total",result.getTotal());
                retMap.put("hits",result.getHits());
                List<Map<String,Object>> retList = new ArrayList<>();
                return retMap;
            } else {
                // multi index
                return null;
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
