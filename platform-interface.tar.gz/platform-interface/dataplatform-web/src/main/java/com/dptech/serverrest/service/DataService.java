package com.dptech.serverrest.service;

import com.dptech.util.DateUtils;
import com.dptech.serverrest.exception.WebException;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author jelly.wang
 * @ClassName: DataService
 * @Description:
 * @date 2019/09/08
 */
@Service
public interface DataService {

    String register();

    Object obtainData(Map<String, Object> params) throws WebException;

    default void paramProcess(Map<String, Object> params) throws ParseException {
        // get indexName
        String[] dateInterval = params.remove("timestamp").toString().split(",");
        Long startTime = Long.parseLong(dateInterval[0]);
        Long endTime = Long.parseLong(dateInterval[1]);
        params.put("startTime", startTime);
        params.put("endTime", endTime);

        List<String> times = DateUtils.dateForEach(startTime, endTime, 1);
        if (times.isEmpty()) throw new RuntimeException("param [timestamp] is error");

        if (times.size() == 1) {
            params.put("indexName", times.get(0));
        } else {
            params.put("indexList", times);
        }
        // other params

    }
}
