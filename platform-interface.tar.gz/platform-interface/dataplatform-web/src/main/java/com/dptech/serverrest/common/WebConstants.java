package com.dptech.serverrest.common;


public interface WebConstants {

    //REST TEMPLATE PATH
    String ES_QUERY_TEMPLETE = "template";
    String REST_TEMPLETE_PATH = WebConstants.class.getClassLoader().getResource(WebConstants.ES_QUERY_TEMPLETE).getPath();
}
