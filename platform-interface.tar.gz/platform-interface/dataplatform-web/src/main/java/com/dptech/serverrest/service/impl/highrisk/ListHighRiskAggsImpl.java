package com.dptech.serverrest.service.impl.highrisk;

import com.alibaba.fastjson.JSONObject;
import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.EsResultExtractor;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/25 上午10:53
 * @description: TODO
 */
@Service
public class ListHighRiskAggsImpl implements DataService {
    private final String METHOD_NAME = "listHighRiskAggs";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
            paramProcess(params);
            List<Map<String, Object>> resultList = new ArrayList<>();
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                params.put("interval", "hour");
                params.put("format", "HH");
                String result = DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
                EsResultExtractor esResultExtractor = new EsResultExtractor();
                List<Map<String, Object>> parentBucketsMap = esResultExtractor.extract(result).getParentBucketsMap();
                parentBucketsMap.forEach(bucketsMap -> {
                    resultList.add(new HashMap<String, Object>() {{
                        put("num",bucketsMap.get("doc_count"));
                        put("date",bucketsMap.get("key_as_string"));
                        List<Map<String, Object>> threatTypeList = esResultExtractor.getParentBucketsList((JSONObject) bucketsMap.get("types_count"));
                        threatTypeList.forEach(threatTypeMap -> {
                            threatTypeMap.put("enrichments:threat_type", threatTypeMap.remove("key"));
                            threatTypeMap.put("num", threatTypeMap.remove("doc_count"));
                        });
                        put("threats", threatTypeList);
                    }});
                });
                return resultList;
            } else {
                params.put("interval", "day");
                params.put("format", "yyyy.MM.dd");
                // multi index
                return Collections.emptyList();
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
