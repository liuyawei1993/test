package com.dptech.serverrest.service.impl.highrisk;

import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.EsResultExtractor;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Collections;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/24 下午8:06
 * @description: TODO
 */
@Service
public class ListHighRiskLogImpl implements DataService {
    private final String METHOD_NAME = "listHighRiskLog";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
            paramProcess(params);
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                String s = DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
                EsResultExtractor.Result result = new EsResultExtractor().extract(s).getResult();

                return new HashMap<String, List<Map<String, Object>>>() {{
                    put("hits", result.getHits());
                }};
            } else {
                // multi index
                return Collections.emptyList();
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
