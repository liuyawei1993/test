package com.dptech.serverrest.util;

import com.dptech.elasticsearch.queriers.EsSqlQuerier;
import com.dptech.elasticsearch.queriers.EsTemplateQuerier;
import com.dptech.hbase.HbaseClient;
import com.dptech.hbase.PhoenixClient;
import com.dptech.redis.RedisLocalClient;
import com.dptech.util.ConfigUtils;

import java.sql.SQLException;

/**
 * @author jelly * @date 2019-09-08 20:38
 * @ClassName: DaoHelper
 * @Description: TODO
 */
public final class DaoHelper {
    private static EsTemplateQuerier esTemplateQuerier;
    private static EsSqlQuerier esSqlQuerier;
    private static RedisLocalClient redisLocalClient;
    private static PhoenixClient phoenixClient;
    private static HbaseClient hbaseClient;

    private DaoHelper() {
    }


    /**
     * single model
     *
     * @param tempateFileName
     * @return EsTemplateQuerier
     */
    public static EsTemplateQuerier obtainSingleEsRestClient(String tempateFileName) {
        if (null == esTemplateQuerier)
            esTemplateQuerier = obtainEsRestClient(tempateFileName);
        else
            esTemplateQuerier.setTempateFileName(tempateFileName);
        return esTemplateQuerier;
    }

    /**
     * @return EsTemplateQuerier
     */
    public static EsTemplateQuerier obtainEsRestClient(String tempateFileName) {
        return new EsTemplateQuerier(tempateFileName);
    }

    /**
     * single model
     *
     * @return EsSqlQuerier
     */
    public static EsSqlQuerier obtainSingleEsSqlClient(String tempateFileName) {
        if (null == esSqlQuerier)
            esSqlQuerier = obtainEsSqlClient(tempateFileName);
        else
            esSqlQuerier.setTempateFileName(tempateFileName);
        return esSqlQuerier;
    }

    /**
     * @return EsSqlQuerier
     */
    public static EsSqlQuerier obtainEsSqlClient(String tempateFileName) {
        return new EsSqlQuerier(tempateFileName);
    }

    /**
     * single model
     *
     * @return RedisLocalClient
     */
    public static RedisLocalClient obtainSingleRedisLocalClient() {
        if (null == redisLocalClient)
            redisLocalClient = obtainRedisLocalClient();
        return redisLocalClient;
    }


    /**
     * @return RedisLocalClient
     */
    public static RedisLocalClient obtainRedisLocalClient() {
        return new RedisLocalClient(ConfigUtils.getString("reids_host", "localhost:6379"));
    }

    /**
     * single model
     *
     * @return PhoenixClient
     */
    public static PhoenixClient obtainSinglePhoenixClient() {
        if (null == phoenixClient)
            phoenixClient = obtainPhoenixClient();
        return phoenixClient;
    }

    /**
     * @return PhoenixClient
     */
    public static PhoenixClient obtainPhoenixClient() {
        return new PhoenixClient(ConfigUtils.getString("phoenix_jdbcUrl", "jdbc:phoenix:localhost:2181:/hbase-unsecure"));
    }

    /**
     * @return HbaseClient
     */
    public static HbaseClient obtainSingleHbaseClient() {
        if (null == hbaseClient)
            hbaseClient = obtainHbaseClient();
        return hbaseClient;
    }

    /**
     * @return HbaseClient
     */
    public static HbaseClient obtainHbaseClient() {
        return new HbaseClient();
    }


    public static void main(String[] args) throws SQLException {
        PhoenixClient phoenixClient = obtainPhoenixClient();

//        phoenixClient.delete("delete from \"asset_list\" where \"asset_group\" = '分组2'");

        System.out.println(phoenixClient.query("select * from \"asset_list\""));
    }
}
