package com.dptech.serverrest.service.impl.ccAttack;

import com.alibaba.fastjson.JSON;
import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.EsResultExtractor;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import javax.validation.valueextraction.ExtractedValue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ListCcAttackImpl implements DataService {
    private final String METHOD_NAME = "listCcAttack";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
            paramProcess(params);
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                String s = DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
                System.out.println(s);
                EsResultExtractor.Result result=new EsResultExtractor().extract(s).getResult();
                List<Map<String, Object>> list=result.getHits();
                Map<String,Object> returnMap=new HashMap<>();
                returnMap.put("hits",list);
                return returnMap;
            } else {
                // multi index
                return null;
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
