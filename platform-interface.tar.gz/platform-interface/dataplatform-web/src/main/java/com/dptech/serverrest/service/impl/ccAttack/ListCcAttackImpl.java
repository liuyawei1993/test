package com.dptech.serverrest.service.impl.ccAttack;

import com.alibaba.fastjson.JSON;
import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import javax.validation.valueextraction.ExtractedValue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ListCcAttackImpl implements DataService {
    private final String METHOD_NAME = "listCcAttack";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
            paramProcess(params);
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                String s = DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
                Map<String, Object> map = JSON.parseObject(s);
                Map<String, Object> returnMap = new HashMap<>();
                List<Map<String, Object>> returnList = new ArrayList<>();
                returnMap.put("total", ((Map) map.get("hits")).get("total"));
                List<Map<String, Object>> list = (List<Map<String, Object>>) ((Map<String, Object>) map.get("hits")).get("hits");
                int n=0;
                for (Map<String, Object> m : list) {
                    Map<String, Object> rawMap = (Map) m.get("_source");
                    Map<String, Object> ccAttackMap = new HashMap<>();
                    ccAttackMap.put("time", rawMap.get("timeStamp"));
                    ccAttackMap.put("source",rawMap.get("enrichments:source_engine") );
                    ccAttackMap.put("domain",rawMap.get("domain"));
                    ccAttackMap.put("protocol",rawMap.get("protocal") );
                    ccAttackMap.put("id",n++ );
                    Map<String,Object> initiatorIp=new HashMap<>();
                    initiatorIp.put("value",rawMap.get("ip_src_addr"));
                    initiatorIp.put("type",rawMap.get("enrichments:geo:ip_src_addr:country_code"));
                    ccAttackMap.put("initiatorIp", initiatorIp);
                    Map<String,Object> victimIp=new HashMap<>();
                    victimIp.put("value",rawMap.get("ip_dst_addr"));
                    victimIp.put("type",rawMap.get("enrichments:geo:ip_dst_addr:country_code"));
                    ccAttackMap.put("victimIp", victimIp);
                    returnList.add(ccAttackMap);
                }
                returnMap.put("tableData", returnList);

                return returnMap;
            } else {
                // multi index
                return null;
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
