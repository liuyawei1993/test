package com.dptech.serverrest.service.impl.emailthreat;

import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.EsResultExtractor;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

/**
 * @className: EmailThreatSummaryImpl
 * @description:
 * @author: fanxiaopan
 * @create: 2019-09-24
 */
@Service
public class EmailThreatSummaryImpl implements DataService {

    private final String METHOD_NAME = "emailThreatChart";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {

        try {
            paramProcess(params);
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                int threadNum = 3;
                ExecutorService executor = Executors.newFixedThreadPool(threadNum);
                CompletionService<Map<String, Object>> completionService = new ExecutorCompletionService<>(executor);
                completionService.submit(new EmailThreatSumCallable("ip_dst_addr", (Map) ObjectUtils.deepClone(params)));
                completionService.submit(new EmailThreatSumCallable("ip_src_addr", (Map) ObjectUtils.deepClone(params)));
                completionService.submit(new EmailThreatSumCallable("enrichments:threat_type.keyword", (Map) ObjectUtils.deepClone(params)));

                try {
                    final Map<String, Object> returnMap = new HashMap<>();

                    while (threadNum-- > 0) {
                        returnMap.putAll(completionService.take().get());
                    }

                    return returnMap;
                } catch (Exception e) {
                    throw new WebException(e.getMessage(), e);
                } finally {
                    executor.shutdown();
                }
            } else {
                // multi index
                return null;
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }

    private class EmailThreatSumCallable implements Callable<Map<String, Object>> {
        private String type;
        private Map<String, Object> params;

        public EmailThreatSumCallable(String type, Map<String, Object> params) {
            this.type = type;
            this.params = params;
        }

        @Override
        public Map<String, Object> call() throws Exception {
            params.put("type", type);
            String result = DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
            EsResultExtractor esResultExtractor = new EsResultExtractor();
            EsResultExtractor extract = esResultExtractor.extract(result);
            List<Map<String, Object>> buckets = extract.getParentBucketsMap();
            for (Map<String, Object> bucket : buckets) {
                bucket.put("name",bucket.remove("key"));
                bucket.put("value",bucket.remove("doc_count"));
            }
            return new HashMap<String, Object>() {{
                put(type, buckets);
            }};
        }
    }
}
