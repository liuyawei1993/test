package com.dptech.serverrest.service.impl.ccAttack;

import com.dptech.serverrest.exception.WebException;
import com.dptech.serverrest.service.DataService;
import com.dptech.serverrest.util.DaoHelper;
import com.dptech.util.EsResultExtractor;
import com.dptech.util.ObjectUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class CcAttackTrendImpl implements DataService {
    private final String METHOD_NAME = "ccAttackTrend";

    @Override
    public String register() {
        return METHOD_NAME;
    }

    @Override
    public Object obtainData(Map<String, Object> params) throws WebException {
        try {
            paramProcess(params);
            if (ObjectUtils.isNull(params.remove("indexList"))) {
                String s=DaoHelper.obtainSingleEsRestClient(METHOD_NAME).doQuery(params);
                EsResultExtractor esResultExtractor = new EsResultExtractor();
                EsResultExtractor extract = esResultExtractor.extract(s);
                List<Map<String, Object>> buckets = extract.getParentBucketsMap();
                List<Map<String,Object>> returnList=new ArrayList<>();
                for(Map<String,Object> map:buckets){
                    Map<String,Object> returnMap=new HashMap<>();
                    returnMap.put("name",map.get("key_as_string"));
                    returnMap.put("value",map.get("doc_count"));
                    returnList.add(returnMap);
                }
                return new HashMap<String, Object>() {{
                    put("ccAttackTrend", returnList);
                }};
            }
            else
            {
                return null;
            }
        } catch (Exception e) {
            throw new WebException(e.getMessage(), e);
        }
    }
}
