package com.dptech.serverrest.exception;

/**
 * @author jelly.wang
 * @ClassName: EsException
 * @Description:
 * @date 2017/12/14
 */
public class WebException extends Exception {

    public WebException(String message) {
        super(message);
    }

    public WebException(String message, Throwable cause) {
        super(message, cause);
    }
}
