package com.dptech.redis;

import com.dptech.util.ConfigUtils;
import com.dptech.util.IStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.*;

import java.util.*;

/**
 * @author jelly * @date 2018-07-10 20:38
 * @ClassName: RedisLocalClient
 * @Description: TODO
 */
public final class RedisLocalClient implements IRedisCache {
    private static final Logger LOGGER = LoggerFactory.getLogger(RedisLocalClient.class);
    // 最大活跃数
    private final int redisMaxTotal = 5000;
    // 最大空闲数
    private final int redisMaxIdle = 300;
    // 最小空闲数
    private final int redisMinIdle = 100;
    // 获取对象等待时间
    private final int redisMaxWait = 10 * 1000;
    // 检查可用性
    private boolean testOnBorrow = true;

    private int slot = 0;
    /**
     * 数据源
     */
    private JedisPool jedisPool;
    /**
     * 缓存180秒
     */
    public static final int REF_SECONDS = 180;

    // set slot
    public void setSlot(int slot) {
        this.slot = slot;
    }

    public RedisLocalClient() {
        this(ConfigUtils.getString("reids_host", "localhost:6379"));
    }

    public RedisLocalClient(String host) {
        JedisPoolConfig config = new JedisPoolConfig() {{
            setMaxTotal(ConfigUtils.getInt("redis_max_total", redisMaxTotal));
            setMaxIdle(ConfigUtils.getInt("redis_max_idle", redisMaxIdle));
            setMinIdle(ConfigUtils.getInt("redis_min_idle", redisMinIdle));
            setMaxWaitMillis(ConfigUtils.getInt("reids_max_wait", redisMaxWait));
            setTestOnBorrow(testOnBorrow);
        }};

        String[] ipAndPort = host.split(":");
        String password = ConfigUtils.getString("reids_password");
        if (IStringUtils.isNotEmpty(password)) {
            jedisPool = new JedisPool(config, ipAndPort[0], Integer.valueOf(ipAndPort[1]), ConfigUtils.getInt("redis_timeout", 30000), password);
        } else {
            jedisPool = new JedisPool(config, ipAndPort[0], Integer.valueOf(ipAndPort[1]));
        }

    }

    /**
     * 为给定 key 设置生存时间，当 key 过期时(生存时间为 0 )，它会被自动删除。
     * 在 Redis 中，带有生存时间的 key 被称为『可挥发』(volatile)的。
     *
     * @param key    key
     * @param expire 生命周期，单位为秒
     * @return 1: 设置成功 0: 已经超时或key不存在
     */
    public Long expire(final String key, final int expire) {
        try {
            return new Executor<Long>(jedisPool) {
                @Override
                Long execute() {
                    return jedis.expire(key, expire);
                }
            }.getResult();
        } catch (Exception e) {
            LOGGER.error("", e);
            return 0L;
        }
    }


    /**
     * @param pattern
     * @return
     */
    public Set<String> keys(String pattern) {
        return new Executor<Set<String>>(jedisPool) {
            @Override
            Set<String> execute() {
                return jedis.keys(pattern);
            }
        }.getResult();
    }

    /**
     * @param key
     * @return
     */
    public Set<String> zrange(String key) {
        return new Executor<Set<String>>(jedisPool) {
            @Override
            Set<String> execute() {
                return jedis.zrange(key,0,-1);
            }
        }.getResult();
    }


    /**
     * @param pattern
     * @param curosr
     * @return
     */
    public ScanResult scan(String pattern, String curosr) {
        return new Executor<ScanResult>(jedisPool) {
            @Override
            ScanResult execute() {
                return jedis.scan(curosr, new ScanParams() {{
                    match(pattern);
                    count(10000);
                }});
            }
        }.getResult();
    }


    /* ======================================Strings====================================== */

    /**
     * 将 key 的值设为 value ，当且仅当 key 不存在。若给定的 key 已经存在，则 setStringIfNotExists 不做任何动作。
     * 时间复杂度：O(1)
     *
     * @param key   key
     * @param value string value
     * @return 设置成功，返回 1 。设置失败，返回 0 。
     */
    public Long setStringIfNotExists(final String key, final String value) {
        try {
            return new Executor<Long>(jedisPool) {
                @Override
                Long execute() {
                    return jedis.setnx(key, value);
                }
            }.getResult();
        } catch (Exception e) {
            LOGGER.error("", e);
            return null;
        }

    }

    /**
     * 返回 key 所关联的字符串值。如果 key 不存在那么返回特殊值 nil 。
     * 假如 key 储存的值不是字符串类型，返回一个错误，因为 getString 只能用于处理字符串值。
     * 时间复杂度: O(1)
     *
     * @param key key
     * @return 当 key 不存在时，返回 nil ，否则，返回 key 的值。如果 key 不是字符串类型，那么返回一个错误。
     */
    public String getString(final String key) {
        try {
            return new Executor<String>(jedisPool) {
                @Override
                String execute() {
                    return jedis.get(key);
                }
            }.getResult();
        } catch (Exception e) {
            LOGGER.error("", e);
            return null;
        }

    }

    /* ======================================List====================================== */

    /**
     * 获取缓存名
     *
     * @param type 类型
     * @param key  键
     * @return byte[]
     */
    private byte[] getCacheName(String type, String key) {
        StringBuilder cacheName = new StringBuilder(type);
        if (StringUtils.isNotEmpty(key)) {
            cacheName.append("_").append(key);
        }
        return cacheName.toString().getBytes();
    }

    /**
     * 获取字符串缓存名
     *
     * @param type 类型
     * @param key  键
     * @return 缓存结果
     */
    @Override
    public String getStrCacheName(String type, String key) {
        StringBuilder cacheName = new StringBuilder(type);
        if (StringUtils.isNotEmpty(key)) {
            cacheName.append("_").append(key);
        }
        return cacheName.toString();
    }

    /**
     * 写入Cache
     *
     * @param type    类型
     * @param key     键
     * @param value   值
     * @param seconds 缓存有效期
     * @return 缓存结果
     */
    @Override
    public String putInCache(final String type, final String key, final String value, final int seconds) {
        if (value == null) {
            LOGGER.error("value sent to redis cannot be null");
            return null;
        }
        return new Executor<String>(jedisPool) {

            @Override
            String execute() {
                try {
                    String cacheName = getStrCacheName(type, key);
                    if (seconds < 1) {
                        jedis.set(cacheName, value);
                    } else {
                        jedis.setex(cacheName, seconds, value);
                    }
                } catch (Exception e) {
                    LOGGER.error("cache {} socket error", getCacheName(type, key), e);
                }
                return null;
            }

        }.getResult();

    }

    /**
     * 无时限缓存
     *
     * @param type  类型
     * @param key   键
     * @param value 值
     */
    @Override
    public void putNoTimeInCache(String type, String key, String value) {
        if (value != null) {
            putInCache(type, key, value, -1);
        }
    }


    /**
     * 删除对应的type_key
     *
     * @param type String
     * @param key  匹配的key
     * @return Long
     */
    @Override
    public Long delKey(final String type, final String key) {
        if (key == null || "".equals(key.trim())) {
            return 0L;
        }
        try {
            final String preKey = type + "_" + key;
            LOGGER.debug("delKey  Redis 前缀 ：{}", type);
            return new Executor<Long>(jedisPool) {
                @Override
                Long execute() {
                    return jedis.del(preKey);
                }
            }.getResult();
        } catch (Exception e) {
            LOGGER.error("", e);
            return 0L;
        }
    }

    /**
     * 添加一个指定的值到缓存中.
     *
     * @param type  类型
     * @param key   键
     * @param value 值
     */
    @Override
    public void putInCache(String type, String key, String value) {
        putInCache(type, key, value, REF_SECONDS);
    }

    /**
     * 删除缓存
     *
     * @param type 类型
     * @param key  键
     * @return 删除结果
     */
    @Override
    public Long deleteCache(final String type, final String key) {
        return new Executor<Long>(jedisPool) {

            @Override
            Long execute() {
                return jedis.del(getCacheName(type, key));
            }
        }.getResult();
    }

    /**
     * 改变存储计数
     *
     * @param type  类型
     * @param key   键
     * @param value 值
     * @return 缓存结果
     */
    @Override
    public long incrCounterCache(final String type, final String key, final long value) {
        return new Executor<Long>(jedisPool) {

            @Override
            Long execute() {
                long ret = 0;
                try {
                    if (value >= 0) {
                        ret = jedis.incrBy(getCacheName(type, key), Math.abs(value));
                    } else {
                        ret = jedis.decrBy(getCacheName(type, key), Math.abs(value));
                    }
                } catch (Exception e) {
                    LOGGER.error("cache {} error", getCacheName(type, key), e);
                }
                return ret;
            }

        }.getResult();
    }

    /**
     * 得到值的二进制数组，如果不存在返回null
     *
     * @param type 前缀
     * @param key  键
     * @return byte[] 查询结果
     */
    @Override
    public byte[] getObject(final String type, final String key) {
        return new Executor<byte[]>(jedisPool) {

            @Override
            byte[] execute() {
                try {
                    byte[] v = jedis.get(getCacheName(type, key));
                    if (v != null) {
                        return v;
                    }
                } catch (Exception e) {
                    LOGGER.error("cache {} error", getCacheName(type, key), e);
                }
                return null;
            }

        }.getResult();
    }

    /**
     * 得到值的字符串，如果不存在返回null
     *
     * @param type 前缀
     * @param key  键
     * @return 查询结果字符串
     */
    @Override
    public String getString(final String type, final String key) {
        byte[] bytes = getObject(type, key);
        if (bytes == null) {
            return null;
        } else {
            return new String(bytes);
        }
    }


    /* ======================================Hash====================================== */


    /**
     * @param key
     * @param pattern
     * @param cursor
     * @return
     */
    public Map<String, List> hscan(String key, String pattern, String cursor) {
        return new Executor<Map<String, List>>(jedisPool) {
            @Override
            Map<String, List> execute() {
                ScanResult<Map.Entry<String, String>> scanResult = jedis.hscan(key, cursor, new ScanParams() {{
                    match(pattern);
                    count(10000);
                }});
                return new HashMap<String, List>() {{
                    put(scanResult.getCursor(), scanResult.getResult());
                }};
            }
        }.getResult();
    }


    public Map<String, Map<String, String>> hmgetWithKey(List<String> keys) {
        return new Executor<Map<String, Map<String, String>>>(jedisPool) {
            @Override
            Map<String, Map<String, String>> execute() {
                // prepare
                final Map<String, Response<Map<String, String>>> response = new HashMap<>(keys.size());
                Pipeline pipeline = jedis.pipelined();
                keys.forEach((key) -> response.put(key, pipeline.hgetAll(key)));
                pipeline.sync();

                // get result
                final Map<String, Map<String, String>> result = new HashMap<>();
                response.forEach((k, v) -> result.put(k, v.get()));

                return result;
            }
        }.getResult();
    }


    /**
     * @param keys
     * @return
     */
    public List<Object> hmget(List<String> keys) {
        return new Executor<List<Object>>(jedisPool) {
            @Override
            List<Object> execute() {
                Pipeline pipeline = jedis.pipelined();
                keys.forEach((key) -> pipeline.hgetAll(key));
                return pipeline.syncAndReturnAll();
            }
        }.getResult();
    }

    /**
     * 查询执行器
     *
     * @param <T>
     */
    abstract class Executor<T> {

        /**
         * jedis
         */
        Jedis jedis;

        /**
         * jedis连接池
         */
        private JedisPool jedisPool;


        public Executor(JedisPool jedisPool) {
            this.jedisPool = jedisPool;
            jedis = this.jedisPool.getResource();
            jedis.select(slot);
        }

        /**
         * 回调
         *
         * @return 执行结果
         */
        abstract T execute();

        /**
         * 调用{@link #execute()}并返回执行结果
         * 它保证在执行{@link #execute()}之后释放数据源returnResource(jedis)
         *
         * @return 执行结果
         */
        public T getResult() {
            T result;
            try {
                result = execute();
            } catch (Throwable e) {
                throw new RuntimeException("Redis execute exception", e);
            } finally {
                if (jedis != null) {
                    jedis.close();
                }
            }
            return result;
        }
    }
}

