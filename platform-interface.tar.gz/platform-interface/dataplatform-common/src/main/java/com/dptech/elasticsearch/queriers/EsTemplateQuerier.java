package com.dptech.elasticsearch.queriers;

import com.dptech.elasticsearch.client.EsRestClient;
import com.dptech.elasticsearch.exception.EsException;
import com.dptech.elasticsearch.tempate.entity.ConfigDescriptor;
import com.dptech.util.ConfigUtils;
import com.dptech.util.IStringUtils;
import com.dptech.util.ObjectUtils;
import com.dptech.util.dynamic.AutoLoadClasser;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.dom4j.DocumentException;
import org.elasticsearch.client.Response;

import java.io.File;
import java.io.IOException;
import java.util.*;


/**
 * @author jelly * @date 2018-07-03 17:04
 * @ClassName: EsTemplateQuerier
 * @Description: TODO
 */
public class EsTemplateQuerier extends EsQuerier {

    public EsTemplateQuerier() {
    }

    /**
     * 在配置中获取host
     *
     * @param tempateFileName
     */
    public EsTemplateQuerier(String tempateFileName) {
        this(ConfigUtils.getString("es_rest_hosts", "localhost:9200"), tempateFileName);
    }

    /**
     * 无密码访问
     *
     * @param httpHost
     * @param tempateFileName
     */
    public EsTemplateQuerier(String httpHost, String tempateFileName) {
        this(httpHost, tempateFileName, IStringUtils.EMPTY);
    }

    /**
     * 模版查询 - POST
     *
     * @param httpHost
     * @param tempateFileName
     * @param xpackIdentify
     */
    public EsTemplateQuerier(String httpHost, String tempateFileName, String xpackIdentify) {
        super(httpHost, tempateFileName, xpackIdentify);
    }

    /**
     * sync query
     *
     * @param rrm
     * @return
     * @throws EsException
     * @throws DocumentException
     */
    public String doQuery(Map<String, Object> rrm) throws EsException, DocumentException, IOException {
        final Map<String, ConfigDescriptor> esFileCache = AutoLoadClasser.esFileCache;
        ConfigDescriptor fd = esFileCache.get(this.getTempateFileName());
        String indexName = fd.getIndexName();
        String indexType = fd.getIndexType();
        String fields = fd.getFields();

        if (IStringUtils.isEmpty(indexName) || IStringUtils.isEmpty(indexType) || IStringUtils.isEmpty(fields))
            throw new EsException("undefined：[indexName,indexType,fields]");

        String tempString = fd.getQueryTemplate();
        if (IStringUtils.isEmpty(tempString))
            throw new EsException("the query template cannot be empty.");

        // check indexName-high_risk_${date}
        Object indexNameObject = rrm.get("indexName");
        if (!ObjectUtils.isNull(indexNameObject)) indexName = assignIndexName(indexName, indexNameObject.toString());

        tempString = assign(rrm, tempString);

        return query(indexName, indexType, tempString);
    }

    public String query(String indexName, String indexType, String tempString) throws EsException, IOException {
        EsRestClient esRestClient = new EsRestClient(this.getHttpHost(), this.getXpackIdentify()).init(null);
        try {
            Response response = esRestClient.getRestClient().performRequest("POST", File.separator + indexName + File.separator + indexType + File.separator + "_search", Collections.singletonMap("pretty", "true"), new NStringEntity(tempString, ContentType.APPLICATION_JSON));

            switch (response.getStatusLine().getStatusCode()) {
                case 200:
                case 201:
                    return EntityUtils.toString(response.getEntity());
                default:
                    return IStringUtils.EMPTY;
            }
        } finally {
            esRestClient.close();
        }
    }

}
