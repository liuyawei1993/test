package com.dptech.hbase;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.List;
import java.util.Map;

/**
 * @author jelly * @date 2019-09-08 20:38
 * @ClassName: PhoenixClient
 * @Description: TODO
 */
public final class PhoenixClient {

    private DruidDataSource druidDataSource;

    public PhoenixClient(String url) {
        druidDataSource = new PhoenixDataSourece(url).getDataSource();
    }

    public PhoenixClient(String url, String password) {
        druidDataSource = new PhoenixDataSourece(url, password).getDataSource();
    }

    /**
     * @param sqlString
     * @param param
     * @return
     * @throws SQLException
     */
    public int exec(String sqlString, Object... param) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        return runner.execute(sqlString, param);
    }

    // insert
    public void insert(String sqlString) throws SQLException {
        try {
            QueryRunner runner = new QueryRunner(druidDataSource);
            runner.insert(sqlString, new MapHandler());
        } catch (SQLException e) {
            if (!(e.getNextException() instanceof SQLFeatureNotSupportedException))
                throw new SQLException(e);
        }
    }

    // batch insert
    public void batchInsert(String sqlString, Object[][] params) throws SQLException {
        try {
            QueryRunner runner = new QueryRunner(druidDataSource);
            runner.insertBatch(sqlString, new MapHandler(), params);
        } catch (SQLException e) {
            if (!(e.getNextException() instanceof SQLFeatureNotSupportedException))
                throw new SQLException(e);
        }
    }

    // update
    public int update(String sqlString) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        return runner.update(sqlString);
    }

    // batch update
    public int[] batchUpdate(String sqlString, Object[][] params) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        return runner.batch(sqlString, params);
    }

    // delete
    public int delete(String sqlString) throws SQLException {
        return update(sqlString);
    }

    // batch delete
    public int[] batchDelete(String sqlString, Object[][] params) throws SQLException {
        return batchUpdate(sqlString, params);
    }

    // search
    public <T> T query(String sqlString, Class<T> result) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        ResultSetHandler<T> handler = new BeanHandler<>(result);
        return runner.query(sqlString, handler);
    }

    public List<Map<String, Object>> query(String sqlString) throws SQLException {
        QueryRunner runner = new QueryRunner(druidDataSource);
        return runner.query(sqlString, new MapListHandler());
    }
}