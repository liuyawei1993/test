package com.dptech.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;


import java.util.*;

/**
 * @author jelly * @date 2018-07-10 16:52
 * @ClassName: ResultExtractor
 * @Description: TODO
 */
public class EsResultExtractor {
    private Result result = new Result();
    private List<Map<String, Object>> parentBucketsList = new ArrayList<>();

    public Result getResult() {
        return this.result;
    }

    public List<Map<String, Object>> getParentBucketsMap() {
        return parentBucketsList;
    }

    /**
     * @param source
     * @return
     */
    public EsResultExtractor extract(String source) {
        JSONObject data = JSON.parseObject(source);
        setHits(data);
        setAggs(data);
        setParentBuckets(this.getResult().getAggs());
        return this;
    }

    // set aggs
    private void setAggs(JSONObject data) {
        result.setAggs(getAggs(data));
    }

    // get aggs
    public String getAggs(JSONObject data) {
        Object aggs = data.get("aggregations");
        return !ObjectUtils.isNull(aggs) ? aggs.toString() : IStringUtils.EMPTY;
    }

    // set hits
    private void setHits(JSONObject data) {
        Map<String, Object> hits = getHits(data);
        result.setTotal((Long) hits.get("total"));
        result.setHits((List<Map<String, Object>>) hits.get("hitsList"));
    }

    // get hits
    public Map<String, Object> getHits(JSONObject data) {
        final List<Map<String, Object>> hitResultList = new ArrayList<>();
        Object hitsObject = data.get("hits");
        if (!ObjectUtils.isNull(hitsObject)) {
            JSONObject hitsData = JSON.parseObject(hitsObject.toString());
            Object hitsHitsObject = hitsData.get("hits");
            if (!ObjectUtils.isNull(hitsHitsObject)) {
                List<Hit> hits = JSON.parseArray(hitsHitsObject.toString(), Hit.class);
                hits.forEach((hit) -> {
                    Map<String, Object> source = hit.get_source();
                    source.put("id", hit.get_id());
                    hitResultList.add(source);
                });
            }
        }

        return new HashMap<String, Object>() {{
            Object total = data.get("total");
            put("total", ObjectUtils.isNull(total) ? 0l : Long.parseLong(total.toString()));
            put("hitsList", hitResultList);
        }};
    }

    // set parent buckets
    private void setParentBuckets(String aggsJson) {
        this.parentBucketsList = getParentBucketsList(aggsJson);
    }

    // get parent buckets
    public List<Map<String, Object>> getParentBucketsList(String aggsJson) {
        if (StringUtils.isNotEmpty(aggsJson)) {
            return getParentBucketsList((JSONObject) EsUtils.getFirstOrNull(JSON.parseObject(aggsJson)));
        }
        return Collections.emptyList();
    }

    public List<Map<String, Object>> getParentBucketsList(JSONObject data) {
        return (List) JSON.parseArray(data.getString("buckets"));
    }

    public class Result {
        private Long total;
        private List<Map<String, Object>> hits;
        private String aggs;

        public String getAggs() {
            return aggs;
        }

        public void setAggs(String aggs) {
            this.aggs = aggs;
        }

        public Long getTotal() {
            return total;
        }

        public void setTotal(Long total) {
            this.total = total;
        }

        public List<Map<String, Object>> getHits() {
            return hits;
        }

        public void setHits(List<Map<String, Object>> hits) {
            this.hits = hits;
        }
    }

    private static class Hit {
        private String _index;
        private String _type;
        private String _id;
        private String _score;
        private Map<String, Object> _source;

        public String get_index() {
            return _index;
        }

        public void set_index(String _index) {
            this._index = _index;
        }

        public String get_type() {
            return _type;
        }

        public void set_type(String _type) {
            this._type = _type;
        }

        public String get_id() {
            return _id;
        }

        public void set_id(String _id) {
            this._id = _id;
        }

        public String get_score() {
            return _score;
        }

        public void set_score(String _score) {
            this._score = _score;
        }

        public Map<String, Object> get_source() {
            return _source;
        }

        public void set_source(Map<String, Object> _source) {
            this._source = _source;
        }
    }
}