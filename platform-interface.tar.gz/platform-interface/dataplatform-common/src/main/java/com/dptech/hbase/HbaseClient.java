package com.dptech.hbase;

import com.dptech.util.ConfigUtils;
import com.dptech.util.MD5Utils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * hbase工具类，这里并没有使用单例模式，是为了上层应用拥有同时操作不同hbase集群的能力
 *
 * @author jelly.wang
 * @create 2018/01/09
 */
public class HbaseClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(HbaseClient.class);
    // scan时，默认最多返回行数
    private static final Integer LIMIT = 1000;
    private Connection connection;

    private final String ZK_SERVERS_KEY = "hbase.zookeeper.quorum";
    private final String ZK_PORT_KEY = "hbase.zookeeper.property.clientPort";
    private final String ZK_ZNODE_KEY = "zookeeper.znode.parent";

    /**
     * 默认情况下，配置直接从配置文件中读取
     */
    public HbaseClient() {
        String zkServers = ConfigUtils.getString(ZK_SERVERS_KEY, "localhost");
        String zkPort = ConfigUtils.getString(ZK_PORT_KEY, "2181");
        String znode = ConfigUtils.getString(ZK_ZNODE_KEY, "/hbase");
        init(zkServers, zkPort, znode, null);
    }

    /**
     * @param zkServers
     * @param zkPort
     */
    public HbaseClient(String zkServers, String zkPort, String znode) {
        init(zkServers, zkPort, znode, null);
    }

    /**
     * @param zkServers
     * @param zkPort
     * @param threadpoolSize 线程池大小
     */
    public HbaseClient(String zkServers, String zkPort, String znode, Integer threadpoolSize) {
        init(zkServers, zkPort, znode, threadpoolSize);
    }


    private void init(String zkServers, String zkPort, String znode, Integer threadpoolSize) {
        Configuration conf = HBaseConfiguration.create();
        conf.set(ZK_SERVERS_KEY, zkServers);
        conf.set(ZK_PORT_KEY, zkPort);
        conf.set(ZK_ZNODE_KEY, znode);
        ExecutorService pool = null;
        if (threadpoolSize != null && threadpoolSize > 0) {
            pool = Executors.newScheduledThreadPool(threadpoolSize);
        }

        try {
            connection = ConnectionFactory.createConnection(conf, pool);
        } catch (IOException e) {
            LOGGER.error("hbase init faild ", e);
        }
    }

    /**
     * 获取key/value信息
     *
     * @param tableName
     * @param rowkey
     * @return
     * @throws IOException
     */
    public Map<String, byte[]> getRowMap(String tableName, byte[] rowkey) throws IOException {
        Result result = getRecord(tableName, rowkey);
        return resultToMap(result);
    }

    /**
     * 向hbase查询指定列的值
     * @param tableName 表名
     * @param rowkey  操作hbase的rowkey类
     * @param key 查询字段
     */
    public String getValue(String tableName, String rowkey, String key, String type) {
        Table table = null;
        try {
            table = connection.getTable(TableName.valueOf(tableName));
        } catch (IOException e1) {
            LOGGER.error("Failed to get tableName {} information.",tableName);
            e1.printStackTrace();
        }
        Get get = new Get(Bytes.toBytes(rowkey));
        get.addFamily(Bytes.toBytes("t"));
        Result result = null;
        try {
            result = table.get(get);
        } catch (IOException e) {
            LOGGER.error("Failed to get tableName {} result.");
            e.printStackTrace();
            return null;
        }
        if(result == null || result.getRow() == null) {
            return null;
        }
        NavigableMap<byte[], byte[]> cols = result.getFamilyMap(Bytes.toBytes("t"));
        for (Map.Entry<byte[], byte[]> cell : cols.entrySet()) {
            if(null == type) {
                if(key.equals(Bytes.toString(cell.getKey()))) {
                    return Bytes.toString(cell.getValue());
                }
            }else if("int".equals(type)) {
                if(key.equals(Bytes.toString(cell.getKey()))) {
                    return String.valueOf(Bytes.toInt(cell.getValue()));
                }
            }
        }
        return null;
    }


    /**
     * 获取一行数据
     *
     * @param tableName
     * @param rowkey
     * @return
     * @throws IOException
     */
    public Result getRecord(String tableName, byte[] rowkey) throws IOException {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            Get get = new Get(rowkey);
            Result result = table.get(get);
            return result;
        }
    }

    /**
     * 扫描，返回多行key/value信息
     *
     * @param tableName
     * @param startRow
     * @param stopRow
     * @param limit
     * @return
     * @throws IOException
     */
    public Map<byte[], Map<String, byte[]>> scanRowsMap(String tableName, byte[] startRow, byte[] stopRow, Integer limit) throws IOException {
        final Map<byte[], Map<String, byte[]>> map = new HashMap<>();
        List<Result> results = scanRecords(tableName, startRow, stopRow, limit);
        results.forEach((result) -> map.put(result.getRow(), resultToMap(result)));
        return map;
    }

    /**
     * 扫描，返回多行数据
     *
     * @param tableName
     * @param startRow
     * @param stopRow
     * @param limit
     * @return
     * @throws IOException
     */
    public List<Result> scanRecords(String tableName, byte[] startRow, byte[] stopRow, Integer limit) throws IOException {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            final List<Result> results = new ArrayList<>();
            Scan scan = new Scan();
            if (null != startRow) scan.setStartRow(startRow);
            if (null != stopRow) scan.setStopRow(stopRow);
            if (null == limit) limit = LIMIT;
            scan.setMaxResultSize(limit);

            ResultScanner rs = table.getScanner(scan);
            rs.forEach((result) -> {
                results.add(result);
                /*if (results.size() >= limit) {
                    break;
                }*/
            });
            return results;
        }
    }

    /**
     * 前缀扫描，返回多行key/value信息
     *
     * @param tableName
     * @param prefix
     * @param limit
     * @return
     * @throws IOException
     */
    public Map<byte[], Map<String, byte[]>> scanRowsMapByPrefix(String tableName, byte[] prefix, Integer limit) throws IOException {
        Map<byte[], Map<String, byte[]>> map = new HashMap<>();
        List<Result> results = scanRecordsByPrefix(tableName, prefix, limit);
        results.forEach((result) -> map.put(result.getRow(), resultToMap(result)));
        return map;
    }

    /**
     * 前缀扫描，返回多行数据
     *
     * @param tableName
     * @param prefix
     * @param limit
     * @return
     * @throws IOException
     */
    public List<Result> scanRecordsByPrefix(String tableName, byte[] prefix, Integer limit) throws IOException {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            final List<Result> results = new ArrayList<>();
            Scan scan = new Scan();
            scan.setRowPrefixFilter(prefix);
            scan.setMaxResultSize(limit);

            ResultScanner rs = table.getScanner(scan);
            rs.forEach((result) -> {
                results.add(result);
                /*if (results.size() >= limit) {
                    break;
                }*/
            });
            return results;
        }
    }

    /**
     * 根据rowkeys批量获取
     *
     * @param tableName
     * @param rowkeys
     * @return
     * @throws IOException
     */
    public Result[] getByRowkeys(String tableName, List<String> rowkeys) throws IOException {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            final List<Get> getList = new ArrayList();
            rowkeys.forEach((rowkey) -> {
                getList.add(new Get(Bytes.toBytes(rowkey)));
            });
            return table.get(getList);
        }
    }


    /**
     * 分页查询
     *
     * @param tableName
     * @param pageSize
     * @param startRowKey
     * @param endRowKey
     * @param otherParams [family,[fieldName,value]]
     * @return
     * @throws IOException 注意不设置前缀，则反向无结果；
     *                     scan.setRowPrefixFilter(prefix.getBytes());
     */
    public Map<String, Result> scanRecordsByPrefixFilterPage(String tableName, int pageSize, String startRowKey, String endRowKey, Map<String, String[]> otherParams, boolean reverse) throws IOException {
        if (hasNull4Parameters(tableName, pageSize, startRowKey, endRowKey)) return null;
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            final Scan scan = new Scan();
            // rowkey 范围
            scan.setStartRow(Bytes.toBytes(startRowKey));
            scan.setStopRow(Bytes.toBytes(endRowKey));
            // 最新版本数据
            scan.setMaxVersions();
            // 反向查询
            scan.setReversed(reverse);

            final FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);
            // 附加字段域参数
            if (otherParams != null)
                otherParams.forEach((k, v) -> {
                    filterList.addFilter(new SingleColumnValueFilter(Bytes.toBytes(k), Bytes.toBytes(v[0]), CompareFilter.CompareOp.EQUAL, Bytes.toBytes(v[1])));
                });
            filterList.addFilter(new PageFilter(pageSize));
            // 设置过滤条件
            scan.setFilter(filterList);

            ResultScanner rs = table.getScanner(scan);
            final Map<String, Result> map = new LinkedHashMap<>();
            for (Result result : rs) {
                map.put(Bytes.toString(result.getRow()), result);
            }
            return map;
        }
    }

    /**
     * 删除数据
     *
     * @param tableName
     * @param rowkeys
     * @throws IOException
     */
    public void delete(String tableName, List<byte[]> rowkeys) throws IOException {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            final List<Delete> deletes = new ArrayList<>();
            rowkeys.forEach((rowKey) -> deletes.add(new Delete(rowKey)));
            table.delete(deletes);
        }
    }


    /**
     * 插入一行数据
     *
     * @param tableName
     * @param rowkey
     * @param columnFamily
     * @param qualifiers
     * @param values
     * @throws IOException
     */
    public void insertRecord(String tableName, byte[] rowkey, String columnFamily, List<String> qualifiers, List<byte[]> values) throws IOException {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            Put put = new Put(rowkey);
            for (int i = 0; i < qualifiers.size(); i++) {
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifiers.get(i)), values.get(i));
            }
            table.put(put);
        }
    }

    /**
     * 插入一个单元
     *
     * @param tableName
     * @param rowkey
     * @param columnFamily
     * @param qualifier
     * @param value
     * @throws IOException
     */
    public void insertCell(String tableName, byte[] rowkey, String columnFamily, String qualifier, byte[] value) throws IOException {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            Put put = new Put(rowkey);
            put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier), value);
            table.put(put);
        }
    }

    /**
     * 批量插入
     *
     * @param tableName
     * @param puts
     * @throws Exception
     */
    public void inserts(String tableName, List<?> puts) throws Exception {
        try (Table table = connection.getTable(TableName.valueOf(tableName))) {
            table.put((List<Put>) puts);
        }
    }

    /**
     * 释放资源
     */
    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (IOException e) {
                LOGGER.error(e.getMessage(), e);
            }
        }
    }

    /**
     * 获取连接
     *
     * @return
     */
    public Connection open() {
        return connection;
    }

    /**
     * 把Result转化成key/value对
     *
     * @param result
     * @return
     */
    private Map<String, byte[]> resultToMap(Result result) {
        Map<String, byte[]> map = new HashMap<>();
        for (Cell cell : result.rawCells()) {
            map.put(Bytes.toString(CellUtil.cloneQualifier(cell)), CellUtil.cloneValue(cell));
        }
        return map;
    }

    /**
     * Object 转换成byte[]
     *
     * @param value 需要转换的对象
     * @return byte[]数组
     */
    public byte[] stringToByte(Object value) {
        if (null != value && StringUtils.isNotBlank(String.valueOf(value))) {
            return Bytes.toBytes(String.valueOf(value));
        }
        return new byte[0];
    }

    /**
     * 获取表名
     *
     * @param prefix 前缀
     * @param date   拼接的数据
     * @return prefix_date
     */
    public String getTableName(String prefix, String date) {
        return prefix + "_" + date;
    }

    /**
     * 预分区规则
     *
     * @param startKey   起始rowkey
     * @param endKey     endrowkey
     * @param numRegions 分区数量
     * @return 预分区之后的二维数组
     */
    public byte[][] getHexSplits(String startKey, String endKey, int numRegions) {
        byte[][] splits = new byte[numRegions - 1][];

        BigInteger lowestKey = new BigInteger(startKey);
        BigInteger highestKey = new BigInteger(endKey);
        BigInteger range = highestKey.subtract(lowestKey);
        BigInteger regionIncrement = range.divide(BigInteger.valueOf(numRegions));
        //lowestKey = lowestKey.add(regionIncrement);

        for (int i = 0; i < numRegions - 1; i++) {
            BigInteger key = lowestKey.add(regionIncrement.multiply(BigInteger.valueOf(i)));
            byte[] b = String.valueOf(key).getBytes();
            splits[i] = b;
        }
        return splits;
    }

    /**
     * 给对象赋值
     *
     * @param r
     * @param o
     */
    @Deprecated
    public void setObjectPropertiesValue(Result r, Object o) throws
            IllegalAccessException, NoSuchMethodException, InvocationTargetException, UnsupportedEncodingException {
        if (hasNull4Parameters(r, o)) return;
        final List<Cell> listCells = r.listCells();
        final Class<?> aClass = o.getClass();
        doSetValues(o, listCells, aClass);
    }

    /**
     * 给对象赋值，包括父类
     *
     * @param r
     * @param o
     * @throws IllegalAccessException
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @throws UnsupportedEncodingException
     */
    public void setSuperObjectPropertiesValue(Result r, Object o) throws
            IllegalAccessException, NoSuchMethodException, InvocationTargetException, UnsupportedEncodingException {
        if (hasNull4Parameters(r, o)) return;
        Class<?> aClass = o.getClass();
        for (; aClass != Object.class; aClass = aClass.getSuperclass()) {
            doSetValues(o, r.listCells(), aClass);
        }
    }

    private void doSetValues(Object o, List<Cell> listCells, Class<?> aClass) throws UnsupportedEncodingException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        if (listCells == null) return;

        final Field[] fields = aClass.getDeclaredFields();
        for (Field f : fields) {
            f.setAccessible(true);
            final String fieldType = f.getGenericType().toString();
            for (Cell cell : listCells) {
                final String cellName = new String(CellUtil.cloneQualifier(cell));
                final String cellValue = new String(CellUtil.cloneValue(cell), "UTF-8").trim();
                if (f.getName().equals(cellName)) {
                    final String methodName = "set" + cellName.substring(0, 1).toUpperCase() + cellName.substring(1);
                    Method method;
                    if (fieldType.endsWith("String")) {
                        method = aClass.getMethod(methodName, String.class);
                        method.invoke(o, cellValue);
                    } else if (fieldType.endsWith("Short")) {
                        method = aClass.getMethod(methodName, Short.class);
                        if (NumberUtils.isNumber(cellValue)) {
                            method.invoke(o, Short.parseShort(cellValue));
                        }
                    } else if (fieldType.endsWith("Integer")) {
                        method = aClass.getMethod(methodName, Integer.class);
                        if (NumberUtils.isNumber(cellValue)) {
                            method.invoke(o, Integer.parseInt(cellValue));
                        }
                    } else if (fieldType.endsWith("Long")) {
                        method = aClass.getMethod(methodName, Long.class);
                        if (NumberUtils.isNumber(cellValue)) {
                            method.invoke(o, Long.parseLong(cellValue));
                        }
                    } else if (fieldType.endsWith("Float")) {
                        method = aClass.getMethod(methodName, Float.class);
                        if (NumberUtils.isNumber(cellValue)) {
                            method.invoke(o, Float.parseFloat(cellValue));
                        }
                    } else if (fieldType.endsWith("Double")) {
                        method = aClass.getMethod(methodName, Double.class);
                        if (NumberUtils.isNumber(cellValue)) {
                            method.invoke(o, Double.parseDouble(cellValue));
                        }
                    } else if (fieldType.endsWith("Boolean")) {
                        method = aClass.getMethod(methodName, Boolean.class);
                        if (StringUtils.isNotEmpty(cellValue)) {
                            switch (cellValue.toLowerCase()) {
                                case "true":
                                case "false":
                                    method.invoke(o, Boolean.parseBoolean(cellValue));
                                    break;
                            }
                        }
                    } else if (fieldType.endsWith("Byte")) {
                        method = aClass.getMethod(methodName, Byte.class);
                        method.invoke(o, Byte.parseByte(cellValue));
                    }
                }
            }
        }
    }

    /**
     * 检查参数是否有空值
     *
     * @param objs
     * @return boolean
     */
    private boolean hasNull4Parameters(Object... objs) {
        boolean result = false;
        if (null == objs) return !result;
        for (Object obj : objs) {
            if (obj instanceof String) {
                result = StringUtils.isEmpty(obj.toString());
            } else {
                result = null == obj;
            }
            if (result) {
                break;
            }
        }
        return result;
    }


    /**
     * 获取散列rowkey
     *
     * @param digit
     * @param key
     * @return
     */
    public String getHashRowkey(int digit, final String key) {
        if (StringUtils.isEmpty(key)) return null;
        final String md5 = MD5Utils.getMD5(key);
        int len = md5.length();
        if (digit > len) digit = len;
        return md5.substring(0, digit) + key;
    }

    /**
     * 向hbase插入一条数据
     * @param tableName 表名
     * @param key  操作hbase的rowkey类
     * @param value 一个map集合
     */
    public void insertRecord(String tableName, String key, Map<String, Object>value) {
        try {
            Table table = connection.getTable(TableName.valueOf(tableName));
            Put put = new Put(Bytes.toBytes(key));
            for (Map.Entry<String, Object> entry : value.entrySet()) {
                if(entry.getValue() instanceof Integer) {
                    put.addColumn(Bytes.toBytes("t"), Bytes.toBytes(entry.getKey()), Bytes.toBytes(Integer.valueOf(entry.getValue().toString())));
                }else {
                    put.addColumn(Bytes.toBytes("t"), Bytes.toBytes(entry.getKey()), Bytes.toBytes(entry.getValue().toString()));
                }
            }
            table.put(put);
        } catch (IOException e) {
            LOGGER.error("Insert data failed! value = {}",value);
            e.printStackTrace();
        }
    }
}