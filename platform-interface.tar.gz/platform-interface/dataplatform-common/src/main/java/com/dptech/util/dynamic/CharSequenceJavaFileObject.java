package com.dptech.util.dynamic;

import javax.tools.SimpleJavaFileObject;
import java.net.URI;

/**
 * @ClassName: CharSequenceJavaFileObject
 * @Description: TODO
 * @author jelly.wang
 * @date 2017年2月18日
 */
public class CharSequenceJavaFileObject extends SimpleJavaFileObject {

	private CharSequence content;

	public CharSequenceJavaFileObject(String className, CharSequence content) {
		super(URI.create("string:///" + className.replace('.', '/') + Kind.SOURCE.extension), Kind.SOURCE);
		this.content = content;
	}

	@Override
	public CharSequence getCharContent(boolean ignoreEncodingErrors) {
		return content;
	}
}