package com.dptech.elasticsearch.common;

/**
 * @author jelly * @date 2018-07-09 23:06
 * @ClassName: EsConstants
 * @Description: TODO
 */
public class EsConstants {
    public final static String GD_ENTIRY_PACKAGE = "com.dptech.elasticsearch.dyentitys";
    public final static String EMPTY_STRING = "";
    public final static String SLASH = "/";
    // template 操作成功响应码 200
    public final static Integer SUCCESS_RESPONSE_FLAG_1 = 200;
    // template 创建文档成功响应码 201
    public final static Integer SUCCESS_RESPONSE_FLAG_2 = 201;
    // 索引名称
    public final static String INDEX_NAME = "INDEX_NAME";
    // 数据类型
    public final static String DATA_TYPE = "DATA_TYPE";
    //主键
    public final static String PRIMARY_KEY = "PRIMARY_KEY";
    // EsTransportClient端口
    public final static Integer ES_TANS_PORT = 9300;

    //http访问类型
    public enum HttpRequestType {
        GET {
            @Override
            public String toString() {
                return "get";
            }
        },
        POST {
            @Override
            public String toString() {
                return "post";
            }
        },
        DELETE {
            @Override
            public String toString() {
                return "delete";
            }
        },
        PUT {
            @Override
            public String toString() {
                return "put";
            }
        }
    }

    /**
     * 请求协议
     */
    public enum RequestProtocol {
        HTTP {
            @Override
            public String toString() {
                return "http://";
            }
        },
        HTTPS {
            @Override
            public String toString() {
                return "https://";
            }
        }
    }

    // 模版解析常量
    public final static String START_TAG = "<";
    public final static String START_IF_TAG = "<if";
    public final static String END_TAG = "/>";
    public final static String END_ENDIF_TAG = "<endif/>";
    public final static String MARK = "#MARK_";

    public final static String POUND_KEY = "#";
}
