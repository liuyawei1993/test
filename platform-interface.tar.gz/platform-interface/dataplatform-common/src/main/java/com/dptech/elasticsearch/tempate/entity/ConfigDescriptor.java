package com.dptech.elasticsearch.tempate.entity;

/**
 * Created by jelly.wang on 2017/2/21.
 * template 动态查询模版配置文件属性映射类
 */

public class ConfigDescriptor {
    // 查询模版
    private String queryTemplate;
    // 索引名称
    private String indexName;
    // 索引类型
    private String indexType;
    // 返回字段
    private String fields;

    public String getQueryTemplate() {
        return queryTemplate;
    }

    public void setQueryTemplate(String queryTemplate) {
        this.queryTemplate = queryTemplate;
    }

    public String getIndexName() {
        return indexName;
    }

    public void setIndexName(String indexName) {
        this.indexName = indexName;
    }

    public String getIndexType() {
        return indexType;
    }

    public void setIndexType(String indexType) {
        this.indexType = indexType;
    }

    public String getFields() {
        return fields;
    }

    public void setFields(String fields) {
        this.fields = fields;
    }

    @Override
    public String toString() {
        return "FileDescriptor4Es{" +
                "queryTemplete='" + queryTemplate + '\'' +
                ", indexName='" + indexName + '\'' +
                ", indexType='" + indexType + '\'' +
                ", fields='" + fields + '\'' +
                '}';
    }
}
