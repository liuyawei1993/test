package com.dptech.elasticsearch.exception;

/**
 * @author jelly.wang
 * @ClassName: EsException
 * @Description:
 * @date 2017/12/14
 */
public class EsException extends Exception {

    public EsException(String message) {
        super(message);
    }

    public EsException(String message, Throwable cause) {
        super(message, cause);
    }
}
