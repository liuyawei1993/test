package com.dptech.redis;

/**
 * @author jelly * @date 2018-07-10 20:38
 * @ClassName: RedisLocalClient
 * @Description: TODO
 */
interface IRedisCache {

    /**
     * 无时限缓存
     *
     * @param type
     * @param key
     * @param value
     */
    void putNoTimeInCache(String type, String key, String value);

    /**
     * 删除
     *
     * @param key 匹配的key
     * @return 删除成功的条数
     */
    Long delKey(final String type, final String key);

    /**
     * 得到值的字符串，如果不存在返回null
     *
     * @param type 前缀
     * @param key  键
     */
    String getString(final String type, final String key);

    /**
     * 写入Cache
     *
     * @param type
     * @param key
     * @param value
     * @param seconds
     */
    String putInCache(final String type, final String key, final String value, final int seconds);

    /**
     * 改变存储计数
     *
     * @param type
     * @param key
     * @param value
     */
    long incrCounterCache(final String type, final String key, final long value);

    /**
     * 删除缓存
     *
     * @param type
     * @param key
     */
    Long deleteCache(final String type, final String key);

    /**
     * @param type
     * @param key
     * @return
     */
    String getStrCacheName(String type, String key);

    /**
     * 将 key 的值设为 value ，当且仅当 key 不存在。若给定的 key 已经存在，则 setStringIfNotExists
     * 不做任何动作。 时间复杂度：O(1)
     *
     * @param key   key
     * @param value string value
     * @return 设置成功，返回 1 。设置失败，返回 0 。
     */
    Long setStringIfNotExists(final String key, final String value);

    /**
     * 添加一个指定的值到缓存中.
     *
     * @param key
     * @param value
     * @return
     */
    void putInCache(String type, String key, String value);

    /**
     * 根据Key获取具体数据
     *
     * @param type
     * @param key
     * @return
     */
    byte[] getObject(final String type, final String key);
}
