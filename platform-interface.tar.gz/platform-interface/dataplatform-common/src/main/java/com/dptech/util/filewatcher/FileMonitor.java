package com.dptech.util.filewatcher;

import com.dptech.util.dynamic.AutoLoadClasser;
import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

/**
 * @author jelly.wang
 * @ClassName: FileMonitor
 * @Description: TODO
 * @date 2017年2月18日
 */
public class FileMonitor {
    private FileAlterationMonitor monitor;
    private long intervalTime = 60 * 1000L;
    private final Logger LOG = LoggerFactory.getLogger(FileMonitor.class);
    private String filePath;

    public FileMonitor(String filePath) {
        this.filePath = filePath;
        monitor(filePath);
    }

    public FileMonitor(String filePath, long intervalTime) {
        this.intervalTime = intervalTime;
        this.filePath = filePath;
        monitor(filePath);
    }

    private void monitor(String filePath) {
        monitor = new FileAlterationMonitor(intervalTime);
        FileAlterationObserver observer = new FileAlterationObserver(new File(filePath));
        monitor.addObserver(observer);
        observer.addListener(new FileListener());
    }

    public void start() {
        try {
            monitor.start();
        } catch (Exception e) {
            LOG.error("FileMonitor start exception:", e);
        }
    }

    public void stop() {
        try {
            monitor.stop();
        } catch (Exception e) {
            LOG.error("FileMonitor stop exception:", e);
        }
    }

    private class FileListener implements FileAlterationListener {
        private final Logger logger = LoggerFactory.getLogger(FileListener.class);

        @Override
        public void onStart(FileAlterationObserver observer) {
        }

        @Override
        public void onStop(FileAlterationObserver observer) {
        }

        @Override
        public void onDirectoryCreate(File directory) {
            logger.info("Directory is Created.");
        }

        @Override
        public void onDirectoryChange(File directory) {
            logger.info("Directory is Changed.");
        }

        @Override
        public void onDirectoryDelete(File directory) {
            logger.info("Directory is Deleted.");
        }

        private static final String ES_RELOAD_EXCEPTION_STRING = "reload es dynamic query module exception：";

        @Override
        public void onFileCreate(File file) {
            try {
                AutoLoadClasser.reLoad(filePath);
            } catch (Exception e) {
                logger.error(ES_RELOAD_EXCEPTION_STRING, e);
            }
        }

        @Override
        public void onFileChange(File file) {
            try {
                AutoLoadClasser.reLoad(filePath);
            } catch (Exception e) {
                logger.error(ES_RELOAD_EXCEPTION_STRING, e);
            }
        }

        @Override
        public void onFileDelete(File file) {
            try {
                AutoLoadClasser.reLoad(filePath);
            } catch (Exception e) {
                logger.error(ES_RELOAD_EXCEPTION_STRING, e);
            }
        }
    }
}