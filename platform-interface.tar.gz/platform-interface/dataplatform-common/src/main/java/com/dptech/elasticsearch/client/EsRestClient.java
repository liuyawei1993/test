package com.dptech.elasticsearch.client;

import com.dptech.elasticsearch.exception.EsException;
import com.dptech.util.IStringUtils;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


public final class EsRestClient extends AbstractClient {
    private RestClient restClient;

    public RestClient getRestClient() {
        return restClient;
    }

    public EsRestClient(String hosts) {
        super(hosts);
    }

    public EsRestClient(String hosts, String xpackIdentify) {
        super(hosts, xpackIdentify);
    }

    @Override
    public EsRestClient init(Map<String, Object> params) throws EsException {
        //obtain HttpHost
        final List<HttpHost> httpHosts = new ArrayList<>();
        if (IStringUtils.isNotEmpty(this.getHosts())) {
            Arrays.asList(this.getHosts().split(",")).forEach((httpHost) -> {
                String[] splitHost = httpHost.split(":");
                httpHosts.add(new HttpHost(splitHost[0], Integer.valueOf(splitHost[1]), "http"));
            });

            RestClientBuilder restClientBuilder = RestClient.builder(httpHosts.toArray(new HttpHost[httpHosts.size()]));
            // basic authentication
            if (IStringUtils.isNotEmpty(this.getXpackIdentify())) {
                String[] userAndPassword = this.getXpackIdentify().split(":");
                final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                credentialsProvider.setCredentials(AuthScope.ANY,
                        new UsernamePasswordCredentials(userAndPassword[0], userAndPassword[1]));

                restClientBuilder.setHttpClientConfigCallback(httpClientBuilder -> {
                    httpClientBuilder.disableAuthCaching();
                    return httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                });
            }
            this.restClient = restClientBuilder.build();
            return this;
        }

        throw new EsException("RestClient initialization failed");
    }

    @Override
    public void close() throws IOException {
        if (null != this.restClient) {
            this.restClient.close();
        }
    }
}
