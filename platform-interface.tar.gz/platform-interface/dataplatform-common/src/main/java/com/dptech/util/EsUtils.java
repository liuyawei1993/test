package com.dptech.util;

import java.util.Map;

/**
 * @author jelly * @date 2018-07-10 20:38
 * @ClassName: ElasticsearchUtils
 * @Description: TODO
 */
public final class EsUtils {
    private EsUtils() {
    }

    /**
     * 获取map中的第一个值
     *
     * @param map
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V> V getFirstOrNull(Map<K, V> map) {
        V obj = null;
        for (Map.Entry<K, V> entry : map.entrySet()) {
            obj = entry.getValue();
            if (obj != null) {
                break;
            }
        }
        return obj;
    }
}
