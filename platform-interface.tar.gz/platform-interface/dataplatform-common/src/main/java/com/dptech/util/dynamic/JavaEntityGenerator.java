package com.dptech.util.dynamic;


import com.dptech.elasticsearch.common.EsConstants;
import com.dptech.util.IStringUtils;


/**
 * @author jelly.wang
 * @ClassName: JavaEntityGenerator
 * @Description: TODO
 * @date 2017年2月18日
 */
public class JavaEntityGenerator {

    public static Class<?> generate(String fileName, String fields)
            throws IllegalAccessException, InstantiationException {
        if (IStringUtils.isEmpty(fileName) || IStringUtils.isEmpty(fields)) {
            return null;
        }
        StringBuilder sb = new StringBuilder(
                "package " + EsConstants.GD_ENTIRY_PACKAGE + "; \n public class " + fileName + "{ \n");
        String[] fs = fields.split(",");
//		fs[fs.length-1] = "Long total";
        for (String f : fs) {
            // field
            sb.append("  public " + f + "; \n");
            // set
            String feildName = f.split(" ")[1];
            String feildType = f.split(" ")[0];
            sb.append("  public void set" + String.valueOf(feildName.charAt(0)).toUpperCase() + feildName.substring(1)
                    + "(" + feildType + " " + feildName + ") { this." + feildName + " = " + feildName + ";} \n");
            // get
            sb.append("  public " + feildType + " get" + String.valueOf(feildName.charAt(0)).toUpperCase()
                    + feildName.substring(1) + "() { return " + feildName + "; } \n");

        }
        sb.append("}");

        DynamicEngine de = DynamicEngine.getInstance();
        return de.javaCodeToClass(EsConstants.GD_ENTIRY_PACKAGE + "." + fileName, sb.toString());
    }
}
