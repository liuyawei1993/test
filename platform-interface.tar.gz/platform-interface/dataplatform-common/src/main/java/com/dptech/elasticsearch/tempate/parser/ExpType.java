package com.dptech.elasticsearch.tempate.parser;

/**
 * @author jelly.wang
 * @ClassName: ExpType
 * @Description:
 * @date 2017年1月12日
 */
public enum ExpType {
    FOR("for"), IF("if"),NONE("NONE");
    public String typeString;

    ExpType(String type) {
        this.typeString = type;
    }

    public static ExpType setExpType(String str) {
        final ExpType[] values = ExpType.values();
        for (ExpType et : values) {
            if (str.equals(et.typeString)) return et;
        }
        return NONE;
    }
}