package com.dptech.elasticsearch.index;

import com.alibaba.fastjson.JSON;
import com.dptech.elasticsearch.client.EsRestClient;
import com.dptech.elasticsearch.exception.EsException;
import com.dptech.util.ConfigUtils;
import com.dptech.util.IStringUtils;
import com.dptech.util.ObjectUtils;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/20 下午3:34
 * @description: TODO
 */
public class EsIndexer {
    private static final Logger LOGGER = LoggerFactory.getLogger(EsIndexer.class);
    // es restful 地址
    private String httpHost;
    // xpack用户名和密码
    private String xpackIdentify;
    private RestHighLevelClient client;

    public EsIndexer() {
        this(ConfigUtils.getString("es_rest_hosts", "localhost:9200"), IStringUtils.EMPTY);
    }

    public EsIndexer(String httpHost) {
        this(httpHost, IStringUtils.EMPTY);
    }

    public EsIndexer(String httpHost, String xpackIdentify) {
        this.httpHost = httpHost;
        this.xpackIdentify = xpackIdentify;
        init();
    }

    private void init() {
        EsRestClient esRestClient = null;
        try {
            esRestClient = new EsRestClient(this.getHttpHost(), this.getXpackIdentify()).init(null);
        } catch (EsException e) {
            LOGGER.error(e.getMessage(), e);
        }
        client = new RestHighLevelClient(esRestClient.getRestClient());
    }


    /**
     * bulk index
     *
     * @param indexName
     * @param indexType
     * @param datas
     * @throws EsException
     */
    public void bulkIndex(String indexName, String indexType, List<Map<String, Object>> datas) throws EsException {
        BulkRequest bulkAddRequest = new BulkRequest();

        datas.forEach((dataMap) -> {
            Object id = dataMap.remove("id");
            IndexRequest indexRequest = ObjectUtils.isNull(id) ? new IndexRequest(indexName, indexType) : new IndexRequest(indexName, indexType, id.toString());
            indexRequest.source(JSON.toJSONString(dataMap));
            bulkAddRequest.add(indexRequest);
        });

        try {
            client.bulk(bulkAddRequest);
        } catch (IOException e) {
            throw new EsException(e.getMessage(), e);
        }

    }


    /**
     * bulk
     *
     * @param indexName
     * @param indexType
     * @param datas
     * @throws EsException
     */
    public void bulkUpsert(String indexName, String indexType, List<Map<String, Object>> datas) throws EsException {
        BulkRequest bulkUpdateRequest = new BulkRequest();

        datas.forEach((dataMap) -> {
            Object id = dataMap.remove("id");
            if (!ObjectUtils.isNull(id)) {
                UpdateRequest updateRequest = new UpdateRequest(indexName, indexType, id.toString());
                updateRequest.docAsUpsert(true).doc(JSON.toJSONString(dataMap));
                bulkUpdateRequest.add(updateRequest);
            } else {
                LOGGER.warn("ID does not exist");
            }
        });

        try {
            client.bulk(bulkUpdateRequest);
        } catch (IOException e) {
            throw new EsException(e.getMessage(), e);
        }
    }


    public String getHttpHost() {
        return httpHost;
    }

    public void setHttpHost(String httpHost) {
        this.httpHost = httpHost;
    }

    public String getXpackIdentify() {
        return xpackIdentify;
    }

    public void setXpackIdentify(String xpackIdentify) {
        this.xpackIdentify = xpackIdentify;
    }

}
