package com.dptech.util.dynamic;


import com.dptech.elasticsearch.tempate.entity.ConfigDescriptor;
import com.dptech.elasticsearch.exception.EsException;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by jelly.wang on 2017/2/21.
 */
public class AutoLoadClasser {
    public static Map<String, ConfigDescriptor> esFileCache;
    public static Map<String, Class<?>> classCache = new ConcurrentHashMap<>();

    public static void init(String filePath) throws IOException, InstantiationException, IllegalAccessException, EsException {
        esFileCache = load(filePath);
        for (Map.Entry<String, ConfigDescriptor> m : esFileCache.entrySet()) {
            final Class<?> clazz = JavaEntityGenerator.generate(m.getKey(), m.getValue().getFields());
            if (clazz != null)
                classCache.put(m.getKey(), clazz);
        }
    }

    public static void reLoad(String path) throws IOException, InstantiationException, IllegalAccessException, EsException {
        esFileCache = load(path);
        for (Map.Entry<String, ConfigDescriptor> m : esFileCache.entrySet()) {
            String key = m.getKey();
            if (classCache.get(key) == null) {
                final Class<?> clazz = JavaEntityGenerator.generate(key, m.getValue().getFields());
                if (null != clazz)
                    classCache.put(key, clazz);
            }
        }
    }

    private synchronized static Map<String, ConfigDescriptor> load(String path) throws IOException, EsException {
        Map<String, ConfigDescriptor> fileCache = new ConcurrentHashMap<>();
        final File file = new File(path);
        if (file.exists() && file.isDirectory()) {
            listFiles(fileCache, file);
        } else {
            throw new EsException("folder [template] does not exist in classpath. ");
        }
        return fileCache;
    }

    private static void listFiles(Map<String, ConfigDescriptor> fileCache, File file) throws IOException, EsException {
        final File[] files = file.listFiles();
        for (File f : files) {
            if (f.isDirectory()) {
                listFiles(fileCache, f);
            } else {
                String fileName = f.getName();
                String key = fileName.substring(0, fileName.indexOf("."));
                ConfigDescriptor fileDescriptor4Es = fileCache.get(key);
                if (fileDescriptor4Es == null) {
                    ConfigDescriptor fd = new ConfigDescriptor();
                    set(f, fd);
                    fileCache.put(key, fd);
                } else {
                    set(f, fileDescriptor4Es);
                }
            }
        }
    }

    private static void set(File f, ConfigDescriptor fd) throws IOException, EsException {
        String name = f.getName();
        switch (name.substring(name.indexOf(".") + 1)) {
            case "tj":
                fd.setQueryTemplate(FileUtils.readFileToString(f, "UTF-8"));
                break;
            case "properties":
                List<String> lines = FileUtils.readLines(f, "UTF-8");
                for (String line : lines) {
                    int index = line.indexOf("=");
                    index = index == -1 ? line.indexOf(":") : index;
                    if (index != -1) {
                        String value = line.substring(line.indexOf("=") + 1);
                        if (line.contains("indexName")) {
                            fd.setIndexName(value);
                        } else if (line.contains("indexType")) {
                            fd.setIndexType(value);
                        } else if (line.contains("fields")) {
                            fd.setFields(value);
                        }
                    }
                }
                break;
            default:
                throw new EsException("there only has json and properties files in the folder [template] ");
        }
    }
}
