package com.dptech.util.dynamic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.tools.*;
import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: DynamicEngine
 * @Description: TODO
 * @author jelly.wang
 * @date 2017年2月18日
 */
public class DynamicEngine {
	private final static Logger logger = LoggerFactory.getLogger(DynamicEngine.class);
	private static DynamicEngine ourInstance = new DynamicEngine();

	public static DynamicEngine getInstance() {
		return ourInstance;
	}

	private URLClassLoader parentClassLoader;
	private String classpath;

	private DynamicEngine() {
		this.parentClassLoader = (URLClassLoader) this.getClass().getClassLoader();
		this.buildClassPath();
	}

	private void buildClassPath() {
		this.classpath = null;
		StringBuilder sb = new StringBuilder();
		for (URL url : this.parentClassLoader.getURLs()) {
			String p = url.getFile();
			sb.append(p).append(File.pathSeparator);
		}
		this.classpath = sb.toString();
	}

	/**
	 * @Title: javaCodeToObject @Description: TODO @param @param
	 *         fullClassName @param @param
	 *         javaCode @param @return @param @throws
	 *         IllegalAccessException @param @throws InstantiationException
	 *         参数 @return Object 返回类型 @throws
	 */
	public Class<?> javaCodeToClass(String fullClassName, String javaCode)
			throws IllegalAccessException, InstantiationException {
		long start = System.currentTimeMillis(); // 记录开始编译时间
		Class<?> clazz = null;
		// 获取系统编译器
		JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
		// 建立DiagnosticCollector对象
		DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<JavaFileObject>();

		// 建立用于保存被编译文件名的对象
		// 每个文件被保存在一个从JavaFileObject继承的类中
		ClassFileManager fileManager = new ClassFileManager(compiler.getStandardFileManager(diagnostics, null, null));

		List<JavaFileObject> jfiles = new ArrayList<JavaFileObject>();
		jfiles.add(new CharSequenceJavaFileObject(fullClassName, javaCode));

		// 使用编译选项可以改变默认编译行为。编译选项是一个元素为String类型的Iterable集合
		List<String> options = new ArrayList<String>();
		options.add("-encoding");
		options.add("UTF-8");
		options.add("-classpath");
		options.add(this.classpath);

		JavaCompiler.CompilationTask task = compiler.getTask(null, fileManager, diagnostics, options, null, jfiles);
		// 编译源程序
		boolean success = task.call();

		if (success) {
			// 如果编译成功，用类加载器加载该类
			JavaClassObject jco = fileManager.getJavaClassObject();
			DynamicClassLoader dynamicClassLoader = new DynamicClassLoader(this.parentClassLoader);
			clazz = dynamicClassLoader.loadClass(fullClassName, jco);
		} else {
			// 如果想得到具体的编译错误，可以对Diagnostics进行扫描
			String error = "";
			for (Diagnostic diagnostic : diagnostics.getDiagnostics()) {
				error = error + compilePrint(diagnostic);
			}
		}
		long end = System.currentTimeMillis();
		logger.info("javaCodeToObject use:" + (end - start) + "ms");
		return clazz;
	}

	/**
	 * @Title: compilePrint @Description: TODO @param @param
	 * diagnostic @param @return 参数 @return String 返回类型 @throws
	 */
	private String compilePrint(Diagnostic diagnostic) {
		logger.info("Code:" + diagnostic.getCode());
		logger.info("Kind:" + diagnostic.getKind());
		logger.info("Position:" + diagnostic.getPosition());
		logger.info("Start Position:" + diagnostic.getStartPosition());
		logger.info("End Position:" + diagnostic.getEndPosition());
		logger.info("Source:" + diagnostic.getSource());
		logger.info("Message:" + diagnostic.getMessage(null));
		logger.info("LineNumber:" + diagnostic.getLineNumber());
		logger.info("ColumnNumber:" + diagnostic.getColumnNumber());
		StringBuffer res = new StringBuffer();
		res.append("Code:[" + diagnostic.getCode() + "]\n");
		res.append("Kind:[" + diagnostic.getKind() + "]\n");
		res.append("Position:[" + diagnostic.getPosition() + "]\n");
		res.append("Start Position:[" + diagnostic.getStartPosition() + "]\n");
		res.append("End Position:[" + diagnostic.getEndPosition() + "]\n");
		res.append("Source:[" + diagnostic.getSource() + "]\n");
		res.append("Message:[" + diagnostic.getMessage(null) + "]\n");
		res.append("LineNumber:[" + diagnostic.getLineNumber() + "]\n");
		res.append("ColumnNumber:[" + diagnostic.getColumnNumber() + "]\n");
		return res.toString();
	}
}