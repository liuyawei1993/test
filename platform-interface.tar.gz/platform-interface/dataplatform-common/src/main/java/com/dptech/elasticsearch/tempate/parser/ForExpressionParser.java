package com.dptech.elasticsearch.tempate.parser;


import com.dptech.elasticsearch.exception.SnippetParseException;

import java.util.Map;

/**
 * @author jelly * @date 2018-07-13 14:10
 * @ClassName: ForExpressionParser
 * @Description: TODO
 */
public class ForExpressionParser implements ExpressionParser {

    @Override
    public boolean parse(String snippet, Map<String, Object> params) throws SnippetParseException {
        return false;
    }
}
