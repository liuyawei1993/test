package com.dptech.elasticsearch.tempate.parser;


import com.dptech.elasticsearch.exception.SnippetParseException;
import com.dptech.util.IStringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import java.util.Map;

/**
 * @author jelly * @date 2018-07-13 14:10
 * @ClassName: IfExpressionParser
 * @Description: TODO
 */
public class IfExpressionParser implements ExpressionParser {

    @Override
    public boolean parse(String snippet, Map<String, Object> params) throws SnippetParseException {
        final TagExpression tagExpression = new TagExpression();
        OperatorType operatorType = checkAndSetOperatorType(snippet);
        tagExpression.setOperator(operatorType);
        String[] kv = snippet.split(operatorType.typeString);
        tagExpression.setKey(IStringUtils.trimAll(kv[0]));
        tagExpression.setValue(IStringUtils.trimAll(kv[1]));
        return getResult(tagExpression, params);
    }

    /**
     * 表达式操作类型设置
     *
     * @param str
     * @return
     */
    private static OperatorType checkAndSetOperatorType(String str) {
        final OperatorType[] values = OperatorType.values();
        for (OperatorType ot : values) {
            if (str.contains(ot.typeString)) return ot;
        }
        return OperatorType.NONE;
    }

    /**
     * id = 1
     */
    public static class TagExpression {
        // 表达式左侧
        private String key;
        // 表达式右侧
        private String value;
        // 表达式中间,支持 =,>,<,>=,<=,!=
        private OperatorType operator;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public OperatorType getOperator() {
            return operator;
        }

        public void setOperator(OperatorType operator) {
            this.operator = operator;
        }
    }

    private boolean getResult(TagExpression tagExpression, Map<String, Object> params) {
        boolean result = true;
        Object pValue = params.get(tagExpression.getKey());
        pValue = null == pValue ? IStringUtils.EMPTY : pValue;
//        if (null == pValue) throw new IllegalArgumentException("missing the necessary parameters");
        String value = tagExpression.getValue();
        if (pValue instanceof String) {
            switch (tagExpression.getOperator()) {
                case EQ:
                    if (pValue.toString().equals(value)) return result;
                    break;
                case NE:
                    if (!pValue.toString().equals(value)) return result;
                    break;
                default:
                    break;
            }
        } else if (pValue instanceof Number) {
            switch (tagExpression.getOperator()) {
                case EQ:
                    if (NumberUtils.toDouble(pValue.toString()) == NumberUtils.toDouble(value)) return result;
                    break;
                case GE:
                    if (NumberUtils.toDouble(pValue.toString()) >= NumberUtils.toDouble(value)) return result;
                    break;
                case GT:
                    if (NumberUtils.toDouble(pValue.toString()) > NumberUtils.toDouble(value)) return result;
                    break;
                case LE:
                    if (NumberUtils.toDouble(pValue.toString()) <= NumberUtils.toDouble(value)) return result;
                    break;
                case LT:
                    if (NumberUtils.toDouble(pValue.toString()) < NumberUtils.toDouble(value)) return result;
                    break;
                case NE:
                    if (NumberUtils.toDouble(pValue.toString()) != NumberUtils.toDouble(value)) return result;
                    break;
                default:
                    break;
            }
        } else {
            throw new IllegalArgumentException("the parameter type is incorrect,only String,Number");
        }
        return !result;
    }
}
