package com.dptech.elasticsearch.common;

import java.util.LinkedHashMap;

/**
 * @author jelly * @date 2019-09-07 17:04
 * @ClassName: IndexRowData
 * @Description: TODO
 */
public class IndexRowData extends LinkedHashMap<String, Object> {

    private static final long serialVersionUID = 4040420174717552587L;

    public IndexRowData build(String filedName, Object filedValue) {
        this.put(filedName, filedValue);
        return this;
    }
}
