package com.dptech.elasticsearch.client;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.ElasticSearchDruidDataSourceFactory;
import com.dptech.elasticsearch.exception.EsException;
import com.dptech.util.IStringUtils;

import java.io.File;
import java.util.Map;
import java.util.Properties;

public final class EsSqlClient extends AbstractClient {
    private final String JDBC_URL_PREFIX = "jdbc:elasticsearch://";
    private DruidDataSource dataSource;

    public DruidDataSource getDataSource() {
        return dataSource;
    }

    public EsSqlClient(String hosts) {
        super(hosts);
    }

    public EsSqlClient(String hosts, String xpackIdentify) {
        super(hosts, xpackIdentify);
    }

    @Override
    public EsSqlClient init(Map<String, Object> params) throws EsException {
        if (null == params || params.size() < 1) {
            throw new EsException("Initialization params cannot be null ");
        }

        final Properties properties = new Properties() {{
            put("url", JDBC_URL_PREFIX + getHosts() + File.separator + params.entrySet().toArray()[0]);
            // username,password
            if (IStringUtils.isNotEmpty(getXpackIdentify())) {
                String[] userPass = getXpackIdentify().split(":");
                put("username", userPass[0]);
                put("password", userPass[1]);
            }
        }};

        try {
            this.dataSource = (DruidDataSource) ElasticSearchDruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            throw new EsException("DataSource failed inited ", e);
        }

        return this;
    }

    @Override
    public void close() {
        if (null != this.dataSource) {
            this.dataSource.close();
        }
    }
}
