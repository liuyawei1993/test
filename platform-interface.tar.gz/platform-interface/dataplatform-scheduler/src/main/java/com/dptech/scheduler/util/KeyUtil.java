package com.dptech.scheduler.util;

import com.google.common.hash.HashFunction;
import com.google.common.hash.Hasher;
import com.google.common.hash.Hashing;

public class KeyUtil {
	private static final int SEED = 0xDEADBEEF;
	public static final int HASH_PREFIX_SIZE=16;
	static ThreadLocal<HashFunction> hFunction= new ThreadLocal<HashFunction>() {
		@Override
		protected HashFunction initialValue() {
			return Hashing.murmur3_128(SEED);
		}
	};

	@SuppressWarnings("unused")
	public static byte[] getPrefix(byte[] key) {
		Hasher hasher = hFunction.get().newHasher();
		hasher.putBytes(key);
		return hasher.hash().asBytes();
	}

	@SuppressWarnings("unused")
	public static byte[] merge(byte[] prefix, byte[] key) {
		byte[] val = new byte[key.length + prefix.length];
		int offset = 0;
		System.arraycopy(prefix, 0, val, offset, prefix.length);
		offset += prefix.length;
		System.arraycopy(key, 0, val, offset, key.length);
		return val;
	}
}
