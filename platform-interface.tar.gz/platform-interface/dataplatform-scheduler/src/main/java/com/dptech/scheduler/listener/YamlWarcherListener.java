package com.dptech.scheduler.listener;

import com.dptech.scheduler.util.CustomProcessCLassMonitor;
import com.dptech.scheduler.util.YamlAutoLoader;
import com.dptech.scheduler.util.YamlFileMonitor;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
/**
 * Created by jelly.wang on 2019/09/12
 */
import static com.dptech.scheduler.common.SchedulerConstants.EXTLIB_PATH;
import static com.dptech.scheduler.common.SchedulerConstants.YAML_TEMPLETE_PATH;

/**
 * Created by jenkin.wang on 2017/2/20.
 */
@Component("yamlWarcherListener")
public class YamlWarcherListener implements ApplicationListener<ContextRefreshedEvent> {
    private final Logger logger = Logger.getLogger(YamlWarcherListener.class);

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        logger.info("listening folder =>" + YAML_TEMPLETE_PATH);
        try {
            // load yaml template
            YamlAutoLoader.load(YAML_TEMPLETE_PATH);
            // start file monitor
            new YamlFileMonitor(YAML_TEMPLETE_PATH, 30000L).start();
            // listen scheduler task
            SchedulerTaskListener.listen();
            // custom class
            new CustomProcessCLassMonitor(EXTLIB_PATH, 30000l).start();
        } catch (Exception e) {
            logger.info("error loading folder =>", e);
        }
    }
}
