package com.dptech.scheduler.task.process;

import com.dptech.util.EsResultExtractor;

import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/18 下午2:49
 * @description: TODO
 */
public class EsProcess implements ProcessFactory {
    @Override
    public List<Map<String, Object>> exec(List<String> jsonDataList) {
        EsResultExtractor extract = new EsResultExtractor().extract(jsonDataList.get(0));
        return extract.getResult().getHits();
    }
}
