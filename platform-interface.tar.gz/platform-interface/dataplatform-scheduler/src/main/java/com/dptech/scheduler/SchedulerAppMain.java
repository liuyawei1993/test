package com.dptech.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;

/**
 * Created by jelly.wang on 2019/09/12
 */

@SpringBootApplication
@ImportResource("classpath:spring/spring.xml")
public class SchedulerAppMain extends SpringBootServletInitializer implements EmbeddedServletContainerCustomizer {
    private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerAppMain.class);


    public static void main(String[] args) {
        try {
            SpringApplication.run(SchedulerAppMain.class, args);
        } catch (Exception e) {
            LOGGER.error("spring-boot start exception: ", e);
        }
    }

    @Override
    public void customize(ConfigurableEmbeddedServletContainer container) {
        container.setPort(8070);
    }
}
