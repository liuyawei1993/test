package com.dptech.scheduler.task.process;

import com.alibaba.fastjson.JSON;

import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/18 上午10:26
 * @description: TODO
 */
public class DefaultProcess implements ProcessFactory {
    @Override
    public List<Map<String, Object>> exec(String jsonData) {
        return JSON.parseObject(jsonData, List.class);
    }
}
