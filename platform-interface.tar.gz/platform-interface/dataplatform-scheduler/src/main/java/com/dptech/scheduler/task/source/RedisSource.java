package com.dptech.scheduler.task.source;

import com.alibaba.fastjson.JSON;
import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.exception.SchedulerException;
import com.dptech.scheduler.util.DruidUtils;
import com.dptech.scheduler.util.RedisUtils;

import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/18 上午10:07
 * @description: TODO
 */
public class RedisSource extends SourceFactory {
    @Override
    public String exec(SchedulerYaml.Input input) throws SchedulerException {
        // select * from map where key = 'test2019*' limit 10000
        String exp = paramsAssign(input.getExp());
        Map<String, Object> consMap = DruidUtils.simpleRedisSqlParse(exp);
        switch (consMap.get("table_name").toString()) {
            case "map":
                List<String[]> conditions = (List<String[]>) consMap.get("conditions");
                return JSON.toJSONString(RedisUtils.obtainMapTypeData(conditions.get(0)[1], Integer.valueOf(input.getTable())));
            default:
                throw new SchedulerException("redis data type:" + consMap.get("table_name").toString() + " no support");
        }
    }
}
