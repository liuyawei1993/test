package com.dptech.scheduler.common;

import com.dptech.scheduler.job.SchedulerJobDetail;
import com.dptech.util.ConfigUtils;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * Created by jelly.wang on 2019/09/12
 */
public interface SchedulerConstants {
    String SWAP_START_STRING = "${";
    String SWAP_END_STRING = "}";

    String YAML_TEMPLETE = "template";
    String YAML_TEMPLETE_PATH = SchedulerConstants.class.getClassLoader().getResource(SchedulerConstants.YAML_TEMPLETE).getPath();

    String EXTLIB = "extlib";
    String EXTLIB_PATH = SchedulerConstants.class.getClassLoader().getResource(SchedulerConstants.EXTLIB).getPath();

    ArrayBlockingQueue<SchedulerJobDetail> SCHEDULER_TASK_QUEUE = new ArrayBlockingQueue(ConfigUtils.getInt("queue_capacity", 10), true);
}
