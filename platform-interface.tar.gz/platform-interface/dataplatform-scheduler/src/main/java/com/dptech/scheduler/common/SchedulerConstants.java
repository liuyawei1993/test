package com.dptech.scheduler.common;

import java.util.concurrent.ArrayBlockingQueue;

/**
 * Created by jelly.wang on 2019/09/12
 */
public interface SchedulerConstants {
    String YAML_TEMPLETE = "template";
    String YAML_TEMPLETE_PATH = SchedulerConstants.class.getClassLoader().getResource(SchedulerConstants.YAML_TEMPLETE).getPath();

    String EXTLIB = "extlib";
    String EXTLIB_PATH = SchedulerConstants.class.getClassLoader().getResource(SchedulerConstants.EXTLIB).getPath();


    ArrayBlockingQueue SCHEDULER_TASK_QUEUE = new ArrayBlockingQueue(10, true);
}
