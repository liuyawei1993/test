package com.dptech.scheduler.job;

import com.dptech.scheduler.entity.SchedulerYaml;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Created by jelly.wang on 2019/09/12
 */
public final class SchedulerJobBuilder {
    private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerJobBuilder.class);

    private SchedulerJobBuilder() {
    }

    public static void build(List<SchedulerYaml> schedulerYamls) {
        if (null != schedulerYamls && schedulerYamls.size() > 0) {
            schedulerYamls.forEach((schedulerYaml) -> schedulerYaml.getTasks().forEach((task) -> {
                String jobName = task.getName();
                if (SchedulerManager.checkJob(jobName))
                    SchedulerManager.delJob(jobName);

                // obtain SchedulerJobDetail
                SchedulerJobDetail schedulerJobDetail = new SchedulerJobDetail();
                schedulerJobDetail.setName(task.getName());
                schedulerJobDetail.setExecClass(task.getExecCLass());
                schedulerYaml.getInputs().forEach((input) -> {
                    if (input.getId().equalsIgnoreCase(task.getFrom())) {
                        schedulerJobDetail.setFrom(input);
                        return;
                    }
                });

                schedulerYaml.getOutputs().forEach((output) -> {
                    if (output.getId().equalsIgnoreCase(task.getTo())) {
                        schedulerJobDetail.setTo(output);
                    }
                });

                if (null != schedulerJobDetail.getFrom() && null != schedulerJobDetail.getTo()) {
                    SchedulerManager.addJob(jobName, SchedulerJob.class, task.getCron(), schedulerJobDetail);
                } else {
                    LOGGER.warn("there are no Input/Output.");
                }

            }));
        }
    }
}
