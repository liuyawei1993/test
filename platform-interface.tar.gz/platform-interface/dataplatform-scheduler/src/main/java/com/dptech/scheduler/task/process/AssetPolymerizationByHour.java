package com.dptech.scheduler.task.process;

import com.alibaba.fastjson.JSON;
import com.dptech.scheduler.util.PolymerizationUtils;
import com.dptech.util.ConfigUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AssetPolymerizationByHour implements ProcessFactory{
    private static PolymerizationUtils pUtils = new PolymerizationUtils(3,"yyyyMMddHH");
    private static List<Map<String, Object>> listRedis = null;
    @Override
    public List<Map<String, Object>> exec(String jsonData) {
        List<Map<String, Object>> result = new ArrayList<>();
        List<Map<String, Object>> groupAssetMap = null;
        List<Map<String, Object>> singleAssetMap = null;

        listRedis = JSON.parseObject(jsonData, List.class);
        singleAssetMap = pUtils.singlePolymerization(listRedis);//单个资产聚合
        groupAssetMap =pUtils.groupPolymerization(singleAssetMap);//分组资产聚合
        pUtils.allPolymerization(singleAssetMap);//整体资产聚合
        pUtils.aggsPolymerization(singleAssetMap, "asset_type");//依据query_type=asset_type聚合
        pUtils.aggsPolymerization(groupAssetMap, "asset_group");//依据query_type=asset_group聚合
        pUtils.aggsPolymerization(null, "asset_risk");//依据query_type=asset_risk聚合

        result.addAll(singleAssetMap);
        result.addAll(groupAssetMap);
        for (Map<String, Object> map : result) {
            System.out.println(map);
        }
        return result;
    }
}
