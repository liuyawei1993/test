package com.dptech.scheduler.task.sink;

import com.dptech.elasticsearch.exception.EsException;
import com.dptech.elasticsearch.index.EsIndexer;
import com.dptech.scheduler.entity.SchedulerYaml;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/18 上午10:07
 * @description: TODO
 */
public class ElasticsearchSink extends SinkFactory {
    private final static Logger LOGGER = Logger.getLogger(ElasticsearchSink.class);
    private final EsIndexer esIndexer = new EsIndexer();

    @Override
    public void exec(List<Map<String, Object>> data, SchedulerYaml.Output output) throws Exception {
        dipartTable(data).forEach((tableName, dataMaps) -> {
            if (tableName.equals(DEFAULT_TABLE_NAME)) tableName = output.getTable();

            try {
                esIndexer.bulkUpsert(tableName, tableName, dataMaps);
            } catch (EsException e) {
                LOGGER.error(e.getMessage(), e);
            }
        });
    }
}
