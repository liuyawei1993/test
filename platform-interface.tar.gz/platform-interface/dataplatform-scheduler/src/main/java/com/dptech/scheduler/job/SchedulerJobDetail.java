package com.dptech.scheduler.job;

import com.dptech.scheduler.entity.SchedulerYaml;
import lombok.Data;

@Data
public class SchedulerJobDetail {
    private String name;
    private SchedulerYaml.Input from;
    private SchedulerYaml.Output to;
    private String execClass;
}
