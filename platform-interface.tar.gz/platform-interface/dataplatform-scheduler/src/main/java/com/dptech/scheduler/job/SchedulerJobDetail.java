package com.dptech.scheduler.job;

import com.dptech.scheduler.entity.SchedulerYaml;
import lombok.Data;

import java.util.List;

/**
 * Created by jenkin.wang on 2019/9/20.
 */
@Data
public class SchedulerJobDetail {
    private String name;
    private List<SchedulerYaml.Input> fromList;
    private List<SchedulerYaml.Output> toList;
    private String execClass;
    private String cron;

    private Long expectTime;
    private Long startJobTime;
    private Long endJobTime;
}
