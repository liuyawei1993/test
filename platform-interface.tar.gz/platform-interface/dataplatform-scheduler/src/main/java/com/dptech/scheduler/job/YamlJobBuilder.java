package com.dptech.scheduler.job;

import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.listener.SchedulerTaskListener;
import com.dptech.util.DateUtils;
import com.dptech.util.IStringUtils;
import org.apache.commons.io.FileUtils;
import org.quartz.CronExpression;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by jelly.wang on 2019/09/12
 */
public class YamlJobBuilder implements JobBuilder {
    private static final Logger LOGGER = LoggerFactory.getLogger(YamlJobBuilder.class);
    private List<SchedulerYaml> schedulerYamls;
    private final Long defaultExpectTime = 60 * 1000L;
    private final String expProtocol = "file://";

    public YamlJobBuilder(List<SchedulerYaml> schedulerYamls) {
        this.schedulerYamls = schedulerYamls;
    }

    @Override
    public void build() {
        if (null != schedulerYamls && schedulerYamls.size() > 0) {
            schedulerYamls.forEach((schedulerYaml) -> schedulerYaml.getTasks().forEach((task) -> {
                String jobName = task.getName();
                if (SchedulerManager.checkJob(jobName))
                    SchedulerManager.delJob(jobName);

                // obtain SchedulerJobDetail
                SchedulerJobDetail schedulerJobDetail = new SchedulerJobDetail();
                schedulerJobDetail.setName(task.getName());
                schedulerJobDetail.setExecClass(task.getExecCLass());
                schedulerJobDetail.setCron(task.getCron());
                schedulerJobDetail.setExpectTime(defaultExpectTime);

                List<SchedulerYaml.Input> inputList = new ArrayList<>();
                schedulerYaml.getInputs().forEach((input) -> {
                    // read exp
                    String exp = input.getExp();
                    if (exp.startsWith(expProtocol)) {
                        try {
                            input.setExp(FileUtils.readFileToString(new File(exp.replace(expProtocol,IStringUtils.EMPTY)), "utf-8"));
                        } catch (IOException e) {
                            LOGGER.error(e.getMessage(), e);
                        }
                    }

                    String[] fromArray = task.getFrom().split(",");
                    for (String from : fromArray) {
                        if (input.getId().equalsIgnoreCase(from)) {
                            inputList.add(input);
                        }
                    }
                });
                schedulerJobDetail.setFromList(inputList);

                List<SchedulerYaml.Output> outList = new ArrayList<>();
                schedulerYaml.getOutputs().forEach((output) -> {
                    String[] toArray = task.getTo().split(",");
                    for (String to : toArray) {
                        if (output.getId().equalsIgnoreCase(to)) {
                            outList.add(output);
                        }
                    }
                });
                schedulerJobDetail.setToList(outList);

                SchedulerManager.addJob(jobName, SchedulerJob.class, task.getCron(), schedulerJobDetail);
            }));
        }
    }
}
