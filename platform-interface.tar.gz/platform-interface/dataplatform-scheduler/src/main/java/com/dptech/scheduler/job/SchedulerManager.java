package com.dptech.scheduler.job;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

import java.util.Arrays;

/**
 * Created by jelly.wang on 2019/09/12
 */
public class SchedulerManager {
    private final static SchedulerFactory stdSchedulerFactory = new StdSchedulerFactory();
    private final static String JOB_GROUP_NAME = "OFFLINE_JOB_GROUP";
    private final static String TRIGGER_GROUP_NAME = "OFFLINE_TRIGGER_GROUP";
    public final static String SCHEDULER_TASK_PARAM_NAME = "SCHEDULER_TASK_PARAM";

    /**
     * add a job
     *
     * @param jobName
     * @param clazz
     * @param cron
     */
    public static void addJob(String jobName, Class clazz, String cron, Object param) {
        try {
            Scheduler scheduler = stdSchedulerFactory.getScheduler();
            JobDetail jobDetail = new JobDetail(jobName, JOB_GROUP_NAME, clazz);
            jobDetail.getJobDataMap().put(SCHEDULER_TASK_PARAM_NAME, param);

            CronTrigger trigger = new CronTrigger(jobName, TRIGGER_GROUP_NAME);
            trigger.setCronExpression(cron);

            scheduler.scheduleJob(jobDetail, trigger);

            scheduler.start();
        } catch (Exception e) {
            throw new SecurityException("failed add quartz job", e);
        }
    }

    /**
     * modify a cron with the job
     *
     * @param jobName
     * @param cron
     */
    public static void modifyJobCron(String jobName, String cron, Object param) {
        try {
            Scheduler scheduler = stdSchedulerFactory.getScheduler();
            CronTrigger trigger = (CronTrigger) scheduler.getTrigger(jobName, TRIGGER_GROUP_NAME);
            if (null != trigger) {
                String oldCron = trigger.getCronExpression();
                if (!oldCron.equalsIgnoreCase(cron)) {
                    delJob(jobName);

                    JobDetail jobDetail = scheduler.getJobDetail(jobName, JOB_GROUP_NAME);
                    addJob(jobName, jobDetail.getJobClass(), cron, param);
                }
            }
        } catch (Exception e) {
            throw new SecurityException("failed modify quartz job", e);
        }
    }

    /**
     * delete a job
     *
     * @param jobName
     */
    public static void delJob(String jobName) {
        try {
            Scheduler scheduler = stdSchedulerFactory.getScheduler();
            scheduler.pauseTrigger(jobName, TRIGGER_GROUP_NAME);
            scheduler.unscheduleJob(jobName, TRIGGER_GROUP_NAME);
            scheduler.deleteJob(jobName, JOB_GROUP_NAME);
        } catch (Exception e) {
            throw new SecurityException("failed delete quartz job", e);
        }
    }

    /**
     * start jobs
     */
    public static void startJobs() {
        try {
            stdSchedulerFactory.getScheduler().start();
        } catch (Exception e) {
            throw new SecurityException("failed start quartz job", e);
        }
    }

    /**
     * shutdown jobs
     */
    public static void shutdownJobs() {
        try {
            stdSchedulerFactory.getScheduler().shutdown();
        } catch (Exception e) {
            throw new SecurityException("failed shutdown quartz job", e);
        }
    }

    /**
     * 判断job是否存在
     *
     * @param jobName
     * @return
     */
    public static boolean checkJob(String jobName) {
        try {
            Scheduler scheduler = stdSchedulerFactory.getScheduler();
            return Arrays.asList(scheduler.getJobNames(JOB_GROUP_NAME)).contains(jobName);
        } catch (Exception e) {
            throw new SecurityException("failed shutdown quartz job", e);
        }
    }
}
