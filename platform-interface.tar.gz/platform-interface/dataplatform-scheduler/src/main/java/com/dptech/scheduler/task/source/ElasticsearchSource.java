package com.dptech.scheduler.task.source;

import com.dptech.elasticsearch.queriers.EsSqlQuerier;
import com.dptech.elasticsearch.queriers.EsTemplateQuerier;
import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.exception.SchedulerException;
import com.dptech.util.IStringUtils;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/16 上午11:00
 * @description: TODO
 */
public class ElasticsearchSource extends SourceFactory {
    @Override
    public String exec(SchedulerYaml.Input input) throws SchedulerException {
        String exp = input.getExp();
        String[] indexAndType = paramsAssign(input.getTable()).split("&");
        // sql
        if (exp.trim().startsWith("select")) {
            EsSqlQuerier esSqlQuerier = new EsSqlQuerier(IStringUtils.EMPTY);
            try {
                return esSqlQuerier.query(indexAndType[0], exp);
            } catch (Exception e) {
                throw new SchedulerException(e.getMessage(), e);
            }
        } else { // rest
            EsTemplateQuerier esTemplateQuerier = new EsTemplateQuerier(IStringUtils.EMPTY);
            try {
                return esTemplateQuerier.query(indexAndType[0], indexAndType[1], exp);
            } catch (Exception e) {
                throw new SchedulerException(e.getMessage(), e);
            }
        }
    }
}
