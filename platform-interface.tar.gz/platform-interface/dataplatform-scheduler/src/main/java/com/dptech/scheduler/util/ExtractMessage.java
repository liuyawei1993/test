package com.dptech.scheduler.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractMessage {

    public static void main(String[] args) {


        String str = "{\n" +
				"\t\"took\": 86,\n" +
				"\t\"timed_out\": false,\n" +
				"\t\"_shards\": {\n" +
				"\t\t\"total\": 2,\n" +
				"\t\t\"successful\": 2,\n" +
				"\t\t\"skipped\": 0,\n" +
				"\t\t\"failed\": 0\n" +
				"\t},\n" +
				"\t\"hits\": {\n" +
				"\t\t\"total\": 316170,\n" +
				"\t\t\"max_score\": 0,\n" +
				"\t\t\"hits\": []\n" +
				"\t},\n" +
				"\t\"aggregations\": {\n" +
				"\t\t\"eventList\": {\n" +
				"\t\t\t\"doc_count_error_upper_bound\": 186,\n" +
				"\t\t\t\"sum_other_doc_count\": 6857,\n" +
				"\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\"key\": \"192.168.1.21\",\n" +
				"\t\t\t\t\t\"doc_count\": 106510,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 604,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 91825\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 13018\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 1063\n" +
				"\t\t\t\t\t\t\t}\n" +
				"\t\t\t\t\t\t]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"192.168.66.190\",\n" +
				"\t\t\t\t\t\"doc_count\": 96529,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 0,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 96277\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 179\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 73\n" +
				"\t\t\t\t\t\t\t}\n" +
				"\t\t\t\t\t\t]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"10.1.1.100\",\n" +
				"\t\t\t\t\t\"doc_count\": 62356,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 151,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 42411\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 14230\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 5564\n" +
				"\t\t\t\t\t\t\t}\n" +
				"\t\t\t\t\t\t]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"192.168.1.101\",\n" +
				"\t\t\t\t\t\"doc_count\": 11147,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 0,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\"doc_count\": 11147\n" +
				"\t\t\t\t\t\t}]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"172.16.1.240\",\n" +
				"\t\t\t\t\t\"doc_count\": 11119,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 0,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 10408\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"?????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 711\n" +
				"\t\t\t\t\t\t\t}\n" +
				"\t\t\t\t\t\t]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"192.168.1.100\",\n" +
				"\t\t\t\t\t\"doc_count\": 11013,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 579,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 6916\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"?????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 2225\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 1293\n" +
				"\t\t\t\t\t\t\t}\n" +
				"\t\t\t\t\t\t]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"10.101.0.2\",\n" +
				"\t\t\t\t\t\"doc_count\": 6578,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 0,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\"doc_count\": 6578\n" +
				"\t\t\t\t\t\t}]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"192.168.18.1\",\n" +
				"\t\t\t\t\t\"doc_count\": 1449,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 0,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 842\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 402\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 205\n" +
				"\t\t\t\t\t\t\t}\n" +
				"\t\t\t\t\t\t]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"192.168.0.20\",\n" +
				"\t\t\t\t\t\"doc_count\": 1432,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 0,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\"doc_count\": 1432\n" +
				"\t\t\t\t\t\t}]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t},\n" +
				"\t\t\t\t{\n" +
				"\t\t\t\t\t\"key\": \"192.168.66.197\",\n" +
				"\t\t\t\t\t\"doc_count\": 1180,\n" +
				"\t\t\t\t\t\"threatType\": {\n" +
				"\t\t\t\t\t\t\"doc_count_error_upper_bound\": 0,\n" +
				"\t\t\t\t\t\t\"sum_other_doc_count\": 0,\n" +
				"\t\t\t\t\t\t\"buckets\": [{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 683\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 312\n" +
				"\t\t\t\t\t\t\t},\n" +
				"\t\t\t\t\t\t\t{\n" +
				"\t\t\t\t\t\t\t\t\"key\": \"?????\",\n" +
				"\t\t\t\t\t\t\t\t\"doc_count\": 185\n" +
				"\t\t\t\t\t\t\t}\n" +
				"\t\t\t\t\t\t]\n" +
				"\t\t\t\t\t}\n" +
				"\t\t\t\t}\n" +
				"\t\t\t]\n" +
				"\t\t}\n" +
				"\t}\n" +
				"}";


		System.out.println(extractMessageByRegular(str));


	}

    /**
     * @param msg
     * @return
     */
    public static String extractMessage(String msg) {

        StringBuilder sb = new StringBuilder();
        int start = 0;
        int startFlag = 0;
        int endFlag = 0;
        for (int i = 0; i < msg.length(); i++) {
            if (msg.charAt(i) == '[') {
                startFlag++;
                if (startFlag == endFlag + 1) {
                    start = i;
                }
            } else if (msg.charAt(i) == ']') {
                endFlag++;
                if (endFlag == startFlag) {
                    sb.append(msg.substring(start + 1, i));
                }
            }
        }
        return sb.toString();
    }

    public static List<String> extractMessageByRegular(String msg) {
        List<String> list = new ArrayList<String>();
        Pattern pattern = Pattern.compile("\\[(.*?)]");
        Matcher matcher = pattern.matcher(msg);
        while (matcher.find()) {
            String englishBrand = matcher.group();
            list.add(englishBrand.toUpperCase());
        }
        return list;
    }


}