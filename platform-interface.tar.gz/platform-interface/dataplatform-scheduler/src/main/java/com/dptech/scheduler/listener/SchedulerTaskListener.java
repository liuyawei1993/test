package com.dptech.scheduler.listener;

import com.dptech.scheduler.common.SchedulerConstants;
import com.dptech.scheduler.job.SchedulerJobDetail;
import com.dptech.scheduler.task.TaskActuator;
import com.dptech.util.DateUtils;
import lombok.Data;
import org.apache.log4j.Logger;

import java.util.Map;
import java.util.concurrent.*;

/**
 * Created by jenkin.wang on 2019/9/20.
 */
public final class SchedulerTaskListener {
    private final static Logger LOGGER = Logger.getLogger(SchedulerTaskListener.class);
    public final static ThreadInfo threadInfo = new ThreadInfo();
    public final static Map<String, Long> TASK_EXEC_TIME = new ConcurrentHashMap<>();

    public static void listen() {
        ExecutorService executorService = Executors.newFixedThreadPool(1);
        try {
            executorService.execute(() -> {
                for (; ; ) {
                    ExecutorService executor = Executors.newFixedThreadPool(1);
                    CompletionService<Boolean> completionService = new ExecutorCompletionService<>(executor);
                    completionService.submit(() -> {
                        SchedulerJobDetail schedulerJobDetail = SchedulerConstants.SCHEDULER_TASK_QUEUE.take();
                        // set ThreadInfo
                        threadInfo.setThreadId(Thread.currentThread().getId());
                        threadInfo.setThreadTimestamp(DateUtils.getCurrentDateTime().getTime());
                        threadInfo.setSchedulerJobDetail(schedulerJobDetail);
                        threadInfo.setJobExecutorService(executor);

                        long taskStartTime = DateUtils.getCurrentDateTime().getTime();
                        boolean result = new TaskActuator(schedulerJobDetail).execute();
                        TASK_EXEC_TIME.put(schedulerJobDetail.getName(), DateUtils.getCurrentDateTime().getTime() - taskStartTime);
                        LOGGER.info("Job execution result[" + schedulerJobDetail + "],result: <" + result + ">");
                        return result;
                    });

                    try {
                        completionService.take().get();
                    } catch (Exception e) {
                        LOGGER.error(e.getMessage(), e);
                    } finally {
                        if (null != executor) executor.shutdown();
                    }
                }
            });
        } finally {
            if (null != executorService) executorService.shutdown();
        }
    }

    @Data
    public static class ThreadInfo {
        private Long threadId;
        private Long threadTimestamp;
        private SchedulerJobDetail schedulerJobDetail;
        private ExecutorService jobExecutorService;
    }
}
