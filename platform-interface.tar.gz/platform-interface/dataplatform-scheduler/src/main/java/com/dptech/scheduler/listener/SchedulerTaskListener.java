package com.dptech.scheduler.listener;

import com.dptech.scheduler.common.SchedulerConstants;
import com.dptech.scheduler.job.SchedulerJobDetail;
import com.dptech.scheduler.task.TaskActuator;
import org.apache.log4j.Logger;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class SchedulerTaskListener {
    private final static Logger LOGGER = Logger.getLogger(SchedulerTaskListener.class);

    public static void listen() {
        ExecutorService executorService = Executors.newFixedThreadPool(1);
        try {
            executorService.execute(() -> {
                for (; ; ) {
                    try {
                        SchedulerJobDetail schedulerJobDetail = (SchedulerJobDetail) SchedulerConstants.SCHEDULER_TASK_QUEUE.take();
                        boolean result = new TaskActuator(schedulerJobDetail).execute();
                        LOGGER.info("Job execution result[" + schedulerJobDetail + "],result: <" + result + ">");
                    } catch (InterruptedException e) {
                        LOGGER.error(e.getMessage(), e);
                        break;
                    }
                }
            });
        } finally {
            executorService.shutdown();
        }
    }
}
