package com.dptech.scheduler.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AssignableTypeFilter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/15 下午2:12
 * @description: TODO
 */
public final class ReflectionsUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(ReflectionsUtils.class);
    private static Map<String, List<Class>> classMap = new ConcurrentHashMap<>();

    private ReflectionsUtils() {
    }


    public static List<Class> getAllSubclass(Class superClass) {
        String basePackage = superClass.getPackage().getName();
        String key = superClass.getName() + "_" + basePackage;
        List<Class> cachedClasses = classMap.get(key);
        if (cachedClasses != null) {
            return cachedClasses;
        }

        ClassPathScanningCandidateComponentProvider provider = new ClassPathScanningCandidateComponentProvider(false);
        provider.addIncludeFilter(new AssignableTypeFilter(superClass));
        Set<BeanDefinition> components = provider.findCandidateComponents(basePackage);
        final List<Class> classes = new ArrayList<>();
        components.forEach((component) -> {
            try {
                classes.add(Class.forName(component.getBeanClassName()));
            } catch (ClassNotFoundException e) {
                LOGGER.error(e.getMessage(), e);
            }
        });

        classMap.put(key, classes);
        return classes;
    }

}
