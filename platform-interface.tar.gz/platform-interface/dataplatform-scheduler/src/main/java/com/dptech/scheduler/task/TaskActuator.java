package com.dptech.scheduler.task;

import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.exception.SchedulerException;
import com.dptech.scheduler.job.SchedulerJobDetail;
import com.dptech.scheduler.task.sink.SinkFactory;
import com.dptech.scheduler.task.source.SourceFactory;
import com.dptech.util.IStringUtils;
import org.apache.log4j.Logger;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/15 下午12:02
 * @description: TODO
 */
public final class TaskActuator {
    private final static Logger LOGGER = Logger.getLogger(TaskActuator.class);
    private SchedulerJobDetail schedulerJobDetail;
    private List<Map<String, Object>> dataTransferSation;

    public TaskActuator(SchedulerJobDetail schedulerJobDetail) {
        this.schedulerJobDetail = schedulerJobDetail;
    }

    public synchronized boolean execute() {
        try {
            sink(process(source()));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    private String source() throws Exception {
        SchedulerYaml.Input input = schedulerJobDetail.getFrom();
        SourceFactory sourceFactory = SourceFactory.getSourceFactory(input.getType());
        if (null == sourceFactory) throw new SchedulerException("Input type[" + input.getType() + "] is not support.");
        return sourceFactory.exec(input);
    }

    private List<Map<String, Object>> process(String jsonData) throws Exception {
        String execClass = schedulerJobDetail.getExecClass();
        if (IStringUtils.isEmpty(execClass)) execClass = "com.dptech.scheduler.task.process.DefaultProcess";
        Class<?> aClass = Class.forName(execClass);
        Method execMethod = aClass.getMethod("exec", String.class);
        return (List<Map<String, Object>>) execMethod.invoke(aClass.newInstance(), jsonData);
    }

    private void sink(List<Map<String, Object>> dataMaps) throws Exception {
        SchedulerYaml.Output output = schedulerJobDetail.getTo();
        SinkFactory sinkFactory = SinkFactory.getSinkFactory(output.getType());
        if (null == sinkFactory) throw new SchedulerException("Output type[" + output.getType() + "] is not support.");
        sinkFactory.exec(dataMaps, output);
    }
}
