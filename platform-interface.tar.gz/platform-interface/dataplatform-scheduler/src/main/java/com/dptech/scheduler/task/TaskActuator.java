package com.dptech.scheduler.task;

import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.exception.SchedulerException;
import com.dptech.scheduler.job.SchedulerJobDetail;
import com.dptech.scheduler.task.sink.SinkFactory;
import com.dptech.scheduler.task.source.SourceFactory;
import com.dptech.util.IStringUtils;
import org.apache.log4j.Logger;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.*;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/15 下午12:02
 * @description: TODO
 */
public final class TaskActuator {
    private final static Logger LOGGER = Logger.getLogger(TaskActuator.class);
    private SchedulerJobDetail schedulerJobDetail;

    public TaskActuator(SchedulerJobDetail schedulerJobDetail) {
        this.schedulerJobDetail = schedulerJobDetail;
    }

    public synchronized boolean execute() {
        try {
            sink(process(source()));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    /**
     * @return
     * @throws Exception
     */
    private List<String> source() throws Exception {
        List<SchedulerYaml.Input> fromList = schedulerJobDetail.getFromList();
        int threadNum = fromList.size();
        if (threadNum <= 0) {
            LOGGER.warn("SchedulerYaml.Input is null");
            return Collections.emptyList();
        }

        ExecutorService executor = Executors.newFixedThreadPool(threadNum);
        CompletionService<String> completionService = new ExecutorCompletionService<>(executor);
        fromList.forEach(from -> completionService.submit(() -> {
            SourceFactory sourceFactory = SourceFactory.getSourceFactory(from.getType());
            if (null == sourceFactory)
                throw new SchedulerException("Input type[" + from.getType() + "] is not support.");
            return sourceFactory.exec(from);
        }));

        List<String> resultList = new ArrayList<>();
        try {
            while (threadNum-- > 0) {
                resultList.add(completionService.take().get());
            }
        } catch (Exception e) {
            throw new SchedulerException(e.getMessage(), e);
        } finally {
            executor.shutdown();
        }
        return resultList;
    }

    /**
     * @param jsonDataList
     * @return
     * @throws Exception
     */
    private List<Map<String, Object>> process(List<String> jsonDataList) throws Exception {
        String execClass = schedulerJobDetail.getExecClass();
        if (IStringUtils.isEmpty(execClass)) execClass = "com.dptech.scheduler.task.process.DefaultProcess";
        Class<?> aClass = Class.forName(execClass);
        Method execMethod = aClass.getMethod("exec", List.class);
        return (List<Map<String, Object>>) execMethod.invoke(aClass.newInstance(), jsonDataList);
    }

    /**
     * @param dataMaps
     * @throws Exception
     */
    private void sink(List<Map<String, Object>> dataMaps) throws Exception {
        List<SchedulerYaml.Output> toList = schedulerJobDetail.getToList();
        int threadNum = toList.size();
        if (threadNum <= 0) {
            LOGGER.warn("SchedulerYaml.Input is null");
            return;
        }

        ExecutorService executor = Executors.newFixedThreadPool(threadNum);
        CompletionService<Boolean> completionService = new ExecutorCompletionService<>(executor);
        toList.forEach(to -> completionService.submit(() -> {
            SinkFactory sinkFactory = SinkFactory.getSinkFactory(to.getType());
            if (null == sinkFactory) throw new SchedulerException("Output type[" + to.getType() + "] is not support.");
            sinkFactory.exec(dataMaps, to);
            return true;
        }));

        try {
            while (threadNum-- > 0) {
                completionService.take().get();
            }
        } catch (Exception e) {
            throw new SchedulerException(e.getMessage(), e);
        } finally {
            executor.shutdown();
        }
    }
}
