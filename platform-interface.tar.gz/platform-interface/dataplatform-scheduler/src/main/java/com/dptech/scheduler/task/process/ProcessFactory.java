package com.dptech.scheduler.task.process;

import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/15 下午1:35
 * @description: TODO
 */
public interface ProcessFactory {

    List<Map<String, Object>> exec(List<String> jsonDataList);
}
