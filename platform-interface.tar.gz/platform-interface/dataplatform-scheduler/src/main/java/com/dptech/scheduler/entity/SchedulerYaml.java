package com.dptech.scheduler.entity;

import lombok.Data;

import java.util.List;

/**
 * Created by jenkin.wang on 2019/9/12
 */
@Data
public class SchedulerYaml {
    private String name;
    private List<Input> inputs;
    private List<Output> outputs;
    private List<Task> tasks;

    @Data
    public static class Input {
        private String id;
        private String type;
        private String table;
        private String exp;
    }

    @Data
    public static class Output {
        private String id;
        private String type;
        private String table;
    }

    @Data
    public static class Task {
        private String name;
        private String from;
        private String to;
        private String cron;
        private String execCLass;
    }
}
