package com.dptech.scheduler.task.process;

import com.alibaba.fastjson.JSON;
import com.dptech.scheduler.util.PolymerizationUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AssetPolymerizationByDay implements ProcessFactory{
    private static PolymerizationUtils pUtils = new PolymerizationUtils(3,"yyyyMMdd");
    private static List<Map<String, Object>> listRedis = null;
    @Override
    public List<Map<String, Object>> exec(String jsonData) {
        List<Map<String, Object>> result = new ArrayList<>();
        List<Map<String, Object>> groupAssetMap = null;
        List<Map<String, Object>> singleAssetMap = null;

        listRedis = JSON.parseObject(jsonData, List.class);
        singleAssetMap = pUtils.singlePolymerization(listRedis);//单个资产聚合
        groupAssetMap =pUtils.groupPolymerization(singleAssetMap);//分组资产聚合
        pUtils.allPolymerization(singleAssetMap);//整体资产聚合

        result.addAll(singleAssetMap);
        result.addAll(groupAssetMap);
        for (Map<String, Object> map : result) {
            System.out.println(map);
        }
        return result;
    }
}
