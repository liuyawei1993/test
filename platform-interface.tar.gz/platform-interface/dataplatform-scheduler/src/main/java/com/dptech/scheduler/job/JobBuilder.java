package com.dptech.scheduler.job;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/29 上午8:46
 * @description: TODO
 */
public interface JobBuilder {
    void build();
}
