package com.dptech.scheduler.util;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dptech.hbase.HbaseClient;
import com.dptech.redis.RedisLocalClient;
import com.dptech.util.ConfigUtils;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 资产聚合类
 * @author smart
 *
 */

public class PolymerizationUtils {
	private static final Logger LOGGER = LoggerFactory.getLogger(PolymerizationUtils.class);
	private HbaseClient hClient = new HbaseClient();
	private RedisLocalClient rClient = null;
	private SimpleDateFormat dateFormat = null;
    private ArrayList<String> groupArray = new ArrayList<>();
    private ArrayList<String> typeArray = new ArrayList<>();

	public  PolymerizationUtils(){

	}

    public  PolymerizationUtils(int slot, String fomat){
    	rClient = new RedisLocalClient();
    	rClient.setSlot(slot);
    	dateFormat = new SimpleDateFormat(fomat);
	}

    /**
     * 单个资产聚合
     * @param list,传入一个单个资产List集合
     *
     * 
     */
	public List<Map<String, Object>> singlePolymerization(List<Map<String, Object>> list) {
		List<Map<String, Object>> listmap = new ArrayList<Map<String,Object>>();
	    String period = dateFormat.format(new Date());
	    String oneDayAgo = getBeforeDate(1);
	    String sevenDayAgo = getBeforeDate(7);
	    String asset_id,asset_ip,asset_name,asset_type,probe_id,asset_risk_level,asset_open_protocol = null;
	    Integer hnl,mnl,lnl,hns,mns,lns,lsum,ssum = 0;
	    Integer asset_risk_yesterday, asset_risk_lastweek, asset_risk_now= null;
	    String asset_compare_to_yesterday, asset_compare_to_last_week = null;
	    String suspected_invasion = null;
	    
	    for (Map<String, Object> map : list) {
	    	asset_id = (String) map.get(HbaseConf.ASSET_ID);
	    	asset_ip = (String) map.get(HbaseConf.ASSET_IP);
	    	asset_name = (String) map.get(HbaseConf.ASSET_NAME);
	    	asset_type = (String) map.get(HbaseConf.ASSET_TYPE);
	    	probe_id = (String) map.get(HbaseConf.PROBE_ID);
	    	suspected_invasion = (String) map.get(HbaseConf.SUSPECTED_INVASION);
	    	hnl = Integer.valueOf((String) map.get(HbaseConf.HIGH_RISK_NUM_BY_LAUNCH_ATTACK));
	    	mnl = Integer.valueOf((String) map.get(HbaseConf.MEDIUM_RISK_NUM_BY_LAUNCH_ATTACK));
	    	lnl = Integer.valueOf((String) map.get(HbaseConf.LOW_RISK_NUM_BY_LAUNCH_ATTACK));
	    	hns = Integer.valueOf((String) map.get(HbaseConf.HIGH_RISK_NUM_BY_SUFFER_ATTACK));
	    	mns = Integer.valueOf((String) map.get(HbaseConf.MEDIUM_RISK_NUM_BY_SUFFER_ATTACK));
	    	lns = Integer.valueOf((String) map.get(HbaseConf.LOW_RISK_NUM_BY_SUFFER_ATTACK));
	    	lsum = hnl + mnl + lnl;
	        ssum = hns + mns + lns;
	        if("no".equals(suspected_invasion)) {
	        	asset_risk_now = assetRiskCalculate(hnl, mnl, hns, mns, lsum, ssum);
	        }else {
	        	asset_risk_now = 0;
	        }
//	    	asset_open_protocol = (String) map.get(HbaseConf.ASSET_OPEN_PROTOCOL);//通过es聚合获取
	    	asset_risk_yesterday = getAssetRisk(oneDayAgo, asset_id, HbaseConf.ASSET_RISK);
	    	asset_risk_lastweek = getAssetRisk(sevenDayAgo, asset_id, HbaseConf.ASSET_RISK);
	    	asset_compare_to_yesterday = getAssetcompare(asset_risk_now, asset_risk_yesterday);
	    	asset_compare_to_last_week = getAssetcompare(asset_risk_now, asset_risk_lastweek);
	    	asset_risk_level = getAssetRiskLevel(asset_risk_now, asset_risk_yesterday, map);
	    	assetRiskChangeJudgment(asset_risk_level, asset_id, asset_name, asset_type, getBeforeByHourTime(1));
	    	map.put(HbaseConf.ASSET_COMPARE_TO_YESTERDAY, asset_compare_to_yesterday);
	    	map.put(HbaseConf.ASSET_COMPARE_TO_LAST_WEEK, asset_compare_to_last_week);
			map.put(HbaseConf.RANGE, "single");
			map.put(HbaseConf.PERIOD, period);
			map.put(HbaseConf.ASSET_RISK_LEVEL, asset_risk_level);
			map.put(HbaseConf.HIGH_RISK_NUM_BY_LAUNCH_ATTACK, hnl);
			map.put(HbaseConf.MEDIUM_RISK_NUM_BY_LAUNCH_ATTACK, mnl);
			map.put(HbaseConf.LOW_RISK_NUM_BY_LAUNCH_ATTACK, lnl);
			map.put(HbaseConf.HIGH_RISK_NUM_BY_SUFFER_ATTACK, hns);
			map.put(HbaseConf.MEDIUM_RISK_NUM_BY_SUFFER_ATTACK, mns);
			map.put(HbaseConf.LOW_RISK_NUM_BY_SUFFER_ATTACK, lns);
			map.put("id",getRowkey(period,asset_id));
			map.put("table_name",HbaseConf.ASSET_RISK_LIST);
			map.remove("asset_org");
			listmap.add(map);
//			assetProtocolAndassetRiskLevelUpdate(probe_id, asset_ip, asset_risk_level, asset_open_protocol);//更新asset_list表里的资产风险等级和开放协议
		}
	    return listmap;
	}
	
	/**
	 * 分组聚合
	 * @param list
	 * 
	 */
	public List<Map<String, Object>> groupPolymerization(List<Map<String, Object>> list) {
		List<Map<String, Object>> listmap = new ArrayList<Map<String,Object>>();
		Map<String, Object> result = new HashMap<String, Object>();
	    String period = dateFormat.format(new Date());
	    Integer asset_risk = 0;
		String asset_level = null;
		for (Map<String, Object> map : list) {
			groupAssetLevelCount(result,map);
		}
		for (String key : result.keySet()) {
			@SuppressWarnings("unchecked")
			Map<String, Integer> groupMap = (Map<String, Integer>) result.get(key);
			asset_risk = calculate(groupMap.get(HbaseConf.SUSPECT_ASSET_NUM),groupMap.get(HbaseConf.SAFA_ASSET_NUM),groupMap.get(HbaseConf.LOW_RISK_ASSET_NUM),groupMap.get(HbaseConf.MEDIUM_RISK_ASSET_NUM),groupMap.get(HbaseConf.HIGH_RISK_ASSET_NUM));
			asset_level = getAssetLevel(asset_risk);
			Map<String, Object> rMap = typeChange(groupMap);
			rMap.put(HbaseConf.ASSET_RISK, asset_risk);
			rMap.put(HbaseConf.ASSET_RISK_LEVEL, asset_level);
			rMap.put(HbaseConf.PERIOD, period);
			rMap.put(HbaseConf.RANGE, "group");
			rMap.put("group_key", key);
			rMap.put("id",getRowkey(period,key));
			rMap.put("table_name",HbaseConf.ASSET_RISK_LIST);
			listmap.add(rMap);
		}
		groupArray.clear();
		return listmap;
   }
	
	/**
	 * 整体资产聚合
	 * @param list
	 *
	 * 
	 */
	public void allPolymerization(List<Map<String, Object>> list) {
		Map<String, Object> result = new HashMap<String, Object>();
	    String period = dateFormat.format(new Date());
	    String oneDayAgo = getBeforeDate(1);
	    String sevenDayAgo = getBeforeDate(7);
		Integer asset_risk = 0;
		String asset_level = null;
		Integer asset_risk_yesterday, asset_risk_lastweek = 0;
	    String asset_compare_to_yesterday, asset_compare_to_last_week = null;
	    Integer all_safe_num = 0,all_low_num = 0,all_medium_num = 0,all_high_num = 0,all_suspect_num = 0;
		for (Map<String, Object> map : list) {
			String type = (String) map.get(HbaseConf.ASSET_RISK_LEVEL);
			 switch(type){
             case "疑似被入侵":
            	 all_suspect_num++;         
                 break;
             case "安全":
            	 all_safe_num++;
                 break;
             case "低风险":
            	 all_low_num++;
                 break;
             case "中风险":
            	 all_medium_num++;
            	 break;
             case "高风险":
            	 all_high_num++;
            	 break;
         }
		}
		asset_risk = calculate(all_suspect_num, all_safe_num, all_low_num, all_medium_num, all_high_num);
		asset_level = getAssetLevel(asset_risk);
		asset_risk_yesterday = getAssetRisk(oneDayAgo, "all", HbaseConf.ASSET_RISK);
    	asset_risk_lastweek = getAssetRisk(sevenDayAgo, "all", HbaseConf.ASSET_RISK);
    	asset_compare_to_yesterday = getAssetcompare(asset_risk, asset_risk_yesterday);
    	asset_compare_to_last_week = getAssetcompare(asset_risk, asset_risk_lastweek);
    	
    	result.put(HbaseConf.ASSET_RISK, asset_risk);
    	result.put(HbaseConf.ASSET_RISK_LEVEL, asset_level);
    	result.put(HbaseConf.SAFA_ASSET_NUM, all_safe_num);
    	result.put(HbaseConf.LOW_RISK_ASSET_NUM, all_low_num);
    	result.put(HbaseConf.MEDIUM_RISK_ASSET_NUM, all_medium_num);
    	result.put(HbaseConf.HIGH_RISK_ASSET_NUM, all_high_num);
    	result.put(HbaseConf.SUSPECT_ASSET_NUM, all_suspect_num);
    	result.put(HbaseConf.ASSET_COMPARE_TO_YESTERDAY, asset_compare_to_yesterday);
    	result.put(HbaseConf.ASSET_COMPARE_TO_LAST_WEEK, asset_compare_to_last_week);
    	result.put(HbaseConf.PERIOD, period);
    	result.put(HbaseConf.RANGE, "all");
		hClient.insertRecord(HbaseConf.ASSET_RISK_LIST,getRowkey(period, "all"),result);
	}
	
	/**
	 * hbase asset_aggs_list表聚合
	 * @param list
	 * @param query_type
	 */
	public void aggsPolymerization(List<Map<String, Object>> list, String query_type){
		switch (query_type) {
			case "asset_group":
				 aggsGroup(list);
				 break;
			case "asset_type":
	       	 	 aggsType(list);
				 break;
	        case "asset_risk":
	       	 	aggsRisk();
				break;
		}
	}
	
	public void aggsType(List<Map<String, Object>> list) {
		Map<String, Object> result = new HashMap<>();
		JSONObject jsonObject = new JSONObject();
		String asset_type = null;
		for (Map<String, Object> map : list) {
			asset_type = (String) map.get(HbaseConf.ASSET_TYPE);
			Boolean flag = typeArray.contains(asset_type);
			if(!flag) {
				typeArray.add(asset_type);
				jsonObject.put(asset_type, 1);
			}else {
				jsonObject.put(asset_type, jsonObject.getIntValue(asset_type) + 1);
			}
		}
		result.put("query_type", "asset_type");
		result.put("query_value", jsonObject.toString());
		hClient.insertRecord(HbaseConf.ASSET_AGGS_LIST, getRowkey("asset_aggs", "asset_type"), result);
	}
	
	private void aggsRisk() {
		String period = dateFormat.format(new Date());
		period = period.substring(0,period.length()-2);
		Set<String> keySet = rClient.keys("asset_weight"+period);
		Set<String> set = null;
		for (String key : keySet) {
			set = rClient.zrange(key);
		}
		List<String> list = new ArrayList<>(set);
		Collections.reverse(list);
		List<Object> map = rClient.hmget(list);
		String asset_name, asset_risk_level,suspected_invasion = null;
		Integer hnl,mnl,lnl,hns,mns,lns,lsum,ssum,asset_risk_now= 0;
		JSONArray jsonArray = new JSONArray();
		Map<String, Object> result = new HashMap<>();
		for (Object o : map) {
			if(o instanceof  Map){
				Map<String,String> assetRiskMap = (Map<String, String>) o;
				JSONObject jsonObject = new JSONObject();
				asset_name = assetRiskMap.get(HbaseConf.ASSET_NAME);
				suspected_invasion = assetRiskMap.get(HbaseConf.SUSPECTED_INVASION);
				hnl = Integer.valueOf(assetRiskMap.get(HbaseConf.HIGH_RISK_NUM_BY_LAUNCH_ATTACK));
				mnl = Integer.valueOf(assetRiskMap.get(HbaseConf.MEDIUM_RISK_NUM_BY_LAUNCH_ATTACK));
				lnl = Integer.valueOf(assetRiskMap.get(HbaseConf.LOW_RISK_NUM_BY_LAUNCH_ATTACK));
				hns = Integer.valueOf(assetRiskMap.get(HbaseConf.HIGH_RISK_NUM_BY_SUFFER_ATTACK));
				mns = Integer.valueOf(assetRiskMap.get(HbaseConf.MEDIUM_RISK_NUM_BY_SUFFER_ATTACK));
				lns = Integer.valueOf(assetRiskMap.get(HbaseConf.LOW_RISK_NUM_BY_SUFFER_ATTACK));
				lsum = hnl + mnl + lnl;
				ssum = hns + mns + lns;
				if("no".equals(suspected_invasion)) {
					asset_risk_now = assetRiskCalculate(hnl, mnl, hns, mns, lsum, ssum);
				}else {
					asset_risk_now = 0;
				}
				asset_risk_level = getAssetLevel(asset_risk_now);
				jsonObject.put(HbaseConf.ASSET_NAME, asset_name);
				jsonObject.put(HbaseConf.ALL_NUM_SUFFER_ATTACK, lsum);
				jsonObject.put(HbaseConf.ASSET_RISK_LEVEL, asset_risk_level);
				jsonArray.add(jsonObject);
			}
		}
		result.put("query_type", "asset_risk");
		result.put("query_value", jsonArray.toJSONString());
		hClient.insertRecord(HbaseConf.ASSET_AGGS_LIST, getRowkey("asset_aggs", "asset_risk"), result);
	}

	private void aggsGroup(List<Map<String, Object>> list) {
		Map<String, Object> result = new HashMap<>();
		JSONObject jsonObject = new JSONObject();
		Integer assetCount, safe_num ,low_num ,medium_num ,high_num ,suspect_num = 0;
		String str = null;
		String group[] = null;
		for (Map<String, Object> groupMap : list) {
			safe_num = (Integer) groupMap.get(HbaseConf.SAFA_ASSET_NUM);
			low_num = (Integer) groupMap.get(HbaseConf.LOW_RISK_ASSET_NUM);
			medium_num = (Integer) groupMap.get(HbaseConf.MEDIUM_RISK_ASSET_NUM);
			high_num = (Integer) groupMap.get(HbaseConf.HIGH_RISK_ASSET_NUM);
			suspect_num = (Integer) groupMap.get(HbaseConf.SUSPECT_ASSET_NUM);
			assetCount = safe_num + low_num + medium_num + high_num + suspect_num;
			str = (String)groupMap.get("group_key");
			group = str.split(",");
			jsonObject.put(group[1], assetCount);
		}
		result.put("query_type", "asset_group");
		result.put("query_value", jsonObject.toString());
		hClient.insertRecord(HbaseConf.ASSET_AGGS_LIST, getRowkey("asset_aggs", "asset_group"), result);
	}

	/**
	 * 判断资产风险是否有变更，若发生变更往hbase的asset_risk_change表插入一条数据
	 * @param asset_risk_level_now 风险等级
	 * @param asset_id 资产ID
	 * @param asset_name 资产名字
	 * @param asset_type 资产类型
	 * @param period 前一小时，格式：yyyyMMddHH
	 */
	private void assetRiskChangeJudgment(String asset_risk_level_now, String asset_id, String asset_name, String asset_type, String period) {
		String asset_risk_level_before = null;
		Map<String, Object> map = null;
		asset_risk_level_before = hClient.getValue(HbaseConf.ASSET_RISK_LIST, getRowkey(period, asset_id), HbaseConf.ASSET_RISK_LEVEL, null);
		if(null != asset_risk_level_before && !asset_risk_level_now.equals(asset_risk_level_before)) {
			map = new HashMap<>();
			String time = String.valueOf(System.currentTimeMillis());
	        map.put("asset_id", asset_id);
	        map.put("asset_name", asset_name);
	        map.put("asset_type", asset_type);
	        map.put("asset_risk_level_change_before", asset_risk_level_before);
	        map.put("asset_risk_level_change_after", asset_risk_level_now);
	        map.put("asset_risk_change_time", time);
			hClient.insertRecord(HbaseConf.ASSET_RISK_CHANGE,getRowkey(HbaseConf.TYPE_RISK,asset_id),map);
		}
	}

	/**
	 * 计算风险数值
	 * @param hnl 发起的高危攻击次数
	 * @param mnl 发起的中危攻击次数
	 * @param hns 遭受的高危攻击次数
	 * @param mns 遭受的中危攻击次数
	 * @param lsum 发起的攻击总次数
	 * @param ssum 遭受的攻击总次数
	 * @return 风险数值
	 */
	private Integer assetRiskCalculate(Integer hnl, Integer mnl, Integer hns, Integer mns,Integer lsum, Integer ssum) {
		Integer ars = null;
		if(0 == lsum && 0 != ssum){
            ars = 95 - (hns*15 + mns*5)/ssum;
            return ars;
        }else if(0 != lsum && 0 == ssum){
            ars = 95 - (hnl*35 + mnl*15)/lsum;
            return ars;
        }else if(0 != lsum && 0 != ssum){
            ars = 90 - (hnl*35 + mnl*15)/lsum - (hns*15 + mns*5)/ssum;
            return ars;
        }else{
            return 100;
        }
	}

	/**
	 * 获取资产的风险等级
	 * @param asset_risk_now 现在的风险值
	 * @param asset_risk_yesterday 前一天的风险值
	 * @return 风险等级
	 */
	private String getAssetRiskLevel(Integer asset_risk_now, Integer asset_risk_yesterday, Map<String, Object> map) {
		String asset_level_now = getAssetLevel(asset_risk_now);
		if(null == asset_risk_yesterday ) {
			map.put(HbaseConf.ASSET_RISK, asset_risk_now);
			return asset_level_now;
		}
		String asset_level_yesterday = getAssetLevel(asset_risk_yesterday);
		if(asset_level_now.equals(asset_level_yesterday)){
			map.put(HbaseConf.ASSET_RISK, asset_risk_now);
			return asset_level_now;
		}
		Integer score = null;
		score = Integer.valueOf(ConfigUtils.getString(asset_level_yesterday));
		if(asset_risk_now > score) {
			asset_level_now = getAssetLevel(asset_risk_now - score);
			map.put(HbaseConf.ASSET_RISK, asset_risk_now - score);
			return asset_level_now;
		}else {
			map.put(HbaseConf.ASSET_RISK, asset_risk_now);
			return asset_level_now;
		}
	}
	
	private void groupAssetLevelCount(Map<String, Object> result, Map<String, Object> map) {
		String type = (String) map.get(HbaseConf.ASSET_RISK_LEVEL);
		String group = (String) map.get(HbaseConf.ASSET_GROUP);
		String probe_id = (String) map.get(HbaseConf.PROBE_ID);
		String groupId[] = group.split(",");
		for (String id : groupId) {
			Boolean flag = groupArray.contains(probe_id+","+id);
			if(!flag) {
				groupArray.add(probe_id+","+id);
				Map<String, Object> groupMap = new HashMap<>();
				groupMap.put(HbaseConf.HIGH_RISK_ASSET_NUM,0);
				groupMap.put(HbaseConf.MEDIUM_RISK_ASSET_NUM, 0);
				groupMap.put(HbaseConf.LOW_RISK_ASSET_NUM, 0);
				groupMap.put(HbaseConf.SAFA_ASSET_NUM, 0);
				groupMap.put(HbaseConf.SUSPECT_ASSET_NUM, 0);
				groupMap.put(HbaseConf.ASSET_GROUP, id);
				assetLevelCount(type,groupMap);
				result.put(probe_id+","+id, groupMap);
			}else {
				@SuppressWarnings("unchecked")
				Map<String, Object> groupMap = (Map<String, Object>) result.get(probe_id+","+id);
				assetLevelCount(type,groupMap);
				result.put(probe_id+","+id, groupMap);
			}
		}
	}
	
	private void assetLevelCount(String type, Map<String, Object> groupMap) {
		switch(type){
        case "疑似被入侵":
       	 groupMap.put(HbaseConf.SUSPECT_ASSET_NUM,(Integer) groupMap.get(HbaseConf.SUSPECT_ASSET_NUM)+1);
            break;
        case "安全":
       	 groupMap.put(HbaseConf.SAFA_ASSET_NUM, (Integer) groupMap.get(HbaseConf.SAFA_ASSET_NUM)+1);
            break;
        case "低风险":
       	 groupMap.put(HbaseConf.LOW_RISK_ASSET_NUM, (Integer) groupMap.get(HbaseConf.LOW_RISK_ASSET_NUM)+1);
            break;
        case "中风险":
       	 groupMap.put(HbaseConf.MEDIUM_RISK_ASSET_NUM, (Integer) groupMap.get(HbaseConf.MEDIUM_RISK_ASSET_NUM)+1);
       	 break;
        case "高风险":
       	 groupMap.put(HbaseConf.HIGH_RISK_ASSET_NUM, (Integer)groupMap.get(HbaseConf.HIGH_RISK_ASSET_NUM)+1);
       	 break;
		}
	}
	/**
	 * 更新asset_list表里面的资产风险等级和开放协议
	 * @param probe_id
	 * @param asset_ip
	 * @param asset_risk_level
	 * @param asset_open_protocol
	 */
	private void assetProtocolAndassetRiskLevelUpdate(String probe_id, String asset_ip, String asset_risk_level,
			String asset_open_protocol) {
		Map<String, Object> map = new HashMap<>();
		map.put(HbaseConf.ASSET_RISK_LEVEL, asset_risk_level);
		map.put(HbaseConf.ASSET_OPEN_PROTOCOL, asset_open_protocol);
//		hClient.insertRecord("asset_list", hClient.setRowkey(probe_id, asset_ip), map);
	}
	
	/**
	 * 计算前几日时间。
	 * @param sum
	 * @return
	 */
	public String getBeforeDate(int sum) {
	    Calendar c = Calendar.getInstance();           
	    c.add(Calendar.DATE, - sum);           
	    Date time = c.getTime();         
	    String preDay = dateFormat.format(time);
		return preDay;
	}
	
	/**
	 * 计算前几日时间。
	 * @param ihour
	 * @return
	 */
	public String getBeforeByHourTime(int ihour) {
		String returnstr = "";
		Calendar calendar = Calendar.getInstance(); 
		calendar.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY) - ihour); 
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHH");
		returnstr = df.format(calendar.getTime());
		return returnstr;
	}
	/**
	 * 从hbase中获取指定时间段的风险值。
	 * @param type
	 * @param indicator
	 * @param score
	 * @return
	 */
	private Integer getAssetRisk(String type, String indicator, String score) {
		String asset_risk = null;
		try {
			String rowkey = getRowkey(type, indicator);
			asset_risk = hClient.getValue(HbaseConf.ASSET_RISK_LIST, rowkey, score, "int");
		} catch (Exception e) {
			LOGGER.error("Failed to get asset risk value. Exception: {}",e.toString());
		}
		if(null != asset_risk) {
			return Integer.valueOf(asset_risk);
		}else {
			return null ;
		}	
	}
	
	/**
	 * 环比同比计算
	 * @param var1
	 * @param var2
	 * @return
	 */
	private String getAssetcompare(Integer var1, Integer var2) {
	    if(null !=var2 && 0 == var2){
	        return String.valueOf((var1-var2)*100);
        }
		return null != var2 ? String.valueOf((var1-var2)*100/var2) : "100";
	}
	
	/**
	 * 风险值计算
	 * @param suspect_num，可疑数量
	 * @param safe_num，安全数量
	 * @param low_num，低危数量
	 * @param medium_num，中危数量
	 * @param high_num，高危数量
	 * @return
	 */
	private Integer calculate(Integer suspect_num,Integer safe_num,Integer low_num,Integer medium_num,Integer high_num) {
		Integer sum ,ars = 0;
		sum = safe_num + suspect_num + low_num + medium_num + high_num;
		if(0 == sum) {
			LOGGER.error("Risk value calculation failed, asset_risk = {}.",sum);
			return 100;
		}
		ars = 100-(suspect_num*40 + high_num*30 + medium_num*20 + low_num*10)/sum;
		return ars;
	}
	
	/**
	 * 获取危险等级
	 * @param ars
	 * @return
	 */
	private String getAssetLevel(Integer ars) {
		if(0 == ars) {
			return "疑似被入侵";
		}else if(ars >= 90) {
			return "安全";
		}else if (70 <= ars && ars < 90) {
			return "低风险";
		}else if (50 <= ars && ars < 70) {
			return "中风险";
		}else {
			return "高风险";
		}
	}
	
	private Map<String, Object> typeChange(Map<String, Integer> map) {
		Map<String, Object> map2 = new HashMap<>();
		map2.putAll(map);
		return map2;	
	}

	/**
	 * 设置hbase rowkey
	 * @param type
	 * @param indicator
	 * @return
	 */
	public String getRowkey(String type, String indicator){
		byte[] indicatorBytes = new byte[0];
		try {
			indicatorBytes = typedIndicatorToBytes(type,indicator);
		} catch (IOException e) {
			throw new RuntimeException("Unable to convert type and indicator to bytes", e);
		}
		byte[] prefix = KeyUtil.getPrefix(Bytes.toBytes(indicator));
		return Base64.getEncoder().encodeToString(KeyUtil.merge(prefix, indicatorBytes));
	}

	public byte[] typedIndicatorToBytes(String type, String indicator) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream w = new DataOutputStream(baos);
		w.writeUTF(type);
		w.writeUTF(indicator);
		w.flush();
		return baos.toByteArray();
	}
}
