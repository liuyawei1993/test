package com.dptech.scheduler.util;

import org.apache.hadoop.hdfs.server.namenode.status_jsp;

/**
 * asset_risk_list中所有字段名
 * @author smart
 */
public class HbaseConf {
	public static final String RANGE = "range";
	public static final String PERIOD = "period";
	public static final String PROBE_ID = "asset_org_id";
	public static final String SUSPECTED_INVASION ="suspected_invasion";
	public static final String ASSET_OPEN_PROTOCOL = "asset_open_protocol";
	public static final String ASSET_IP = "asset_ip";
	public static final String ASSET_ID = "asset_id";
	public static final String ASSET_WEIGHT = "asset_weight";
	public static final String ASSET_NAME = "asset_name";
	public static final String ASSET_TYPE = "asset_type";
	public static final String ASSET_GROUP = "asset_group";
	public static final String ASSET_RISK = "asset_risk";
	public static final String ASSET_RISK_LEVEL = "asset_risk_level";
	public static final String HIGH_RISK_NUM_BY_LAUNCH_ATTACK = "high_risk_num_by_launch_attack";
	public static final String MEDIUM_RISK_NUM_BY_LAUNCH_ATTACK = "medium_risk_num_by_launch_attack";
	public static final String LOW_RISK_NUM_BY_LAUNCH_ATTACK = "low_risk_num_by_launch_attack";
	public static final String HIGH_RISK_NUM_BY_SUFFER_ATTACK = "high_risk_num_by_suffer_attack";
	public static final String MEDIUM_RISK_NUM_BY_SUFFER_ATTACK = "medium_risk_num_by_suffer_attack";
	public static final String LOW_RISK_NUM_BY_SUFFER_ATTACK = "low_risk_num_by_suffer_attack";
	public static final String ASSET_COMPARE_TO_LAST_WEEK = "asset_compare_to_last_week";
	public static final String ASSET_COMPARE_TO_YESTERDAY = "asset_compare_to_yesterday";
	public static final String SAFA_ASSET_NUM = "safe_asset_num";
	public static final String LOW_RISK_ASSET_NUM = "low_risk_asset_num";
	public static final String MEDIUM_RISK_ASSET_NUM = "medium_risk_asset_num";
	public static final String HIGH_RISK_ASSET_NUM = "high_risk_asset_num";
	public static final String SUSPECT_ASSET_NUM = "suspect_asset_num";
	public static final String ALL_NUM_SUFFER_ATTACK = "all_num_suffer_attack";
	
	public static final String ASSET_RISK_LIST = "asset_risk_list";
	public static final String ASSET_LIST = "asset_list";
	public static final String ASSET_AGGS_LIST = "asset_aggs_list";
	public static final String ASSET_RISK_CHANGE ="asset_risk_change";
	public static final String TYPE_RISK = "risk_change";
}
