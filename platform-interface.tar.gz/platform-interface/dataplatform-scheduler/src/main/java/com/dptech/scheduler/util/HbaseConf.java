package com.dptech.scheduler.util;

/**
 * asset_risk_list中所有字段名
 * @author smart
 */
public interface HbaseConf {
	String RANGE = "range";
	String PERIOD = "period";
	String PROBE_ID = "asset_org_id";
	String SUSPECTED_INVASION ="suspected_invasion";
	String ASSET_OPEN_PROTOCOL = "asset_open_protocol";
	String ASSET_IP = "asset_ip";
	String ASSET_ID = "asset_id";
	String ASSET_WEIGHT = "asset_weight";
	String ASSET_NAME = "asset_name";
	String ASSET_TYPE = "asset_type";
	String ASSET_GROUP = "asset_group";
	String ASSET_RISK = "asset_risk";
	String ASSET_RISK_LEVEL = "asset_risk_level";
	String HIGH_RISK_NUM_BY_LAUNCH_ATTACK = "high_risk_num_by_launch_attack";
	String MEDIUM_RISK_NUM_BY_LAUNCH_ATTACK = "medium_risk_num_by_launch_attack";
	String LOW_RISK_NUM_BY_LAUNCH_ATTACK = "low_risk_num_by_launch_attack";
	String HIGH_RISK_NUM_BY_SUFFER_ATTACK = "high_risk_num_by_suffer_attack";
	String MEDIUM_RISK_NUM_BY_SUFFER_ATTACK = "medium_risk_num_by_suffer_attack";
	String LOW_RISK_NUM_BY_SUFFER_ATTACK = "low_risk_num_by_suffer_attack";
	String ASSET_COMPARE_TO_LAST_WEEK = "asset_compare_to_last_week";
	String ASSET_COMPARE_TO_YESTERDAY = "asset_compare_to_yesterday";
	String SAFA_ASSET_NUM = "safe_asset_num";
	String LOW_RISK_ASSET_NUM = "low_risk_asset_num";
	String MEDIUM_RISK_ASSET_NUM = "medium_risk_asset_num";
	String HIGH_RISK_ASSET_NUM = "high_risk_asset_num";
	String SUSPECT_ASSET_NUM = "suspect_asset_num";
	String ALL_NUM_SUFFER_ATTACK = "all_num_suffer_attack";
	
	String ASSET_RISK_LIST = "asset_risk_list";
	String ASSET_LIST = "asset_list";
	String ASSET_AGGS_LIST = "asset_aggs_list";
	String ASSET_RISK_CHANGE ="asset_risk_change";
	String TYPE_RISK = "risk_change";
}
