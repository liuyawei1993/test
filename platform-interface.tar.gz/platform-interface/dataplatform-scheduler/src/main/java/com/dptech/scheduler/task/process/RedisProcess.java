package com.dptech.scheduler.task.process;

import com.alibaba.fastjson.JSON;

import java.util.*;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/20 下午5:01
 * @description: TODO
 */
public class RedisProcess implements ProcessFactory {
    @Override
    public List<Map<String, Object>> exec(List<String> jsonDataList) {
        return new ArrayList<Map<String, Object>>() {{
            JSON.parseArray(jsonDataList.get(0), Map.class).forEach((ja) -> {
                ja.put("id", UUID.randomUUID());
                add(ja);
            });
        }};
    }
}
