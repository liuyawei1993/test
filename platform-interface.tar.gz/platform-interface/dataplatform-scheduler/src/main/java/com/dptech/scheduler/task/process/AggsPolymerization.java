package com.dptech.scheduler.task.process;


import com.dptech.scheduler.util.PolymerizationUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * 关于asset_aggs_list表的聚合
 *
 * @author smart
 */
public class AggsPolymerization implements ProcessFactory {
    private static PolymerizationUtils pUtils = new PolymerizationUtils(3, "yyyyMMdd");

    @Override
    public List<Map<String, Object>> exec(List<String> jsonDataList) {
        pUtils.aggsPolymerization();
        return Collections.emptyList();
    }
}
