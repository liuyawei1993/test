package com.dptech.scheduler.util;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/18 上午11:46
 * @description: TODO
 */
public final class CustomClassLoader {
    private final static URLClassLoader URL_CLASS_LOADER = (URLClassLoader) ClassLoader.getSystemClassLoader();

    private CustomClassLoader() {
    }


    /**
     * load jar to classpath
     *
     * @param path
     * @throws Exception
     */
    public static void load(String path) throws Exception {
        Method method = URLClassLoader.class.getDeclaredMethod("addURL", new Class[]{URL.class});
        method.setAccessible(true);

        File[] jars = new File(path).listFiles((file, s) -> s.endsWith("jar"));
        for (File jar : jars) {
            method.invoke(URL_CLASS_LOADER, new Object[]{jar.toURI().toURL()});
        }
    }
}
