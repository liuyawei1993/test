package com.dptech.scheduler.task.sink;

import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.util.ReflectionsUtils;
import com.dptech.util.ObjectUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/15 下午1:34
 * @description: TODO
 */
public abstract class SinkFactory {
    private final String TABLE_NAME_FIELD = "table_name";
    public final String DEFAULT_TABLE_NAME = "default";

    public static SinkFactory getSinkFactory(String type) throws IllegalAccessException, InstantiationException {
        List<Class> allSubclass = ReflectionsUtils.getAllSubclass(SinkFactory.class);
        for (Class subclass : allSubclass) {
            if (subclass.getSimpleName().equals(type + "Sink")) {
                return (SinkFactory) subclass.newInstance();
            }
        }
        return null;
    }

    /**
     * split table
     *
     * @param data
     * @return
     */
    public Map<String, List<Map<String, Object>>> dipartTable(List<Map<String, Object>> data) {
        return new HashMap<String, List<Map<String, Object>>>() {{
            data.forEach(dataMap -> {
                Object remove = dataMap.remove(TABLE_NAME_FIELD);
                String tableName = ObjectUtils.isNull(remove) ? DEFAULT_TABLE_NAME : (String) remove;
                List<Map<String, Object>> mapList = get(tableName);
                if (null == mapList) {
                    mapList = new ArrayList<>();
                    mapList.add(dataMap);
                    put(tableName, mapList);
                } else {
                    mapList.add(dataMap);
                }
            });
        }};
    }

    public abstract void exec(List<Map<String, Object>> data, SchedulerYaml.Output output) throws Exception;

}
