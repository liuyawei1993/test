package com.dptech.scheduler.exception;

/**
 * @author jelly.wang
 * @ClassName: EsException
 * @Description:
 * @date 2017/12/14
 */
public class SchedulerException extends Exception {

    public SchedulerException(String message) {
        super(message);
    }

    public SchedulerException(String message, Throwable cause) {
        super(message, cause);
    }
}
