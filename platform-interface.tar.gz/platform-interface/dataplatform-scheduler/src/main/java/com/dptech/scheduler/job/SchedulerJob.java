package com.dptech.scheduler.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.dptech.scheduler.common.SchedulerConstants.SCHEDULER_TASK_QUEUE;
import static com.dptech.scheduler.job.SchedulerManager.SCHEDULER_TASK_PARAM_NAME;

public class SchedulerJob implements Job {
    private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerJob.class);

    /**
     * 往队列中放入要执行的离线任务
     *
     * @param context
     * @throws JobExecutionException
     */
    @Override
    public void execute(JobExecutionContext context) {
        SchedulerJobDetail schedulerJobDetail = (SchedulerJobDetail) context.getJobDetail().getJobDataMap().get(SCHEDULER_TASK_PARAM_NAME);
        LOGGER.info("SCHEDULER_TASK_QUEUE size is [" + SCHEDULER_TASK_QUEUE.size() + "],and will offer the " + schedulerJobDetail + " to it");
        boolean offer = SCHEDULER_TASK_QUEUE.offer(schedulerJobDetail);
        if (!offer) {
            LOGGER.warn("SCHEDULER_TASK_QUEUE is full,[yaml=>]" + schedulerJobDetail);
            // 队列满了
        }


    }
}
