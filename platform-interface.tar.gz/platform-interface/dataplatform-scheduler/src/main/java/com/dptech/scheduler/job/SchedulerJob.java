package com.dptech.scheduler.job;

import com.dptech.scheduler.listener.SchedulerTaskListener;
import com.dptech.util.DateUtils;
import org.quartz.CronExpression;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.Date;

import static com.dptech.scheduler.common.SchedulerConstants.SCHEDULER_TASK_QUEUE;
import static com.dptech.scheduler.job.SchedulerManager.SCHEDULER_TASK_PARAM_NAME;

public class SchedulerJob implements Job {
    private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerJob.class);

    /**
     * 往队列中放入要执行的离线任务
     *
     * @param context
     * @throws JobExecutionException
     */
    @Override
    public synchronized void execute(JobExecutionContext context) {
        SchedulerJobDetail schedulerJobDetail = (SchedulerJobDetail) context.getJobDetail().getJobDataMap().get(SCHEDULER_TASK_PARAM_NAME);
        schedulerJobDetail.setStartJobTime(DateUtils.getCurrentDateTime().getTime());
        try {
            CronExpression cronExpression = new CronExpression(schedulerJobDetail.getCron());
            schedulerJobDetail.setEndJobTime(cronExpression.getNextValidTimeAfter(new Date()).getTime());
            Long taskExecTime = SchedulerTaskListener.TASK_EXEC_TIME.get(schedulerJobDetail.getName());
            if (null != taskExecTime) {
                schedulerJobDetail.setExpectTime(taskExecTime);
            }
        } catch (ParseException e) {
            LOGGER.error(e.getMessage(), e);
        }

        LOGGER.info("SCHEDULER_TASK_QUEUE size is [" + SCHEDULER_TASK_QUEUE.size() + "],and will offer the " + schedulerJobDetail + " to it");
        boolean offer = SCHEDULER_TASK_QUEUE.offer(schedulerJobDetail);
        if (!offer) {
            LOGGER.warn("SCHEDULER_TASK_QUEUE is full,[yaml=>]" + schedulerJobDetail);
            TaskQueueCheckJobBuilder.checkTask();
        }
    }
}
