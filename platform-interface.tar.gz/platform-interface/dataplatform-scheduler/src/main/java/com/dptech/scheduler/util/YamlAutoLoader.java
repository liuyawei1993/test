package com.dptech.scheduler.util;

import com.alibaba.fastjson.JSON;
import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.job.YamlJobBuilder;
import com.dptech.util.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by jelly.wang on 2019/09/12
 */
public final class YamlAutoLoader {
    private static final Logger LOGGER = LoggerFactory.getLogger(YamlAutoLoader.class);

    private YamlAutoLoader() {
    }

    /**
     * init load
     */
    public static void load(String path) {
        final List<SchedulerYaml> schedulerYamlList = new ArrayList<>();
        try {
            final Yaml yaml = new Yaml();
            File yamlDir = new File(path);
            if (yamlDir.exists() && yamlDir.isDirectory()) {
                File[] yamlFiles = yamlDir.listFiles();
                for (File yf : yamlFiles) {
                    if (yf.getName().endsWith("yaml")) {
                        Map map = yaml.load(new FileInputStream(yf));
                        SchedulerYaml schedulerYaml = JSON.parseObject(JSON.toJSONString(map), SchedulerYaml.class);
                        // parameter check
                        if (!ObjectUtils.hasNullValue(schedulerYaml))
                            schedulerYamlList.add(schedulerYaml);
                    }
                }
            }

            new YamlJobBuilder(schedulerYamlList).build();

        } catch (Exception e) {
            LOGGER.error("yaml load error => ", e);
        }
    }
}




