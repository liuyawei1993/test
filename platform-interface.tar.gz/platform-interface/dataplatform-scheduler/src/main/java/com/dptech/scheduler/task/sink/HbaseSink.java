package com.dptech.scheduler.task.sink;

import com.dptech.hbase.HbaseClient;
import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.util.IStringUtils;
import com.dptech.util.ObjectUtils;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/16 下午2:27
 * @description: TODO
 */
public class HbaseSink extends SinkFactory {
    private final static Logger LOGGER = Logger.getLogger(SinkFactory.class);
    private final String FAMILY = "t";

    @Override
    public void exec(List<Map<String, Object>> data, SchedulerYaml.Output output) throws Exception {
        HbaseClient hbaseClient = new HbaseClient();
        // multi table
        dipartTable(data).forEach((tableName, dataMaps) -> {
            if (tableName.equals(DEFAULT_TABLE_NAME)) tableName = output.getTable();

            List<Put> putList = new ArrayList<>();
            dataMaps.forEach((dataMap) -> {
                Object idObject = dataMap.get("id");
                if (!ObjectUtils.isNull(idObject)) {
                    byte[] id;
                    if (idObject instanceof byte[]) id = (byte[]) idObject;
                    else id = Bytes.toBytes(idObject.toString());
                    Put put = new Put(id);
                    dataMap.forEach((k, v) -> {
                        if(v instanceof Integer){
                            put.addColumn(Bytes.toBytes(FAMILY), Bytes.toBytes(k), Bytes.toBytes(v == null ? Integer.valueOf(IStringUtils.EMPTY) : Integer.valueOf(v.toString())));
                        }else {
                            put.addColumn(Bytes.toBytes(FAMILY), Bytes.toBytes(k), Bytes.toBytes(v == null ? IStringUtils.EMPTY : v.toString()));
                        }
                    });
                    putList.add(put);
                } else {
                    LOGGER.warn("ID does not exist");
                    return;
                }
            });

            if (putList.size() > 0) {
                try {
                    hbaseClient.inserts(tableName, putList);
                } catch (Exception e) {
                    LOGGER.error(e.getMessage(), e);
                }
            }
        });
    }
}
