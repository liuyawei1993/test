package com.dptech.scheduler.task.sink;

import com.dptech.hbase.HbaseClient;
import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.util.IStringUtils;
import com.dptech.util.ObjectUtils;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/16 下午2:27
 * @description: TODO
 */
public class HbaseSink extends SinkFactory {
    private final static Logger LOGGER = Logger.getLogger(SinkFactory.class);
    private final String FAMILY = "t";

    @Override
    public void exec(List<Map<String, Object>> data, SchedulerYaml.Output output) throws Exception {
        HbaseClient hbaseClient = new HbaseClient();
        // multi table
        dipartTable(data).forEach((tableName, dataMaps) -> {
            if (tableName.equals(DEFAULT_TABLE_NAME)) tableName = output.getTable();

            List<Put> putList = new ArrayList<>();
            dataMaps.forEach((dataMap) -> {
                Object idObject = dataMap.remove("id");
                if (!ObjectUtils.isNull(idObject)) {
                    byte[] id;
                    if (idObject instanceof byte[]) id = (byte[]) idObject;
                    else id = Bytes.toBytes(idObject.toString());
                    Put put = new Put(id);
                    dataMap.forEach((k, v) -> put.addColumn(Bytes.toBytes(FAMILY), Bytes.toBytes(k), obtainBytes(v)));
                    putList.add(put);
                } else {
                    LOGGER.warn("ID does not exist");
                    return;
                }
            });

            if (putList.size() > 0) {
                try {
                    hbaseClient.inserts(tableName, putList);
                } catch (Exception e) {
                    LOGGER.error(e.getMessage(), e);
                }
            }
        });
    }

    private byte[] obtainBytes(Object obj) {
        byte[] result = null;
        if (ObjectUtils.isNull(obj)) {
            result = Bytes.toBytes(IStringUtils.EMPTY);
        } else if (obj instanceof String) {
            result = Bytes.toBytes(obj.toString());
        } else if (obj instanceof Integer) {
            result = Bytes.toBytes(Integer.valueOf(obj.toString()));
        } else if (obj instanceof Long) {
            result = Bytes.toBytes(Long.valueOf(obj.toString()));
        } else if (obj instanceof Double) {
            result = Bytes.toBytes(Double.valueOf(obj.toString()));
        } else if (obj instanceof Float) {
            result = Bytes.toBytes(Float.valueOf(obj.toString()));
        } else if (obj instanceof Boolean) {
            result = Bytes.toBytes(Boolean.valueOf(obj.toString()));
        } else if (obj instanceof Short) {
            result = Bytes.toBytes(Short.valueOf(obj.toString()));
        }
        return result;
    }
}