package com.dptech.scheduler.task.source;


import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.exception.SchedulerException;
import com.dptech.scheduler.util.ReflectionsUtils;
import com.dptech.util.DateUtils;

import java.util.List;

import static com.dptech.scheduler.common.SchedulerConstants.SWAP_END_STRING;
import static com.dptech.scheduler.common.SchedulerConstants.SWAP_START_STRING;
import static com.dptech.util.DateUtils.DATE_FMT_0;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/15 下午1:34
 * @description: TODO
 */
public abstract class SourceFactory {
    public static SourceFactory getSourceFactory(String type) throws IllegalAccessException, InstantiationException {
        List<Class> allSubclass = ReflectionsUtils.getAllSubclass(SourceFactory.class);
        for (Class subclass : allSubclass) {
            if (subclass.getSimpleName().equals(type + "Source")) {
                return (SourceFactory) subclass.newInstance();
            }
        }
        return null;
    }


    public static String paramsAssign(String exp) {
        if (exp.contains(SWAP_START_STRING) && exp.contains(SWAP_END_STRING)) {
            // date convert
            if (exp.contains("date"))
                exp = exp.replace(SWAP_START_STRING + "date" + SWAP_END_STRING, DateUtils.getCurrentDateTime(DATE_FMT_0));
        }
        return exp;
    }

    public abstract String exec(SchedulerYaml.Input input) throws SchedulerException;
}
