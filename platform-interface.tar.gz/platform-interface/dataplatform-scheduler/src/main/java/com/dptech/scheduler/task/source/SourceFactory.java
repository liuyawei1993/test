package com.dptech.scheduler.task.source;


import com.dptech.scheduler.entity.SchedulerYaml;
import com.dptech.scheduler.exception.SchedulerException;
import com.dptech.scheduler.util.ReflectionsUtils;

import java.util.List;
;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/15 下午1:34
 * @description: TODO
 */
public abstract class SourceFactory {
    public static SourceFactory getSourceFactory(String type) throws IllegalAccessException, InstantiationException {
        List<Class> allSubclass = ReflectionsUtils.getAllSubclass(SourceFactory.class);
        for (Class subclass : allSubclass) {
            if (subclass.getSimpleName().equals(type + "Source")) {
                return (SourceFactory) subclass.newInstance();
            }
        }
        return null;
    }

    public abstract String exec(SchedulerYaml.Input input) throws SchedulerException;
}
