package com.dptech.scheduler.util;

import com.dptech.redis.RedisLocalClient;
import redis.clients.jedis.ScanResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/19 下午3:09
 * @description: TODO
 */
public final class RedisUtils {
    private final static int mapTypeBatchSize = 10000;

    private RedisUtils() {
    }

    private static final RedisLocalClient redisLocalClient = new RedisLocalClient();


    /**
     * @param keyPrefix
     * @return
     */
    public static List<Map<String, Object>> obtainMapTypeData(String keyPrefix, Integer slot) {
        if (slot != null) redisLocalClient.setSlot(slot);
        // get keys
        ScanResult scanResult = redisLocalClient.scan(keyPrefix, "0");
        List keys = scanResult.getResult();
        String cursor = scanResult.getCursor();

        while (!cursor.equals("0") && keys.size() > 0) {
            scanResult = redisLocalClient.scan(keyPrefix, cursor);
            cursor = scanResult.getCursor();
            keys.addAll(scanResult.getResult());
        }

        // get values
        int size = keys.size();
        List<Map<String, Object>> result = new ArrayList<>(size);
        if (size > 0) {
            int batch;
            while ((size = keys.size()) > 0 && (batch = size % mapTypeBatchSize == 0 ? mapTypeBatchSize : size) > 0) {
                List subList = keys.subList(0, batch);
                result.addAll(redisLocalClient.hmget(subList));
                keys.removeAll(subList);
            }
        }

        return result;
    }
}
