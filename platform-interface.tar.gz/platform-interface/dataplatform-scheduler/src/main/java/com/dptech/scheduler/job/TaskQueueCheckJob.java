package com.dptech.scheduler.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;

/**
 * Created by jenkin.wang on 2019/9/20.
 */
public class TaskQueueCheckJob implements Job {

    @Override
    public void execute(JobExecutionContext context) {
        TaskQueueCheckJobBuilder.checkTask();
    }
}
