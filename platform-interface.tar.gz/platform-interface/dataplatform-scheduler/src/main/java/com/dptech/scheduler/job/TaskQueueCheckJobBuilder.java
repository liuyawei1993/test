package com.dptech.scheduler.job;

import com.dptech.scheduler.common.SchedulerConstants;
import com.dptech.util.DateUtils;
import org.apache.log4j.Logger;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.dptech.scheduler.listener.SchedulerTaskListener.threadInfo;


/**
 * @author : jelly.wang
 * @date : Created in 2019/9/29 上午11:09
 * @description: delete expired task in the SCHEDULER_TASK_QUEUE {@link com.dptech.scheduler.common.SchedulerConstants}
 */
public class TaskQueueCheckJobBuilder implements JobBuilder {
    private final static Logger LOGGER = Logger.getLogger(TaskQueueCheckJobBuilder.class);
//    private final static Map<String, SchedulerJobDetail> expiredJob = new ConcurrentHashMap<>();

    @Override
    public void build() {
        SchedulerManager.addJob("TaskQueueCheckJob", TaskQueueCheckJob.class, "0/10 * * * * ?", new Object());
    }


    public static void checkTask() {
        Long currentTime = DateUtils.getCurrentDateTime().getTime();

        // queue check
        Iterator<SchedulerJobDetail> iterator = SchedulerConstants.SCHEDULER_TASK_QUEUE.iterator();
        while (iterator.hasNext()) {
            SchedulerJobDetail task = iterator.next();
            // marked to be deleted
            /*if (null != expiredJob.get(task.getName())) {
                iterator.remove();
                LOGGER.warn("[" + task.toString() + "] is marked and be deleted.");
            }*/
            // expire job
            if (currentTime > task.getEndJobTime() || currentTime + task.getExpectTime() > task.getEndJobTime()) {
                iterator.remove();
                LOGGER.warn("[" + task.toString() + "] is expired.");
            }
        }

        // current task check
        SchedulerJobDetail schedulerJobDetail = threadInfo.getSchedulerJobDetail();
        Long execTime = threadInfo.getThreadTimestamp();
        //current time > end time OR exec time > expect time
        if (currentTime > schedulerJobDetail.getEndJobTime() || currentTime - execTime > schedulerJobDetail.getExpectTime()) {
            threadInfo.getJobExecutorService().shutdownNow();
            try {
                Thread.sleep(1000l);
                if (threadInfo.getJobExecutorService().isShutdown()) {
//                    expiredJob.put(schedulerJobDetail.getName(), schedulerJobDetail);
                    LOGGER.warn("THREAD_ID:[" + threadInfo.getThreadId() + "] is shutdown.<" + schedulerJobDetail.toString() + ">");
                }
            } catch (InterruptedException e) {
                LOGGER.warn(e.getMessage(), e);
            }
        }
    }
}
