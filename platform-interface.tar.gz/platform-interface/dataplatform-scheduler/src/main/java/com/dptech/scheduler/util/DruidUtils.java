package com.dptech.scheduler.util;

import com.alibaba.druid.sql.ast.statement.SQLSelectQuery;
import com.alibaba.druid.sql.ast.statement.SQLSelectStatement;
import com.alibaba.druid.sql.dialect.mysql.ast.statement.MySqlSelectQueryBlock;
import com.alibaba.druid.sql.dialect.mysql.parser.MySqlStatementParser;
import com.alibaba.druid.sql.dialect.mysql.visitor.MySqlOutputVisitor;
import com.dptech.scheduler.exception.SchedulerException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/20 上午11:02
 * @description: TODO
 */
public final class DruidUtils {
    private DruidUtils() {
    }


    public static Map<String, Object> simpleRedisSqlParse(String sqlString) throws SchedulerException {
        Map<String, Object> result = new HashMap<>();
        try {
            SQLSelectStatement sqlSelectStatement = new MySqlStatementParser(sqlString).parseSelect();
            SQLSelectQuery sqlSelectQuery = sqlSelectStatement.getSelect().getQuery();
            if (sqlSelectQuery instanceof MySqlSelectQueryBlock) {
                MySqlSelectQueryBlock mySqlSelectQueryBlock = (MySqlSelectQueryBlock) sqlSelectQuery;

                // tableName
                MySqlOutputVisitor tableName = new MySqlOutputVisitor(new StringBuilder());
                mySqlSelectQueryBlock.getFrom().accept(tableName);
                result.put("table_name", tableName.getAppender());
                // conditions only AND
                MySqlOutputVisitor where = new MySqlOutputVisitor(new StringBuilder());
                mySqlSelectQueryBlock.getWhere().accept(where);
                String condition = where.getAppender().toString().toLowerCase();
                String[] cons = condition.split("and");
                List<String[]> consList = new ArrayList<>();
                for (String con : cons) {
                    String[] split = con.split("=");
                    consList.add(new String[]{split[0].trim(), split[1].trim().substring(1, split[1].trim().length() - 1)});
                }
                result.put("conditions", consList);
                // limit
                MySqlOutputVisitor limit = new MySqlOutputVisitor(new StringBuilder());
                mySqlSelectQueryBlock.getLimit().accept(limit);
                result.put("limit", limit.getAppender().toString().replace("LIMIT", "").trim());
            }
        } catch (Exception e) {
            throw new SchedulerException("only support mysql dialect");
        }
        return result;
    }
}
