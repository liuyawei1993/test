import java.util.UUID;

/**
 * @author : jelly.wang
 * @date : Created in 2019/9/26 上午9:33
 * @description: TODO
 */
public class TestUuid {
    public static void main(String[] args) {
        System.out.println(createOrderId());
    }

    public static String createOrderId() {
        int machineId = 1;//????1-9???????
        int hashCodeV = UUID.randomUUID().toString().hashCode();
        if (hashCodeV < 0) {//??????
            hashCodeV = -hashCodeV;
        }
        // 0 ??????0
        // 4 ?????4
        // d ????????
        return machineId + String.format("%012d", hashCodeV);
    }
}
