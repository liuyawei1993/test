package dp.tsgz;

import com.google.common.util.concurrent.RateLimiter;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Tuple;

import java.util.Map;
import java.util.Properties;

public class InterceptorOutBolt extends BaseRichBolt {
    private RateLimiter limiter;
    private KafkaProducer producer;
    private String TOPIC;
    private Integer interceptorNum;

    @Override
    public void prepare(Map map, TopologyContext topologyContext, OutputCollector outputCollector) {
        TOPIC = (String) map.get("outPutTopicName");
        Properties properties = new Properties();
        properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, map.get("bootstrap_servers"));
        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
        producer = new KafkaProducer(properties);

        //set interceptor num
        interceptorNum = Integer.parseInt(map.get("interceptorNum").toString());
        limiter = RateLimiter.create(interceptorNum);
    }

    long i = 0;

    @Override
    public void execute(Tuple input) {
        try {
            if (limiter.tryAcquire()) {
                producer.send(new ProducerRecord<>(TOPIC, input.getString(4)));
                i++;
                if (i % 100000 == 0) {
                    System.out.println(i + "**********" + input.getString(4));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
    }
}
