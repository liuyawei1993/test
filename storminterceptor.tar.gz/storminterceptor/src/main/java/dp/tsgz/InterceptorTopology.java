package dp.tsgz;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.kafka.spout.KafkaSpout;
import org.apache.storm.kafka.spout.KafkaSpoutConfig;
import org.apache.storm.topology.TopologyBuilder;


public class InterceptorTopology {
    public static void main(String args[]) {
        TopologyBuilder builder = new TopologyBuilder();

        builder.setSpout("InterceptorKafkaSpout", new KafkaSpout(new KafkaSpoutConfig.Builder<>("10.121.201.182:6667", StringDeserializer.class, StringDeserializer.class, "s01")
                .setProp(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true")
                .setProp(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, 1000)
                .setFirstPollOffsetStrategy(KafkaSpoutConfig.FirstPollOffsetStrategy.UNCOMMITTED_LATEST)
                .setGroupId("bro_consumer")
                .setMaxPollRecords(250)
                .build()), 1);

        builder.setBolt("InterceptorOutBolt", new InterceptorOutBolt(), 1).setNumTasks(1).globalGrouping("InterceptorKafkaSpout");

        Config config = new Config();
        config.setNumWorkers(1);
        config.setNumAckers(0);
        config.setDebug(false);
        config.put("topology.worker.childopts", "-Xmx1024m -Xms1024m");

        config.put("bootstrap_servers", "10.121.201.182:6667");
        config.put("outPutTopicName", "t01");
        config.put("interceptorNum", 5000);

        if (args.length < 1) {
            LocalCluster cluster = new LocalCluster();
            cluster.submitTopology("bropro", config, builder.createTopology());
        } else {
            try {
                StormSubmitter.submitTopology("bropro", config, builder.createTopology());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

}
